<template>
  <aside class="app-sidebar">
    <nav>
      <ul>
        <li>Dashboard</li>
      </ul>
    </nav>
  </aside>
</template>

<script setup lang="ts">
// TODO: implement
</script>

<style scoped>
.app-sidebar { width: 240px; background: var(--bg-color); min-height: calc(100vh - 64px); padding: 16px; }
</style>

<template>
  <header class="app-header">
    <h1>JobGraph</h1>
  </header>
</template>

<script setup lang="ts">
// TODO: implement
</script>

<style scoped>
.app-header { padding: 16px; background: var(--primary-color); color: #fff; }
</style>

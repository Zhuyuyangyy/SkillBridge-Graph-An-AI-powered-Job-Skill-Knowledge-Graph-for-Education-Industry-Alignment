<template>
  <div class="tech-layout">
    <!-- 背景装饰 -->
    <div class="bg-grid"></div>
    <div class="bg-orb bg-orb-1"></div>
    <div class="bg-orb bg-orb-2"></div>

    <n-layout has-sider class="main-layout">
      <n-layout-sider bordered collapse-mode="width" :collapsed-width="68"
        :width="230" :collapsed="collapsed" class="tech-sider">
        <div class="sider-logo">
          <div class="logo-icon">
            <svg viewBox="0 0 40 40" width="36" height="36">
              <circle cx="20" cy="20" r="18" fill="none" stroke="#00F2FF" stroke-width="1.5" opacity="0.6"/>
              <circle cx="20" cy="20" r="10" fill="none" stroke="#0055FF" stroke-width="1.5" opacity="0.5"/>
              <circle cx="20" cy="20" r="4" fill="#00F2FF" opacity="0.8"/>
              <line x1="20" y1="2" x2="20" y2="12" stroke="#00F2FF" stroke-width="1" opacity="0.5"/>
              <line x1="38" y1="20" x2="28" y2="20" stroke="#0055FF" stroke-width="1" opacity="0.5"/>
            </svg>
          </div>
          <span v-if="!collapsed" class="logo-text">
            <span class="logo-title">岗位能力图谱</span>
            <span class="logo-subtitle">JOB COMPETENCY GRAPH</span>
          </span>
        </div>

        <n-menu :collapsed="collapsed" :value="activeKey"
          :options="menuOptions" @update:value="handleMenuClick"
          :indent="20" class="tech-menu" />

        <div class="sider-decoration">
          <div class="deco-line"></div>
          <div class="deco-dots">
            <span v-for="i in 5" :key="i" class="dot"></span>
          </div>
        </div>
      </n-layout-sider>

      <n-layout class="content-area">
        <n-layout-header bordered class="tech-header">
          <div class="header-left">
            <n-button text class="collapse-btn" @click="collapsed = !collapsed">
              <template #icon>
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
              </template>
            </n-button>
            <n-breadcrumb class="header-breadcrumb">
              <n-breadcrumb-item v-for="item in breadcrumbs" :key="item">
                <span class="breadcrumb-text">{{ item }}</span>
              </n-breadcrumb-item>
            </n-breadcrumb>
          </div>

          <div class="header-right">
            <div class="system-status">
              <span class="status-dot online"></span>
              <span class="status-text">系统运行中</span>
            </div>
            <div class="status-divider"></div>
            <span class="header-time">{{ currentTime }}</span>
            <n-tag :type="roleTagType" size="small" :bordered="false" class="role-tag">
              <template #icon><span class="role-dot"></span></template>
              {{ roleLabel }}
            </n-tag>
            <n-dropdown :options="userMenuOptions" @select="handleUserMenu" trigger="click">
              <n-button text class="user-btn">
                <span class="user-avatar">{{ (userStore.userInfo?.realName || 'U')[0] }}</span>
                <span class="user-name">{{ userStore.userInfo?.realName || '用户' }}</span>
              </n-button>
            </n-dropdown>
          </div>
        </n-layout-header>

        <n-layout-content class="main-content">
          <router-view v-slot="{ Component }">
            <transition name="page-fade" mode="out-in">
              <component :is="Component" />
            </transition>
          </router-view>
        </n-layout-content>
      </n-layout>
    </n-layout>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, h, onMounted, onUnmounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const collapsed = ref(false)
const currentTime = ref('')

let timer: any = null

onMounted(() => { updateTime(); timer = setInterval(updateTime, 1000) })
onUnmounted(() => { if (timer) clearInterval(timer) })

function updateTime() {
  currentTime.value = new Date().toLocaleString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
}

const activeKey = computed(() => route.path)

const roleLabel = computed(() => {
  const map: Record<string, string> = { STUDENT: '学生', TEACHER: '教师', ADMIN: '管理员' }
  return map[userStore.role as string] || '用户'
})
const roleTagType = computed(() => {
  const map: Record<string, any> = { STUDENT: 'info', TEACHER: 'warning', ADMIN: 'error' }
  return map[userStore.role as string] || 'default'
})

const breadcrumbs = computed(() => {
  const labels: Record<string, string> = {
    'dashboard': '首页驾驶舱', 'career/advisor': 'AI职业规划',
    'graph': '知识图谱', 'graph/explore': '图谱探索', 'graph/job': '岗位详情', 'graph/competency': '能力详情',
    'evolution': '演化分析', 'evolution/timeline': '时间轴演化', 'evolution/hotspot': '新兴与衰退', 'evolution/compare': '对比分析',
    'match': '产教对接', 'match/overview': '匹配概览', 'match/gap': '技能缺口', 'match/report': '匹配报告',
    'data': '数据中心', 'data/job': '岗位库', 'data/competency': '能力库', 'data/upload': '数据上传', 'data/source': '数据源管理',
    'report': '报告中心', 'report/list': '报告列表',
    'system': '系统管理', 'system/user': '用户管理', 'system/log': '采集日志', 'system/config': '系统配置',
  }
  const path = route.path.replace(/^\//, '').replace(/\/\d+$/, '')
  return [labels[path] || path]
})

// SVG 图标
function renderIcon(type: string) {
  const paths: Record<string, string> = {
    dashboard: 'M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z',
    career: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z',
    graph: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z',
    evolution: 'M3.5 18.49l6-6.01 4 4L22 6.92l-1.41-1.41-7.09 7.97-4-4L2 16.99z',
    match: 'M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z',
    data: 'M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z',
    report: 'M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z',
    system: 'M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94L14.4 2.81c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41L9.25 5.35c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.07.62-.07.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z',
  }
  return () => h('svg', { viewBox: '0 0 24 24', width: '20', height: '20', fill: 'currentColor', style: { opacity: 0.85 } }, [
    h('path', { d: paths[type] || paths.dashboard })
  ])
}

const menuOptions = computed(() => [
  { label: '首页驾驶舱', key: '/dashboard', icon: renderIcon('dashboard') },
  { label: 'AI职业规划', key: '/career/advisor', icon: renderIcon('career') },
  { label: '知识图谱', key: 'graph-group', icon: renderIcon('graph'),
    children: [{ label: '图谱探索', key: '/graph/explore' }] },
  { label: '演化分析', key: 'evolution-group', icon: renderIcon('evolution'),
    children: [
      { label: '时间轴演化', key: '/evolution/timeline' },
      { label: '新兴与衰退', key: '/evolution/hotspot' },
      { label: '对比分析', key: '/evolution/compare' },
    ] },
  { label: '产教对接', key: 'match-group', icon: renderIcon('match'),
    children: [
      { label: '匹配概览', key: '/match/overview' },
      { label: '技能缺口', key: '/match/gap' },
      { label: '生成报告', key: '/match/report' },
    ] },
  { label: '数据中心', key: 'data-group', icon: renderIcon('data'),
    children: [
      { label: '岗位库', key: '/data/job' },
      { label: '能力库', key: '/data/competency' },
      { label: '数据上传', key: '/data/upload' },
      ...(userStore.role === 'ADMIN' ? [{ label: '数据源管理', key: '/data/source' }] : []),
    ] },
  { label: '报告中心', key: '/report/list', icon: renderIcon('report') },
  ...(userStore.role === 'ADMIN' ? [{
    label: '系统管理', key: 'system-group', icon: renderIcon('system'),
    children: [
      { label: '用户管理', key: '/system/user' },
      { label: '采集日志', key: '/system/log' },
      { label: '系统配置', key: '/system/config' },
    ],
  }] : []),
])

function handleMenuClick(key: string) {
  if (!key.startsWith('/')) return
  router.push(key)
}

const userMenuOptions = [{ label: '退出登录', key: 'logout' }]
function handleUserMenu(key: string) {
  if (key === 'logout') { userStore.logout(); router.push('/login') }
}
</script>

<style scoped>
.tech-layout { position: relative; min-height: 100vh; background: var(--gradient-bg); }
.main-layout { position: relative; z-index: 1; height: 100vh; }

.bg-grid {
  position: fixed; inset: 0; pointer-events: none; z-index: 0;
  background-image: radial-gradient(circle, rgba(0, 242, 255, 0.04) 1px, transparent 1px);
  background-size: 44px 44px;
}
.bg-orb { position: fixed; border-radius: 50%; pointer-events: none; z-index: 0; filter: blur(120px); opacity: 0.12; }
.bg-orb-1 { top: -200px; right: -150px; width: 500px; height: 500px; background: radial-gradient(circle, #00F2FF, transparent); }
.bg-orb-2 { bottom: -150px; left: -100px; width: 400px; height: 400px; background: radial-gradient(circle, #0055FF, transparent); }

.tech-sider { background: var(--bg-sidebar) !important; border-right: 1px solid var(--border-color) !important; }

.sider-logo { display: flex; align-items: center; gap: 10px; padding: 18px 18px 16px; border-bottom: 1px solid var(--border-color); margin-bottom: 8px; }
.logo-icon { flex-shrink: 0; animation: glow-pulse 3s ease-in-out infinite; }
.logo-text { display: flex; flex-direction: column; line-height: 1.3; overflow: hidden; }
.logo-title { font-size: 15px; font-weight: 700; color: var(--text-primary); white-space: nowrap; letter-spacing: 1px; }
.logo-subtitle { font-size: 9px; font-weight: 400; color: var(--text-muted); letter-spacing: 2px; white-space: nowrap; }

.tech-menu { padding: 0 8px; }
:deep(.n-menu .n-menu-item) { border-radius: 8px; margin: 2px 0; }
:deep(.n-menu .n-menu-item:hover) { background: rgba(0, 242, 255, 0.06) !important; }

.sider-decoration { position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); }
.deco-line { width: 60%; height: 1px; background: linear-gradient(90deg, transparent, var(--border-glow), transparent); margin: 0 auto 8px; }
.deco-dots { display: flex; justify-content: center; gap: 8px; }
.dot {
  width: 4px; height: 4px; border-radius: 50%;
  background: var(--primary-color); opacity: 0.5;
}
.dot:nth-child(odd) { animation: glow-pulse 2s ease-in-out infinite; }
.dot:nth-child(even) { animation: glow-pulse 2s ease-in-out 1s infinite; }

.tech-header {
  height: 56px !important; display: flex; align-items: center; justify-content: space-between;
  padding: 0 20px; background: rgba(8, 22, 42, 0.88) !important;
  backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(0, 242, 255, 0.08) !important;
  box-shadow: 0 0 15px rgba(0, 242, 255, 0.08);
}
.header-left { display: flex; align-items: center; gap: 16px; }
.collapse-btn { color: var(--text-secondary); }
.collapse-btn:hover { color: #00F2FF !important; }
.breadcrumb-text { color: var(--text-secondary); font-size: 13px; }

.header-right { display: flex; align-items: center; gap: 16px; }
.system-status { display: flex; align-items: center; gap: 6px; }
.status-dot { width: 6px; height: 6px; border-radius: 50%; background: #69F0AE; box-shadow: 0 0 8px #69F0AE; }
.status-dot.online { animation: glow-pulse 2s ease-in-out infinite; }
.status-text { font-size: 12px; color: var(--text-muted); }
.status-divider { width: 1px; height: 16px; background: var(--border-color); }
.header-time { font-family: 'SF Mono', 'Consolas', monospace; font-size: 13px; color: var(--text-secondary); letter-spacing: 1px; }
.role-tag { font-size: 11px; opacity: 0.9; }
.role-dot { display: inline-block; width: 5px; height: 5px; border-radius: 50%; background: currentColor; margin-right: 4px; }
.user-btn { display: flex; align-items: center; gap: 8px; color: var(--text-secondary) !important; }
.user-avatar {
  display: flex; align-items: center; justify-content: center; width: 28px; height: 28px;
  border-radius: 6px; font-size: 13px; font-weight: 600;
  background: linear-gradient(135deg, rgba(0,242,255,0.12), rgba(0,85,255,0.12)); border: 1px solid rgba(0,242,255,0.15); color: #00F2FF;
}
.user-name { font-size: 13px; }

.main-content { padding: 20px 24px; min-height: calc(100vh - 56px); background: transparent; }

.page-fade-enter-active, .page-fade-leave-active { transition: opacity 0.2s ease, transform 0.2s ease; }
.page-fade-enter-from { opacity: 0; transform: translateY(6px); }
.page-fade-leave-to { opacity: 0; transform: translateY(-6px); }
</style>

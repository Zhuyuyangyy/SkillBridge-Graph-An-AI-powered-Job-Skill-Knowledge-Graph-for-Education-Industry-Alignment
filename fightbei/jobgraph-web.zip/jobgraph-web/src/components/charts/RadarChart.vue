<template>
  <div ref="chartRef" :style="{ height: height + 'px' }"></div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import * as echarts from 'echarts'

const props = defineProps<{
  data: Array<{ name: string; value: number; max?: number }>
  height?: number
}>()

const chartRef = ref<HTMLDivElement>()
let chart: any = null

function render() {
  if (!chartRef.value || !props.data.length) return
  if (!chart) chart = echarts.init(chartRef.value)
  const maxVal = Math.max(...props.data.map(d => d.max || 100))
  chart.setOption({
    radar: {
      indicator: props.data.map(d => ({ name: d.name, max: maxVal })),
      shape: 'polygon',
      center: ['50%', '55%'],
      radius: '70%',
    },
    series: [{
      type: 'radar',
      data: [{ value: props.data.map(d => d.value), name: '能力画像' }],
      areaStyle: { color: 'rgba(24,144,255,0.2)' },
      lineStyle: { color: '#1890ff', width: 2 },
      itemStyle: { color: '#1890ff' },
    }],
  })
}

watch(() => props.data, render, { deep: true })
onMounted(render)
</script>

<template>
  <div ref="containerRef" class="force-graph-container"></div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch } from 'vue'
import { Graph } from '@antv/g6'

const props = defineProps<{
  nodes: Array<{ id: string; label: string; type: string; [key: string]: any }>
  edges: Array<{ source: string; target: string; score: number }>
}>()

const emit = defineEmits<{ nodeClick: [node: any] }>()
const containerRef = ref<HTMLDivElement>()
let graph: any = null

function buildData() {
  return {
    nodes: props.nodes.map((n) => ({
      id: n.id,
      data: {
        label: n.label,
        nodeType: n.type,
        industry: n.industry,
        category: n.category,
        demandCount: n.demandCount,
      },
      style: {
        fill: n.type === 'job' ? '#00F2FF' : '#0055FF',
        stroke: n.type === 'job' ? '#00C8D4' : '#0040CC',
        size: n.type === 'job' ? 32 : 20,
      },
    })),
    edges: props.edges.map((e) => ({
      source: e.source,
      target: e.target,
      style: {
        stroke: 'rgba(255,255,255,0.15)',
        lineWidth: 0.8,
        opacity: 0.5,
      },
    })),
  }
}

async function initGraph() {
  if (!containerRef.value) return
  const { width, height } = containerRef.value.getBoundingClientRect()
  if (!width || !height) return

  // 销毁旧实例
  graph?.destroy()

  graph = new Graph({
    container: containerRef.value,
    width: width || 800,
    height: height || 600,
    data: buildData(),
    layout: {
      type: 'd3-force',
      link: { distance: 120, strength: 0.6 },
      collide: { radius: 40 },
      manyBody: { strength: -100 },
    },
    node: {
      type: (d: any) => (d.data?.nodeType === 'job' ? 'circle' : 'rect'),
      style: {
        size: (d: any) => (d.style?.size || 24),
        fill: (d: any) => (d.style?.fill || '#00F2FF'),
        stroke: (d: any) => (d.style?.stroke || '#00C8D4'),
        lineWidth: 1.5,
        labelText: (d: any) => d.data?.label || d.id,
        labelFill: '#A5F3FC',
        labelFontSize: 11,
        labelPlacement: 'bottom',
        labelOffsetY: 6,
      },
      state: {
        active: {
          stroke: '#00F2FF',
          lineWidth: 3,
          shadowBlur: 12,
          shadowColor: 'rgba(0, 242, 255, 0.6)',
        },
      },
    },
    edge: {
      style: {
        stroke: 'rgba(255, 255, 255, 0.12)',
        lineWidth: 0.8,
        opacity: 0.5,
        endArrow: false,
      },
    },
    behaviors: ['drag-canvas', 'zoom-canvas', 'drag-element', 'hover-activate'],
    autoFit: 'view',
    animation: true,
  })

  graph.on('node:click', (evt: any) => {
    const id = evt.target?.id
    const node = props.nodes.find((n) => n.id === id)
    if (node) emit('nodeClick', node)
  })

  await graph.render()
}

function updateGraph() {
  if (!graph) { initGraph(); return }
  graph.setData(buildData())
  graph.render()
}

watch(() => [props.nodes, props.edges], updateGraph, { deep: true })

onMounted(() => {
  setTimeout(initGraph, 150)
})

onUnmounted(() => {
  graph?.destroy()
  graph = null
})
</script>

<style scoped>
.force-graph-container {
  width: 100%;
  min-height: 550px;
  background: rgba(15, 32, 55, 0.68);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 0 15px rgba(0, 242, 255, 0.08);
  border-radius: 10px;
}
</style>

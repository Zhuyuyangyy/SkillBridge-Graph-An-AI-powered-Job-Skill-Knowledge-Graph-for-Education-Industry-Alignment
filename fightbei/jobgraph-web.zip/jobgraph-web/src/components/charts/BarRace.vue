<template>
  <div class="chart-container">
    <h2>BarRace</h2>
  </div>
</template>

<script setup lang="ts">
// TODO: implement
</script>

<style scoped>
.chart-container { padding: 16px; }
</style>

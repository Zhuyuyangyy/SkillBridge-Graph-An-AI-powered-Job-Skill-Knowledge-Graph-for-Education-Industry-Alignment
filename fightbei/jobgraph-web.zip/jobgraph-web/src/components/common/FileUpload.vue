<template>
  <div class="common-container">
    <h2>FileUpload</h2>
  </div>
</template>

<script setup lang="ts">
// TODO: implement
</script>

<style scoped>
.common-container { padding: 16px; }
</style>

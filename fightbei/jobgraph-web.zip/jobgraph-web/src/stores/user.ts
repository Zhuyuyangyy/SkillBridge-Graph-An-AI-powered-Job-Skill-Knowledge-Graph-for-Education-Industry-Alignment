import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { login as loginApi, getCurrentUser, type LoginParams } from '@/api/auth'

export const useUserStore = defineStore('user', () => {
  const token = ref(localStorage.getItem('token') || '')
  const userInfo = ref<any>(null)

  async function login(params: LoginParams) {
    const res: any = await loginApi(params)
    token.value = res.token
    userInfo.value = res.user
    localStorage.setItem('token', res.token)
    return res
  }

  async function fetchUserInfo() {
    if (!token.value) return
    try {
      userInfo.value = await getCurrentUser()
    } catch {
      logout()
    }
  }

  function logout() {
    token.value = ''
    userInfo.value = null
    localStorage.clear()
  }

  const isLoggedIn = computed(() => !!token.value)
  const role = computed(() => userInfo.value?.role)

  return { token, userInfo, login, fetchUserInfo, logout, isLoggedIn, role }
})

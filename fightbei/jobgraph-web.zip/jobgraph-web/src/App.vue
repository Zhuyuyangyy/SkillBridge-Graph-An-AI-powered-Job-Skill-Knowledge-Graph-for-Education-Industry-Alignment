<template>
  <n-config-provider :theme="darkTheme" :theme-overrides="themeOverrides" :locale="zhCN" :date-locale="dateZhCN">
    <n-message-provider placement="top-right" :max="3">
      <n-dialog-provider>
        <n-notification-provider>
          <router-view />
        </n-notification-provider>
      </n-dialog-provider>
    </n-message-provider>
  </n-config-provider>
</template>

<script setup lang="ts">
import { darkTheme, zhCN, dateZhCN } from 'naive-ui'
import type { GlobalThemeOverrides } from 'naive-ui'

const themeOverrides: GlobalThemeOverrides = {
  common: {
    primaryColor: '#00F2FF',
    primaryColorHover: '#33F5FF',
    primaryColorPressed: '#00C8D4',
    primaryColorSuppl: '#0055FF',
    infoColor: '#00F2FF',
    successColor: '#00E676',
    warningColor: '#FF9100',
    errorColor: '#FF5252',
    bodyColor: '#0B1A30',
    cardColor: 'rgba(15, 32, 55, 0.80)',
    modalColor: '#162E50',
    popoverColor: '#162E50',
    tableColor: 'rgba(15, 32, 55, 0.65)',
    inputColor: 'rgba(15, 32, 55, 0.70)',
    borderColor: 'rgba(0, 242, 255, 0.08)',
    dividerColor: 'rgba(255, 255, 255, 0.04)',
    borderRadius: '8px',
    fontFamily: "'Inter','PingFang SC','Microsoft YaHei',sans-serif",
    textColor1: '#E8EDF1',
    textColor2: '#A5F3FC',
    textColor3: '#6B8090',
    hoverColor: 'rgba(0, 242, 255, 0.05)',
  },
  Layout: {
    headerColor: 'rgba(8, 22, 42, 0.92)',
    siderColor: 'rgba(8, 22, 42, 0.95)',
    footerColor: '#0B1A30',
    headerBorderColor: 'rgba(0, 242, 255, 0.06)',
    siderBorderColor: 'rgba(0, 242, 255, 0.06)',
  },
  Menu: {
    itemColorActive: 'rgba(0, 242, 255, 0.10)',
    itemColorActiveHover: 'rgba(0, 242, 255, 0.16)',
    itemTextColorActive: '#00F2FF',
    itemIconColorActive: '#00F2FF',
    itemTextColor: '#A5F3FC',
    itemTextColorHoverHorizontal: '#E8EDF1',
  },
  Button: {
    primaryColor: '#0055FF',
    primaryColorHover: '#2979FF',
    primaryColorPressed: '#0040CC',
    borderRadius: '8px',
    textColor: '#FFF',
  },
  Card: {
    borderRadius: '12px',
    borderColor: 'rgba(0, 242, 255, 0.08)',
    color: 'rgba(15, 32, 55, 0.75)',
    titleTextColor: '#E8EDF1',
  },
  Tag: { borderRadius: '4px' },
  Input: {
    borderRadius: '8px',
    border: '1px solid rgba(0, 242, 255, 0.10)',
    borderHover: '1px solid rgba(0, 242, 255, 0.22)',
    borderFocus: '1px solid #00F2FF',
    color: 'rgba(15, 32, 55, 0.65)',
    textColor: '#E8EDF1',
    placeholderColor: '#6B8090',
  },
  Select: {
    peers: {
      InternalSelection: {
        borderRadius: '8px',
        borderColor: 'rgba(0, 242, 255, 0.10)',
        color: 'rgba(15, 32, 55, 0.65)',
      },
    },
  },
  DataTable: {
    borderRadius: '12px',
    thColor: 'rgba(0, 242, 255, 0.04)',
    tdColor: 'rgba(15, 32, 55, 0.50)',
    thTextColor: '#A5F3FC',
    tdTextColor: '#E8EDF1',
  },
  Progress: { fillColor: '#00F2FF', railColor: 'rgba(255,255,255,0.03)' },
  Statistic: {
    labelFontSize: '13px',
    labelTextColor: '#A5F3FC',
    valueFontSize: '28px',
    valueFontWeight: '700',
    valueTextColor: '#E8EDF1',
  },
  Tabs: {
    tabTextColorActiveLine: '#00F2FF',
    barColor: '#00F2FF',
  },
}
</script>

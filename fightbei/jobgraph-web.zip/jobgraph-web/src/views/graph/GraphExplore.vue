<template>
  <div class="graph-explore">
    <!-- Toolbar -->
    <div class="panel-toolbar">
      <div class="community-filters">
        <n-button v-for="f in communityFilters" :key="f.key ?? 'all'"
          :type="activeCommunity === f.key ? 'primary' : 'default'"
          size="small" round @click="filterCommunity(f.key)">
          <template #icon><span class="comm-dot" :style="{ background: f.color }"></span></template>
          {{ f.label }}
        </n-button>
      </div>
      <n-input v-model:value="keyword" placeholder="搜索节点..." style="width: 200px" clearable size="small" @keyup.enter="doSearch" />
      <n-button size="small" @click="resetGraph">重置视图</n-button>
    </div>

    <div class="graph-layout">
      <!-- Left Stats Panel -->
      <div class="graph-sidebar">
        <div class="panel-card" style="padding: 14px; margin-bottom: 12px">
          <div class="panel-header"><span class="panel-title">图谱统计</span></div>
          <div class="stats-grid">
            <div class="stat-item" v-for="s in statsItems" :key="s.label">
              <span class="stat-num">{{ s.value }}</span>
              <span class="stat-lbl">{{ s.label }}</span>
            </div>
          </div>
        </div>

        <div class="panel-card" style="padding: 14px; margin-bottom: 12px">
          <div class="panel-header"><span class="panel-title">社区分布</span></div>
          <div class="comm-list">
            <div v-for="c in communities" :key="c.name" class="comm-row"
              @click="filterCommunity(c.name)" :class="{ active: activeCommunity === c.name }">
              <span class="comm-dot" :style="{ background: c.color }"></span>
              <span class="comm-name">{{ c.name }}</span>
              <span class="comm-count">{{ c.count }}</span>
            </div>
          </div>
        </div>

        <div class="panel-card" style="padding: 14px">
          <div class="panel-header"><span class="panel-title">路径分析</span></div>
          <n-select v-model:value="pathFrom" :options="nodeOptions" placeholder="起始岗位" size="small" style="margin-bottom: 8px" />
          <n-select v-model:value="pathTo" :options="nodeOptions" placeholder="目标岗位" size="small" style="margin-bottom: 8px" />
          <n-button type="primary" size="small" block @click="findPath" :disabled="!pathFrom || !pathTo">
            分析迁移路径
          </n-button>
          <div v-if="pathResult.length" class="path-result" style="margin-top: 10px">
            <div v-for="(n, i) in pathResult" :key="i" class="path-node">
              <n-tag :type="n.type === 'job' ? 'info' : 'success'" size="small">{{ n.label }}</n-tag>
              <span v-if="i < pathResult.length - 1" class="path-arrow">→</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Main Graph -->
      <div class="graph-main">
        <div class="panel-card" style="padding: 0; height: 100%">
          <ForceGraph :nodes="filteredNodes" :edges="filteredEdges" @node-click="onNodeClick" />
        </div>
      </div>
    </div>

    <!-- Node Detail Drawer -->
    <n-drawer v-model:show="drawerShow" :width="420" placement="right">
      <n-drawer-content :title="selectedNode?.label">
        <template v-if="selectedNode?.type === 'job'">
          <n-descriptions :column="1" bordered size="small" label-placement="left">
            <n-descriptions-item label="类型"><n-tag type="info">岗位</n-tag></n-descriptions-item>
            <n-descriptions-item label="行业">{{ selectedNode.group }}</n-descriptions-item>
            <n-descriptions-item label="需求量">{{ selectedNode.demandCount?.toLocaleString() }}</n-descriptions-item>
            <n-descriptions-item label="中心度">{{ selectedNode.centrality }}</n-descriptions-item>
          </n-descriptions>
          <n-divider />
          <div style="color: #A5F3FC; font-size: 13px; margin-bottom: 8px">关联能力</div>
          <n-space>
            <n-tag v-for="e in nodeEdges" :key="e.target" type="success" size="small">
              {{ e.targetLabel }} ({{ (e.weight * 100).toFixed(0) }}%)
            </n-tag>
          </n-space>
          <n-button type="primary" block style="margin-top: 20px" @click="goDetail">查看完整详情</n-button>
        </template>

        <template v-else-if="selectedNode?.type === 'competency'">
          <n-descriptions :column="1" bordered size="small" label-placement="left">
            <n-descriptions-item label="类型"><n-tag type="success">能力</n-tag></n-descriptions-item>
            <n-descriptions-item label="分类">{{ selectedNode.category }}</n-descriptions-item>
            <n-descriptions-item label="中心度">{{ selectedNode.centrality }}</n-descriptions-item>
          </n-descriptions>
          <n-divider />
          <div style="color: #A5F3FC; font-size: 13px; margin-bottom: 8px">关联岗位</div>
          <n-space>
            <n-tag v-for="e in nodeEdges" :key="e.source" type="info" size="small">
              {{ e.sourceLabel }} ({{ (e.weight * 100).toFixed(0) }}%)
            </n-tag>
          </n-space>
          <n-button type="primary" block style="margin-top: 20px" @click="goDetail">查看完整详情</n-button>
        </template>
      </n-drawer-content>
    </n-drawer>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import ForceGraph from '@/components/charts/ForceGraph.vue'
import { getGraphNodes } from '@/api/graph'

const router = useRouter()
const keyword = ref('')
const activeCommunity = ref<string | null>(null)
const allNodes = ref<any[]>([])
const allEdges = ref<any[]>([])
const drawerShow = ref(false)
const selectedNode = ref<any>(null)
const pathFrom = ref<number | null>(null)
const pathTo = ref<number | null>(null)
const pathResult = ref<any[]>([])

const communityFilters = [
  { key: null, label: '全部', color: '#A5F3FC' },
  { key: '后端开发', label: '后端', color: 'rgba(0,242,255,0.8)' },
  { key: '数据科学', label: '数据', color: 'rgba(0,85,255,0.8)' },
  { key: '前端开发', label: '前端', color: 'rgba(124,77,255,0.8)' },
  { key: '产品管理', label: '产品', color: 'rgba(0,230,118,0.8)' },
  { key: '金融科技', label: '金融', color: 'rgba(255,145,0,0.8)' },
]

const communities = [
  { name: '后端开发', count: 11, color: 'rgba(0,242,255,0.8)' },
  { name: '数据科学', count: 9, color: 'rgba(0,85,255,0.8)' },
  { name: '前端开发', count: 5, color: 'rgba(124,77,255,0.8)' },
  { name: '产品管理', count: 5, color: 'rgba(0,230,118,0.8)' },
  { name: '金融科技', count: 5, color: 'rgba(255,145,0,0.8)' },
]

const statsItems = computed(() => [
  { label: '总节点', value: allNodes.value.length || '32' },
  { label: '岗位数', value: allNodes.value.filter(n => n.type === 'job').length || '11' },
  { label: '能力数', value: allNodes.value.filter(n => n.type === 'competency').length || '21' },
  { label: '关系边', value: allEdges.value.length || '48' },
  { label: '社区数', value: '5' },
  { label: '平均度', value: allNodes.value.length ? (allEdges.value.length * 2 / allNodes.value.length).toFixed(1) : '3.0' },
])

const communityColors: Record<number, string> = {
  0: 'rgba(0,242,255,0.75)',
  1: 'rgba(0,85,255,0.75)',
  2: 'rgba(124,77,255,0.75)',
  3: 'rgba(0,230,118,0.75)',
  4: 'rgba(255,145,0,0.75)',
}

const communityStrokeColors: Record<number, string> = {
  0: '#00F2FF', 1: '#0055FF', 2: '#7C4DFF', 3: '#00E676', 4: '#FF9100',
}

const filteredNodes = computed(() => {
  let nodes = allNodes.value
  if (activeCommunity.value) {
    nodes = nodes.filter(n => n.group === activeCommunity.value || n.community === communities.findIndex(c => c.name === activeCommunity.value))
  }
  if (keyword.value) {
    const kw = keyword.value.toLowerCase()
    nodes = nodes.filter(n => n.label.toLowerCase().includes(kw))
  }
  return nodes.map(n => ({
    ...n,
    style: {
      fill: communityColors[n.community] || '#00F2FF',
      stroke: communityStrokeColors[n.community] || '#00F2FF',
      size: n.size || (n.type === 'job' ? 30 : 16),
    },
  }))
})

const filteredEdges = computed(() => {
  const nodeIds = new Set(filteredNodes.value.map(n => n.id))
  return allEdges.value.filter(e => nodeIds.has(e.source) && nodeIds.has(e.target))
})

const nodeOptions = computed(() =>
  allNodes.value.filter(n => n.type === 'job').map(n => ({ label: n.label, value: n.id }))
)

const nodeEdges = computed(() => {
  if (!selectedNode.value) return []
  const nid = selectedNode.value.id
  return allEdges.value
    .filter(e => e.source === nid || e.target === nid)
    .map(e => ({
      ...e,
      sourceLabel: allNodes.value.find(n => n.id === e.source)?.label || e.source,
      targetLabel: allNodes.value.find(n => n.id === e.target)?.label || e.target,
    }))
})

async function loadFromApi() {
  try {
    const data: any = await getGraphNodes({ limit: 300 })
    if (data?.nodes?.length) {
      allNodes.value = data.nodes
      allEdges.value = data.edges
      return true
    }
  } catch { /* API unavailable, fall back to demo data */ }
  return false
}

function loadDemo() {
  allNodes.value = [
    { id: 'job_1', label: 'Java开发工程师', type: 'job', group: '后端开发', demandCount: 2847, centrality: 0.95, community: 0, size: 36 },
    { id: 'job_2', label: '数据分析师', type: 'job', group: '数据科学', demandCount: 1920, centrality: 0.88, community: 1, size: 34 },
    { id: 'job_3', label: '算法工程师', type: 'job', group: '数据科学', demandCount: 1450, centrality: 0.90, community: 1, size: 34 },
    { id: 'job_4', label: '前端开发工程师', type: 'job', group: '前端开发', demandCount: 1680, centrality: 0.82, community: 2, size: 32 },
    { id: 'job_5', label: '产品经理', type: 'job', group: '产品管理', demandCount: 2100, centrality: 0.84, community: 3, size: 32 },
    { id: 'job_6', label: '金融分析师', type: 'job', group: '金融科技', demandCount: 950, centrality: 0.66, community: 4, size: 28 },
    { id: 'job_7', label: '信息安全工程师', type: 'job', group: '金融科技', demandCount: 760, centrality: 0.62, community: 4, size: 28 },
    { id: 'job_8', label: '运维工程师', type: 'job', group: '后端开发', demandCount: 1200, centrality: 0.72, community: 0, size: 30 },
    { id: 'job_9', label: '数据工程师', type: 'job', group: '数据科学', demandCount: 980, centrality: 0.76, community: 1, size: 30 },
    { id: 'job_13', label: 'Go开发工程师', type: 'job', group: '后端开发', demandCount: 680, centrality: 0.58, community: 0, size: 26 },
    { id: 'job_14', label: '全栈开发工程师', type: 'job', group: '前端开发', demandCount: 920, centrality: 0.68, community: 2, size: 28 },
    { id: 'job_15', label: '项目经理', type: 'job', group: '产品管理', demandCount: 1350, centrality: 0.70, community: 3, size: 28 },
    { id: 'comp_1', label: 'Java', type: 'competency', category: 'HARD_SKILL', community: 0, centrality: 0.90, size: 22 },
    { id: 'comp_2', label: 'Python', type: 'competency', category: 'HARD_SKILL', community: 1, centrality: 0.95, size: 24 },
    { id: 'comp_3', label: 'SpringBoot', type: 'competency', category: 'HARD_SKILL', community: 0, centrality: 0.78, size: 20 },
    { id: 'comp_4', label: 'MySQL', type: 'competency', category: 'HARD_SKILL', community: 0, centrality: 0.82, size: 22 },
    { id: 'comp_5', label: '机器学习', type: 'competency', category: 'HARD_SKILL', community: 1, centrality: 0.88, size: 22 },
    { id: 'comp_6', label: 'Docker', type: 'competency', category: 'TOOL', community: 0, centrality: 0.75, size: 20 },
    { id: 'comp_7', label: 'Vue/React', type: 'competency', category: 'HARD_SKILL', community: 2, centrality: 0.80, size: 20 },
    { id: 'comp_8', label: 'Linux', type: 'competency', category: 'TOOL', community: 0, centrality: 0.85, size: 22 },
    { id: 'comp_9', label: '数据分析', type: 'competency', category: 'HARD_SKILL', community: 1, centrality: 0.85, size: 22 },
    { id: 'comp_10', label: '沟通能力', type: 'competency', category: 'SOFT_SKILL', community: 3, centrality: 0.72, size: 18 },
    { id: 'comp_11', label: '项目管理', type: 'competency', category: 'SOFT_SKILL', community: 3, centrality: 0.78, size: 20 },
    { id: 'comp_12', label: 'Redis', type: 'competency', category: 'HARD_SKILL', community: 0, centrality: 0.68, size: 18 },
    { id: 'comp_13', label: '统计学', type: 'competency', category: 'HARD_SKILL', community: 1, centrality: 0.76, size: 20 },
    { id: 'comp_14', label: 'Kubernetes', type: 'competency', category: 'TOOL', community: 0, centrality: 0.62, size: 18 },
    { id: 'comp_15', label: '网络安全', type: 'competency', category: 'HARD_SKILL', community: 4, centrality: 0.58, size: 16 },
    { id: 'comp_16', label: 'Go', type: 'competency', category: 'HARD_SKILL', community: 0, centrality: 0.52, size: 16 },
    { id: 'comp_17', label: '深度学习', type: 'competency', category: 'HARD_SKILL', community: 1, centrality: 0.82, size: 22 },
    { id: 'comp_18', label: 'PyTorch', type: 'competency', category: 'HARD_SKILL', community: 1, centrality: 0.72, size: 20 },
    { id: 'comp_19', label: 'TypeScript', type: 'competency', category: 'HARD_SKILL', community: 2, centrality: 0.65, size: 18 },
    { id: 'comp_20', label: 'CSS', type: 'competency', category: 'HARD_SKILL', community: 2, centrality: 0.55, size: 16 },
    { id: 'comp_21', label: '需求分析', type: 'competency', category: 'SOFT_SKILL', community: 3, centrality: 0.62, size: 18 },
    { id: 'comp_22', label: '区块链', type: 'competency', category: 'HARD_SKILL', community: 4, centrality: 0.42, size: 14 },
    { id: 'comp_23', label: '风控建模', type: 'competency', category: 'HARD_SKILL', community: 4, centrality: 0.48, size: 16 },
  ]
  allEdges.value = [
    { source: 'job_1', target: 'comp_1', weight: 0.95 },
    { source: 'job_1', target: 'comp_3', weight: 0.90 },
    { source: 'job_1', target: 'comp_4', weight: 0.85 },
    { source: 'job_1', target: 'comp_6', weight: 0.70 },
    { source: 'job_1', target: 'comp_8', weight: 0.78 },
    { source: 'job_1', target: 'comp_12', weight: 0.72 },
    { source: 'job_2', target: 'comp_2', weight: 0.95 },
    { source: 'job_2', target: 'comp_9', weight: 0.90 },
    { source: 'job_2', target: 'comp_4', weight: 0.80 },
    { source: 'job_2', target: 'comp_13', weight: 0.78 },
    { source: 'job_3', target: 'comp_2', weight: 0.92 },
    { source: 'job_3', target: 'comp_5', weight: 0.95 },
    { source: 'job_3', target: 'comp_13', weight: 0.82 },
    { source: 'job_3', target: 'comp_17', weight: 0.88 },
    { source: 'job_3', target: 'comp_18', weight: 0.85 },
    { source: 'job_4', target: 'comp_7', weight: 0.95 },
    { source: 'job_4', target: 'comp_19', weight: 0.82 },
    { source: 'job_4', target: 'comp_20', weight: 0.75 },
    { source: 'job_4', target: 'comp_1', weight: 0.55 },
    { source: 'job_5', target: 'comp_10', weight: 0.88 },
    { source: 'job_5', target: 'comp_11', weight: 0.85 },
    { source: 'job_5', target: 'comp_21', weight: 0.92 },
    { source: 'job_5', target: 'comp_9', weight: 0.70 },
    { source: 'job_6', target: 'comp_2', weight: 0.80 },
    { source: 'job_6', target: 'comp_9', weight: 0.85 },
    { source: 'job_6', target: 'comp_13', weight: 0.90 },
    { source: 'job_6', target: 'comp_23', weight: 0.78 },
    { source: 'job_7', target: 'comp_15', weight: 0.95 },
    { source: 'job_7', target: 'comp_8', weight: 0.80 },
    { source: 'job_7', target: 'comp_22', weight: 0.65 },
    { source: 'job_8', target: 'comp_8', weight: 0.92 },
    { source: 'job_8', target: 'comp_6', weight: 0.88 },
    { source: 'job_8', target: 'comp_14', weight: 0.78 },
    { source: 'job_8', target: 'comp_4', weight: 0.65 },
    { source: 'job_9', target: 'comp_2', weight: 0.88 },
    { source: 'job_9', target: 'comp_6', weight: 0.75 },
    { source: 'job_9', target: 'comp_14', weight: 0.72 },
    { source: 'job_9', target: 'comp_4', weight: 0.70 },
    { source: 'job_13', target: 'comp_16', weight: 0.95 },
    { source: 'job_13', target: 'comp_6', weight: 0.72 },
    { source: 'job_13', target: 'comp_14', weight: 0.68 },
    { source: 'job_13', target: 'comp_8', weight: 0.65 },
    { source: 'job_14', target: 'comp_7', weight: 0.85 },
    { source: 'job_14', target: 'comp_19', weight: 0.72 },
    { source: 'job_14', target: 'comp_1', weight: 0.60 },
    { source: 'job_14', target: 'comp_4', weight: 0.65 },
    { source: 'job_15', target: 'comp_11', weight: 0.92 },
    { source: 'job_15', target: 'comp_10', weight: 0.78 },
    { source: 'job_15', target: 'comp_21', weight: 0.82 },
    { source: 'comp_2', target: 'comp_1', weight: 0.35 },
    { source: 'comp_2', target: 'comp_9', weight: 0.60 },
    { source: 'comp_8', target: 'comp_15', weight: 0.30 },
    { source: 'comp_6', target: 'comp_14', weight: 0.75 },
  ]
}

async function loadData() {
  const apiOk = await loadFromApi()
  if (!apiOk) {
    loadDemo()
  }
}

function filterCommunity(key: string | null) {
  activeCommunity.value = activeCommunity.value === key ? null : key
}

function onNodeClick(node: any) {
  selectedNode.value = node
  drawerShow.value = true
}

function goDetail() {
  if (!selectedNode.value) return
  const id = selectedNode.value.id
  const type = selectedNode.value.type
  if (type === 'job') {
    router.push(`/graph/job/${id.replace('job_', '')}`)
  } else {
    router.push(`/graph/competency/${id.replace('comp_', '')}`)
  }
  drawerShow.value = false
}

function doSearch() {
  // keyword filtering is reactive via computed
}

function resetGraph() {
  activeCommunity.value = null
  keyword.value = ''
}

function findPath() {
  // Simple demo path — in production would call an API
  const from = allNodes.value.find(n => n.id == pathFrom.value)
  const to = allNodes.value.find(n => n.id == pathTo.value)
  if (from && to) {
    pathResult.value = [from, { id: 'bridge', label: 'Python', type: 'competency' }, to]
  }
}

onMounted(() => { loadData() })
</script>

<style scoped>
.graph-explore { display: flex; flex-direction: column; height: calc(100vh - 120px); }
.graph-layout { display: flex; gap: 16px; flex: 1; min-height: 0; }
.graph-sidebar { width: 300px; flex-shrink: 0; overflow-y: auto; }
.graph-main { flex: 1; min-width: 0; }

.community-filters { display: flex; gap: 6px; flex-wrap: wrap; }
.comm-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 4px; }

.stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.stat-item { text-align: center; padding: 8px; background: rgba(255,255,255,0.02); border-radius: 8px; }
.stat-num { display: block; font-size: 18px; font-weight: 700; color: #EFF2F5; font-family: 'SF Mono','Consolas',monospace; }
.stat-lbl { font-size: 11px; color: #7A92A8; }

.comm-list { display: flex; flex-direction: column; gap: 6px; }
.comm-row { display: flex; align-items: center; gap: 8px; padding: 6px 8px; border-radius: 6px; cursor: pointer; transition: all 0.2s; }
.comm-row:hover, .comm-row.active { background: rgba(0,242,255,0.06); }
.comm-name { flex: 1; font-size: 12px; color: #B8E8FF; }
.comm-count { font-size: 12px; font-weight: 600; color: #7A92A8; }

.path-result { display: flex; align-items: center; flex-wrap: wrap; gap: 4px; }
.path-arrow { color: #7A92A8; font-size: 12px; margin: 0 2px; }
</style>

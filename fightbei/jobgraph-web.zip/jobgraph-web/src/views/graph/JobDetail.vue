<template>
  <div>
    <n-page-header @back="() => $router.back()">
      <template #title>岗位详情</template>
    </n-page-header>
    <n-grid :cols="2" :x-gap="16" style="margin-top: 16px">
      <n-grid-item>
        <div class="panel-card">
          <div class="panel-header">
            <span class="panel-title">基本信息</span>
          </div>
          <n-descriptions :column="1" bordered size="small">
            <n-descriptions-item label="岗位名称">Java开发工程师</n-descriptions-item>
            <n-descriptions-item label="所属行业">互联网/IT</n-descriptions-item>
            <n-descriptions-item label="平均薪资">20K-35K</n-descriptions-item>
            <n-descriptions-item label="需求量">2,847</n-descriptions-item>
            <n-descriptions-item label="趋势"><n-tag type="success">上升 ↑</n-tag></n-descriptions-item>
          </n-descriptions>
        </div>
      </n-grid-item>
      <n-grid-item>
        <div class="panel-card">
          <div class="panel-header">
            <span class="panel-title">能力要求</span>
          </div>
          <RadarChart :data="radarData" :height="300" />
        </div>
      </n-grid-item>
    </n-grid>
    <div class="panel-card" style="margin-top: 16px">
      <div class="panel-header">
        <span class="panel-title">关联能力</span>
      </div>
      <n-space>
        <n-tag v-for="skill in skills" :key="skill.name" :type="skill.level === '必须' ? 'error' : 'info'" size="medium">
          {{ skill.name }} ({{ skill.score }}%)
        </n-tag>
      </n-space>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import RadarChart from '@/components/charts/RadarChart.vue'

const radarData = ref([
  { name: 'Java', value: 95, max: 100 },
  { name: 'SpringBoot', value: 90, max: 100 },
  { name: 'MySQL', value: 85, max: 100 },
  { name: 'Linux', value: 78, max: 100 },
  { name: 'Docker', value: 70, max: 100 },
  { name: '分布式', value: 65, max: 100 },
])

const skills = ref([
  { name: 'Java', score: 95, level: '必须' },
  { name: 'SpringBoot', score: 90, level: '必须' },
  { name: 'MySQL', score: 85, level: '必须' },
  { name: 'Linux', score: 78, level: '必须' },
  { name: 'Docker', score: 70, level: '加分' },
  { name: 'Redis', score: 68, level: '加分' },
  { name: 'Kubernetes', score: 55, level: '优先' },
  { name: 'Elasticsearch', score: 50, level: '优先' },
])
</script>

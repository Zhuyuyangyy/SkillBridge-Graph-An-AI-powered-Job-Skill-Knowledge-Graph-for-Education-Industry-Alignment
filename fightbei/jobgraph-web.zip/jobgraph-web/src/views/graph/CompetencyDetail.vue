<template>
  <div>
    <n-page-header @back="() => $router.back()">
      <template #title>能力详情</template>
    </n-page-header>
    <n-grid :cols="2" :x-gap="16" style="margin-top: 16px">
      <n-grid-item>
        <div class="panel-card">
          <div class="panel-header">
            <span class="panel-title">基本信息</span>
          </div>
          <n-descriptions :column="1" bordered size="small">
            <n-descriptions-item label="能力名称">Python</n-descriptions-item>
            <n-descriptions-item label="类别">硬技能</n-descriptions-item>
            <n-descriptions-item label="热度指数">95</n-descriptions-item>
            <n-descriptions-item label="提及次数">12,847</n-descriptions-item>
          </n-descriptions>
        </div>
      </n-grid-item>
      <n-grid-item>
        <div class="panel-card">
          <div class="panel-header">
            <span class="panel-title">需求趋势</span>
          </div>
          <div ref="trendRef" style="height: 280px"></div>
        </div>
      </n-grid-item>
    </n-grid>
    <div class="panel-card" style="margin-top: 16px">
      <div class="panel-header">
        <span class="panel-title">关联岗位</span>
      </div>
      <div class="panel-table">
        <n-table :data="relatedJobs" :columns="columns" size="small" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, h, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { NButton } from 'naive-ui'
import * as echarts from 'echarts'

const router = useRouter()
const trendRef = ref<HTMLDivElement>()

const columns = [
  { title: '岗位名称', key: 'name' },
  { title: '关联度', key: 'score' },
  { title: '要求级别', key: 'level' },
  {
    title: '操作', key: 'actions',
    render: (row: any) => h(NButton, { size: 'small', onClick: () => router.push(`/graph/job/${row.id}`) }, { default: () => '查看' }),
  },
]

const relatedJobs = ref([
  { id: 1, name: 'Python开发工程师', score: '95%', level: '必须' },
  { id: 2, name: '数据分析师', score: '92%', level: '必须' },
  { id: 3, name: '算法工程师', score: '88%', level: '必须' },
  { id: 4, name: '数据工程师', score: '82%', level: '加分' },
  { id: 5, name: '后端开发工程师', score: '65%', level: '加分' },
])

onMounted(() => {
  if (trendRef.value) {
    const chart = echarts.init(trendRef.value)
    chart.setOption({
      tooltip: { trigger: 'axis' },
      xAxis: { type: 'category', data: ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'] },
      yAxis: { type: 'value', name: '需求量' },
      series: [{ type: 'line', smooth: true, data: [480,520,580,620,680,720,780,820,860,900,930,950],
        areaStyle: { color: 'rgba(24,144,255,0.15)' } }],
    })
  }
})
</script>

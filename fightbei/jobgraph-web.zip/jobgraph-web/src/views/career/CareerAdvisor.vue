<template>
  <div class="career-page">
    <!-- 输入区 -->
    <div class="chart-card" style="margin-bottom: 20px">
      <div class="chart-header">
        <span class="chart-title">🤖 AI 职业路径规划</span>
        <span class="chart-badge pulse">创新功能</span>
      </div>
      <p style="color: #A5F3FC; font-size: 13px; margin-bottom: 16px">
        输入你的技能、经历或职业目标，AI 将为你推荐最匹配的岗位，并分析你的能力缺口，制定个性化学习路径。
      </p>
      <n-input
        v-model:value="description"
        type="textarea"
        placeholder="例如：我熟悉 Python 和数据分析，做过几个爬虫项目，想往 AI 方向发展..."
        :autosize="{ minRows: 3, maxRows: 5 }"
        round
        style="margin-bottom: 12px"
        @keyup.enter="handleAnalyze"
      />
      <n-space>
        <n-button type="primary" size="large" @click="handleAnalyze" :loading="loading" round>
          <template #icon>
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
          </template>
          智能分析
        </n-button>
        <n-button size="large" @click="handleQuickDemo" round>快速演示</n-button>
        <n-text depth="3" style="font-size: 12px; align-self: center">
          支持自然语言描述，AI 自动提取技能关键词
        </n-text>
      </n-space>
    </div>

    <!-- 结果区 -->
    <div v-if="result">
      <!-- 提取的技能 -->
      <div class="chart-card" style="margin-bottom: 20px" v-if="result.userSkills?.length">
        <div class="chart-header">
          <span class="chart-title">🧠 AI 识别技能</span>
          <n-tag type="info" size="small">{{ result.skillCount }} 项技能</n-tag>
        </div>
        <n-space>
          <n-tag v-for="s in result.userSkills" :key="s" type="info" size="medium" round :bordered="false">
            {{ s }}
          </n-tag>
        </n-space>
      </div>

      <!-- 岗位推荐 -->
      <n-grid :cols="2" :x-gap="16" style="margin-bottom: 20px">
        <n-grid-item>
          <div class="chart-card">
            <div class="chart-header">
              <span class="chart-title">🎯 岗位匹配推荐</span>
              <span class="chart-badge">Top 5</span>
            </div>
            <div class="job-list">
              <div v-for="(job, i) in result.topJobs" :key="job.jobName" class="job-item">
                <div class="job-rank" :class="'jr-' + (i + 1)">{{ i + 1 }}</div>
                <div class="job-info">
                  <div class="job-name">{{ job.jobName }}</div>
                  <div class="job-meta">
                    <span>{{ job.industry }}</span>
                    <span class="job-salary">{{ job.salaryRange }}</span>
                  </div>
                  <n-progress type="line" :percentage="job.matchRate" :height="6"
                    :color="i === 0 ? '#00F2FF' : i === 1 ? '#0055FF' : '#2979FF'"
                    :rail-color="'rgba(255,255,255,0.04)'" />
                  <div class="job-tags">
                    <n-tag v-for="s in job.masteredSkills" :key="s" size="tiny" :bordered="false" type="success">✓ {{ s }}</n-tag>
                    <n-tag v-for="s in job.missingSkills.slice(0,4)" :key="s" size="tiny" :bordered="false" type="error">✗ {{ s }}</n-tag>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </n-grid-item>

        <!-- 技能缺口 -->
        <n-grid-item>
          <div class="chart-card">
            <div class="chart-header">
              <span class="chart-title">⚡ 能力缺口分析</span>
              <span class="chart-badge">优先补缺</span>
            </div>
            <div class="gap-list">
              <div v-for="gap in result.gapAnalysis" :key="gap.name" class="gap-item">
                <div class="gap-header">
                  <span class="gap-name">{{ gap.name }}</span>
                  <n-tag size="tiny" type="warning">{{ gap.demandCount }}个岗位需要</n-tag>
                </div>
                <div class="gap-related">
                  <span class="gap-label">关联技能：</span>
                  <n-tag v-for="r in gap.relatedSkills" :key="r" size="tiny" :bordered="false" type="info">{{ r }}</n-tag>
                </div>
              </div>
            </div>
          </div>
        </n-grid-item>
      </n-grid>

      <!-- 学习路径 -->
      <div class="chart-card">
        <div class="chart-header">
          <span class="chart-title">📖 个性化学习路径</span>
          <span class="chart-badge pulse">AI生成</span>
        </div>
        <div class="learn-path">
          <div v-for="(line, i) in result.learningPath" :key="i" class="lp-line"
            :class="{ 'lp-phase': line.startsWith('🔍') || line.startsWith('📚') || line.startsWith('🚀') || line.startsWith('📋'),
                       'lp-item': line.startsWith('-') }">
            {{ line }}
          </div>
        </div>
      </div>
    </div>

    <!-- 空状态 -->
    <div v-else class="chart-card" style="text-align: center; padding: 60px 20px">
      <svg viewBox="0 0 120 120" width="80" height="80" style="opacity: 0.3; margin-bottom: 16px">
        <circle cx="60" cy="60" r="50" fill="none" stroke="#00F2FF" stroke-width="2" stroke-dasharray="8 6"/>
        <circle cx="60" cy="60" r="30" fill="none" stroke="#0055FF" stroke-width="1.5"/>
        <circle cx="60" cy="45" r="6" fill="#00F2FF"/>
        <circle cx="45" cy="70" r="5" fill="#0055FF"/>
        <circle cx="75" cy="70" r="5" fill="#00F2FF"/>
        <line x1="60" y1="51" x2="60" y2="59" stroke="#00F2FF" stroke-width="1.5"/>
        <line x1="51" y1="68" x2="59" y2="64" stroke="#00F2FF" stroke-width="1"/>
        <line x1="69" y1="68" x2="62" y2="64" stroke="#00F2FF" stroke-width="1"/>
      </svg>
      <p style="color: #A5F3FC; font-size: 16px; margin-bottom: 8px">输入你的技能描述</p>
      <p style="color: #6B8090; font-size: 13px">AI 将自动分析并推荐最适合你的职业路径</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { getCareerAdvice } from '@/api/career'

const description = ref('')
const loading = ref(false)
const result = ref<any>(null)

async function handleAnalyze() {
  if (!description.value.trim()) {
    window.$message?.warning('请输入你的技能描述')
    return
  }
  loading.value = true
  try {
    result.value = await getCareerAdvice(description.value)
    window.$message?.success('分析完成！')
  } catch (e) {
    window.$message?.error('分析失败，请稍后重试')
  }
  finally { loading.value = false }
}

function handleQuickDemo() {
  result.value = {
    userSkills: ['Python', '数据分析', 'Pandas', 'SQL', '机器学习基础'],
    skillCount: 5,
    topJobs: [
      { jobName: '数据分析师', industry: '互联网/IT', salaryRange: '15K-28K', matchRate: 85.7,
        masteredSkills: ['Python', 'SQL', '数据分析', 'Pandas'],
        missingSkills: ['NumPy', '统计学', '沟通能力'], compositeScore: 80.5 },
      { jobName: '算法工程师', industry: '互联网/IT', salaryRange: '25K-45K', matchRate: 62.5,
        masteredSkills: ['Python', '机器学习'],
        missingSkills: ['深度学习', 'PyTorch', 'TensorFlow', '算法'], compositeScore: 65.2 },
      { jobName: '数据工程师', industry: '互联网/IT', salaryRange: '20K-38K', matchRate: 55.6,
        masteredSkills: ['Python', 'SQL'],
        missingSkills: ['Spark', 'Flink', 'Kafka', 'Hadoop', 'Docker'], compositeScore: 58.3 },
      { jobName: 'Python开发工程师', industry: '互联网/IT', salaryRange: '18K-32K', matchRate: 50.0,
        masteredSkills: ['Python'],
        missingSkills: ['Django', 'MySQL', 'Linux', 'Docker', '数据分析'], compositeScore: 52.1 },
      { jobName: 'AI提示词工程师', industry: '互联网/IT', salaryRange: '20K-40K', matchRate: 42.9,
        masteredSkills: ['Python'],
        missingSkills: ['LLM', 'Prompt Engineering', 'NLP', '对话系统'], compositeScore: 48.6 },
    ],
    gapAnalysis: [
      { name: '深度学习', demandCount: 3, relatedSkills: ['机器学习', 'PyTorch', 'TensorFlow'] },
      { name: '统计学', demandCount: 2, relatedSkills: ['数据分析', '数学', '概率论'] },
      { name: 'NumPy', demandCount: 2, relatedSkills: ['Pandas', '数据分析', '科学计算'] },
      { name: 'Docker', demandCount: 2, relatedSkills: ['Kubernetes', 'Linux', 'DevOps'] },
      { name: '沟通能力', demandCount: 1, relatedSkills: ['项目管理', '需求分析', '团队协作'] },
    ],
    learningPath: [
      '🔍 第一阶段：巩固基础 (1-2周)', '- 检查当前技能Python、数据分析、SQL的掌握程度', '',
      '📚 第二阶段：核心技能学习 (3-6周)', '- 深度学习：推荐 Andrew Ng 深度学习专项课程 + Kaggle实战', '- 统计学：推荐《统计学习方法》+ 可汗学院统计学', '- NumPy：推荐官方文档 + 100 Numpy Exercises', '',
      '🚀 第三阶段：实战提升 (2-4周)', '- 完成一个端到端的ML项目（数据清洗→特征工程→模型训练→部署）', '- 参与Kaggle竞赛积累项目经验', '',
      '📋 第四阶段：持续跟踪', '- 关注算法工程师/数据工程师JD变化，动态调整学习方向'
    ],
  }
  window.$message?.success('演示数据已加载')
}
</script>

<style scoped>
.career-page { position: relative; z-index: 1; }

.chart-card {
  background: rgba(15, 32, 55, 0.78); border: 1px solid rgba(0, 242, 255, 0.12);
  border-radius: 12px; padding: 20px;
  backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 0 15px rgba(0, 242, 255, 0.08);
}
.chart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.chart-title { font-size: 15px; font-weight: 600; color: #E8EDF1; }
.chart-badge { font-size: 11px; color: #6B8090; padding: 3px 10px; border: 1px solid rgba(255,255,255,0.08); border-radius: 20px; }
.chart-badge.pulse { border-color: rgba(0,242,255,0.35); color: #00F2FF; animation: glow-pulse 2s ease-in-out infinite; }

/* Job list */
.job-list { display: flex; flex-direction: column; gap: 12px; }
.job-item { display: flex; gap: 12px; padding: 12px; background: rgba(255,255,255,0.02); border-radius: 10px; border: 1px solid rgba(255,255,255,0.04); }
.job-rank { width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 700; flex-shrink: 0; color: #6B8090; background: rgba(255,255,255,0.05); }
.jr-1 { background: linear-gradient(135deg, #00F2FF, #0055FF); color: #000; }
.jr-2 { background: linear-gradient(135deg, #0055FF, #7C4DFF); color: #fff; }
.jr-3 { background: linear-gradient(135deg, #2979FF, #00C8D4); color: #fff; }
.job-info { flex: 1; min-width: 0; }
.job-name { font-size: 14px; font-weight: 600; color: #E8EDF1; margin-bottom: 2px; }
.job-meta { font-size: 11px; color: #6B8090; margin-bottom: 6px; display: flex; gap: 8px; }
.job-salary { color: #00E676; font-family: 'SF Mono', 'Consolas', monospace; }
.job-tags { margin-top: 8px; display: flex; flex-wrap: wrap; gap: 4px; }

/* Gap list */
.gap-list { display: flex; flex-direction: column; gap: 14px; }
.gap-item { padding: 12px; background: rgba(255,255,255,0.02); border-radius: 10px; border: 1px solid rgba(255,255,255,0.04); }
.gap-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
.gap-name { font-size: 14px; font-weight: 600; color: #E8EDF1; }
.gap-related { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.gap-label { font-size: 11px; color: #6B8090; }

/* Learning path */
.learn-path { font-size: 13px; line-height: 2; color: #B0BEC5; }
.lp-phase { font-size: 15px; font-weight: 700; color: #00F2FF; margin-top: 8px; }
.lp-item { padding-left: 8px; color: #A5F3FC; }
</style>

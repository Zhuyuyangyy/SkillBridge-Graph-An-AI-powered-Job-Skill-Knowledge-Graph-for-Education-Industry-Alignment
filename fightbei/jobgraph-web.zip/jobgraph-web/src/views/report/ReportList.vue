<template>
  <div>
    <div class="panel-toolbar">
      <n-button type="primary" @click="$router.push('/match/report')" round>
        <template #icon>
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        </template>
        新建报告
      </n-button>
    </div>

    <div class="panel-card panel-table" v-if="list.length">
      <div class="panel-header"><span class="panel-title">报告存档列表</span><span class="panel-badge">{{ pagination.itemCount }} 份</span></div>
      <n-data-table :columns="columns" :data="list" size="small" :bordered="false" :pagination="pagination" />
    </div>

    <div v-else class="panel-card" style="text-align: center; padding: 60px 20px">
      <svg viewBox="0 0 120 120" width="80" height="80" style="opacity: 0.3; margin-bottom: 16px">
        <rect x="16" y="20" width="88" height="80" rx="6" fill="none" stroke="#00F2FF" stroke-width="2"/>
        <line x1="36" y1="40" x2="84" y2="40" stroke="#0055FF" stroke-width="2" opacity="0.5"/>
        <line x1="36" y1="56" x2="72" y2="56" stroke="#0055FF" stroke-width="2" opacity="0.4"/>
        <line x1="36" y1="72" x2="78" y2="72" stroke="#0055FF" stroke-width="2" opacity="0.3"/>
      </svg>
      <p style="color: #B8E8FF; font-size: 16px; margin-bottom: 8px">暂无报告</p>
      <p style="color: #7A92A8; font-size: 13px; margin-bottom: 16px">生成的报告将保存在此处，方便随时查看和下载</p>
      <n-button type="primary" @click="$router.push('/match/report')" round>去生成第一份报告</n-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, h, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { NButton, NTag } from 'naive-ui'
import { getReportList } from '@/api/report'

const router = useRouter()
const list = ref<any[]>([])
const pagination = reactive({ page: 1, pageSize: 10, itemCount: 0 })

const columns = [
  { title: '报告类型', key: 'reportType', render: (row: any) => {
    const labels: Record<string, string> = { MATCH_ANALYSIS: '产教匹配分析', JOB_ANALYSIS: '岗位趋势分析', COMPETENCY_TREND: '能力趋势分析' }
    return h(NTag, { type: 'info', size: 'small', bordered: false }, { default: () => labels[row.reportType] || row.reportType })
  }},
  { title: '生成时间', key: 'createTime' },
  { title: '操作', key: 'actions', render: (row: any) =>
    h('div', { style: 'display:flex;gap:8px' }, [
      h(NButton, { size: 'tiny', onClick: () => preview(row) }, { default: () => '预览' }),
      h(NButton, { size: 'tiny', type: 'primary', onClick: () => download(row) }, { default: () => '下载' }),
    ])
  },
]

async function load() {
  try {
    const res: any = await getReportList({ pageNum: pagination.page, pageSize: pagination.pageSize })
    if (res?.records) { list.value = res.records; pagination.itemCount = res.total || 0 }
  } catch { /* empty */ }
}

function preview(row: any) { router.push(`/report/${row.id}`) }
function download(row: any) { window.$message?.info('PDF下载链接: ' + (row.fileUrl || '生成中...')) }

onMounted(load)
</script>

<template>
  <div>
    <div class="panel-toolbar">
      <n-button @click="$router.back()" round>← 返回</n-button>
    </div>
    <div class="panel-card" style="text-align: center; padding: 60px 20px">
      <svg viewBox="0 0 120 120" width="100" height="100" style="margin-bottom: 20px; opacity: 0.6">
        <rect x="20" y="10" width="80" height="100" rx="8" fill="none" stroke="#00F2FF" stroke-width="2.5"/>
        <rect x="34" y="34" width="52" height="10" rx="2" fill="#00F2FF" opacity="0.4"/>
        <rect x="34" y="52" width="40" height="6" rx="2" fill="#0055FF" opacity="0.3"/>
        <rect x="34" y="64" width="48" height="6" rx="2" fill="#0055FF" opacity="0.3"/>
        <rect x="34" y="76" width="36" height="6" rx="2" fill="#0055FF" opacity="0.25"/>
      </svg>
      <p style="color: #B8E8FF; font-size: 16px; margin-bottom: 8px">报告已生成</p>
      <p style="color: #7A92A8; font-size: 13px; margin-bottom: 24px">产教匹配分析报告</p>
      <n-space justify="center">
        <n-button type="primary" size="large" round @click="handleDownload">📥 下载 PDF</n-button>
        <n-button size="large" round @click="$router.back()">返回列表</n-button>
      </n-space>
    </div>
  </div>
</template>

<script setup lang="ts">
function handleDownload() {
  window.$message?.success('正在下载报告...')
}
</script>

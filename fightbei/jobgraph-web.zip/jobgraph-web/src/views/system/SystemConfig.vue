<template>
  <div class="panel-card">
    <div class="panel-header">
      <div class="panel-title">系统配置</div>
    </div>
    <n-form label-placement="left" label-width="120">
      <n-form-item label="采集间隔(分)"><n-input-number v-model:value="config.interval" /></n-form-item>
      <n-form-item label="新兴岗位阈值"><n-input-number v-model:value="config.emergingThreshold" /></n-form-item>
      <n-form-item label="数据保留天数"><n-input-number v-model:value="config.retainDays" /></n-form-item>
      <n-button type="primary" @click="save">保存配置</n-button>
    </n-form>
  </div>
</template>

<script setup lang="ts">
import { reactive } from 'vue'
const config = reactive({ interval: 360, emergingThreshold: 50, retainDays: 365 })
function save() { window.$message?.success('配置已保存') }
</script>

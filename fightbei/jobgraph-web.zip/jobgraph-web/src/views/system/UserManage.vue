<template>
  <div class="panel-card panel-table">
    <div class="panel-header">
      <div class="panel-title">用户管理</div>
    </div>
    <n-data-table :columns="columns" :data="list" :pagination="pagination" />
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'

const list = ref([
  { id: 1, username: 'admin', realName: '系统管理员', role: 'ADMIN', createTime: '2024-01-01' },
  { id: 2, username: 'teacher1', realName: '张老师', role: 'TEACHER', createTime: '2024-03-15' },
  { id: 3, username: 'student1', realName: '李同学', role: 'STUDENT', createTime: '2024-05-20' },
])

const pagination = reactive({ page: 1, pageSize: 10, itemCount: 3 })
const columns = [
  { title: '用户名', key: 'username' },
  { title: '姓名', key: 'realName' },
  { title: '角色', key: 'role' },
  { title: '注册时间', key: 'createTime' },
]
</script>

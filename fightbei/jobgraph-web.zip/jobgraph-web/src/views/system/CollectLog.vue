<template>
  <div class="panel-card panel-table">
    <div class="panel-header">
      <div class="panel-title">采集日志</div>
    </div>
    <n-data-table :columns="columns" :data="list" :pagination="pagination" />
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'

const list = ref([
  { id: 1, sourceName: 'BOSS直聘-北京', taskType: '定时采集', status: 'SUCCESS', message: '采集180条数据', startTime: '2024-06-15 08:00', endTime: '2024-06-15 08:15' },
  { id: 2, sourceName: '智联招聘-上海', taskType: '定时采集', status: 'SUCCESS', message: '采集142条数据', startTime: '2024-06-15 08:00', endTime: '2024-06-15 08:12' },
  { id: 3, sourceName: '人社部API', taskType: 'API同步', status: 'FAILED', message: '连接超时', startTime: '2024-06-15 06:00', endTime: '2024-06-15 06:01' },
])

const pagination = reactive({ page: 1, pageSize: 10, itemCount: 3 })
const columns = [
  { title: '数据源', key: 'sourceName' },
  { title: '任务类型', key: 'taskType' },
  { title: '状态', key: 'status', render: (row: any) => row.status === 'SUCCESS' ? '✅ 成功' : '❌ 失败' },
  { title: '信息', key: 'message' },
  { title: '耗时', key: 'startTime' },
]
</script>

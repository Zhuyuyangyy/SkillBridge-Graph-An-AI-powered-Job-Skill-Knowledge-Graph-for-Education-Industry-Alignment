<template>
  <div>
    <div class="panel-toolbar">
      <n-input v-model:value="school" placeholder="学校" style="width: 140px" />
      <n-input v-model:value="major" placeholder="专业" style="width: 140px" />
      <n-button type="primary" @click="load">分析</n-button>
      <n-button @click="handleGenerate">生成报告</n-button>
    </div>
    <n-grid :cols="3" :x-gap="16">
      <n-grid-item>
        <div class="panel-card">
          <n-statistic label="课程覆盖率" :value="data.coverage || 0"><template #suffix>%</template></n-statistic>
        </div>
      </n-grid-item>
      <n-grid-item>
        <div class="panel-card">
          <n-statistic label="市场技能数" :value="data.marketSkillCount || 0" />
        </div>
      </n-grid-item>
      <n-grid-item>
        <div class="panel-card">
          <n-statistic label="课程覆盖数" :value="data.courseSkillCount || 0" />
        </div>
      </n-grid-item>
    </n-grid>
    <div class="panel-card" style="margin-top: 16px">
      <div class="panel-header">
        <span class="panel-title">技能缺口清单</span>
      </div>
      <div class="panel-table">
        <n-table :data="data.gaps || []" :columns="gapColumns" size="small" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { getGapAnalysis } from '@/api/match'

const router = useRouter()
const school = ref('')
const major = ref('')
const data = reactive<any>({ coverage: 0, gaps: [] })

const gapColumns = [
  { title: '技能名称', key: 'name' },
  { title: '市场需求热度', key: 'demand' },
  { title: '覆盖状态', key: 'covered', render: (row: any) => row.covered ? '已覆盖' : '未覆盖' },
]

async function load() {
  try { Object.assign(data, await getGapAnalysis({ school: school.value, major: major.value })) } catch { /* */ }
}

function handleGenerate() { router.push('/match/report') }
load()
</script>

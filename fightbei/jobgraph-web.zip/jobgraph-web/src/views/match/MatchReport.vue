<template>
  <div>
    <div class="panel-card" style="margin-bottom: 20px">
      <div class="panel-header">
        <span class="panel-title">📋 生成产教匹配报告</span>
        <span class="panel-badge live">实时分析</span>
      </div>
      <p style="color: #B8E8FF; font-size: 13px; margin-bottom: 16px">
        配置学校和专业参数，系统将自动分析市场需求与课程培养方案的匹配度，并生成PDF报告。
      </p>
      <n-grid :cols="3" :x-gap="12">
        <n-grid-item>
          <n-form-item label="学校" label-placement="top">
            <n-input v-model:value="form.school" placeholder="安徽中医药大学" />
          </n-form-item>
        </n-grid-item>
        <n-grid-item>
          <n-form-item label="专业" label-placement="top">
            <n-input v-model:value="form.major" placeholder="留空分析全部专业" />
          </n-form-item>
        </n-grid-item>
        <n-grid-item>
          <n-form-item label="报告类型" label-placement="top">
            <n-select v-model:value="form.reportType" :options="[
              {label:'产教匹配分析',value:'MATCH_ANALYSIS'},
              {label:'岗位趋势分析',value:'JOB_ANALYSIS'},
              {label:'能力趋势分析',value:'COMPETENCY_TREND'}
            ]" />
          </n-form-item>
        </n-grid-item>
      </n-grid>
      <n-button type="primary" size="large" :loading="loading" @click="handleGenerate" round style="margin-top: 8px">
        <template #icon>
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
        </template>
        生成分析报告
      </n-button>
    </div>

    <!-- 分析结果预览 -->
    <div v-if="analysisResult" class="fade-in">
      <!-- 概览卡片 -->
      <n-grid :cols="3" :x-gap="16" style="margin-bottom: 20px">
        <n-grid-item>
          <div class="panel-card" style="text-align: center">
            <div class="panel-header" style="justify-content: center"><span class="panel-title">综合匹配度</span></div>
            <n-statistic :value="analysisResult.overallMatch || analysisResult.coverage || 0">
              <template #suffix>%</template>
            </n-statistic>
            <n-progress type="line" :percentage="analysisResult.overallMatch || analysisResult.coverage || 0" :height="8" />
          </div>
        </n-grid-item>
        <n-grid-item>
          <div class="panel-card" style="text-align: center">
            <div class="panel-header" style="justify-content: center"><span class="panel-title">市场技能需求</span></div>
            <n-statistic :value="analysisResult.marketSkillCount || 0"><template #suffix>项</template></n-statistic>
          </div>
        </n-grid-item>
        <n-grid-item>
          <div class="panel-card" style="text-align: center">
            <div class="panel-header" style="justify-content: center"><span class="panel-title">课程覆盖技能</span></div>
            <n-statistic :value="analysisResult.courseSkillCount || 0"><template #suffix>项</template></n-statistic>
          </div>
        </n-grid-item>
      </n-grid>

      <!-- 技能缺口表格 -->
      <div class="panel-card panel-table" style="margin-bottom: 20px">
        <div class="panel-header"><span class="panel-title">技能缺口清单</span><span class="panel-badge">共 {{ analysisResult.gaps?.length || 0 }} 项</span></div>
        <n-data-table :columns="gapColumns" :data="analysisResult.gaps || []" size="small" :bordered="false" />
      </div>

      <!-- 操作按钮 -->
      <div class="panel-card" style="text-align: center">
        <n-space justify="center">
          <n-button type="primary" size="large" @click="downloadReport" round>
            📥 下载 PDF 报告
          </n-button>
          <n-button size="large" @click="saveReport" round>
            💾 保存到报告中心
          </n-button>
        </n-space>
      </div>
    </div>

    <!-- 空状态 -->
    <div v-else class="panel-card" style="text-align: center; padding: 60px 20px">
      <svg viewBox="0 0 120 120" width="80" height="80" style="opacity: 0.3; margin-bottom: 16px">
        <rect x="20" y="10" width="80" height="100" rx="6" fill="none" stroke="#00F2FF" stroke-width="2"/>
        <rect x="30" y="30" width="60" height="8" rx="2" fill="#00F2FF" opacity="0.3"/>
        <rect x="30" y="48" width="45" height="6" rx="2" fill="#0055FF" opacity="0.3"/>
        <rect x="30" y="62" width="55" height="6" rx="2" fill="#0055FF" opacity="0.3"/>
        <circle cx="90" cy="90" r="18" fill="none" stroke="#00F2FF" stroke-width="2"/>
        <polygon points="85,82 85,98 98,90" fill="#00F2FF" opacity="0.6"/>
      </svg>
      <p style="color: #B8E8FF; font-size: 16px; margin-bottom: 8px">配置参数并生成报告</p>
      <p style="color: #7A92A8; font-size: 13px">系统将自动分析产教匹配度，生成详细PDF报告</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, h } from 'vue'
import { NTag } from 'naive-ui'
import { runMatchAnalysis } from '@/api/match'

const loading = ref(false)
const analysisResult = ref<any>(null)

const form = reactive({ school: '安徽中医药大学', major: '', reportType: 'MATCH_ANALYSIS' })

const gapColumns = [
  { title: '技能名称', key: 'name' },
  { title: '市场需求度', key: 'demand' },
  { title: '覆盖状态', key: 'covered', render: (row: any) =>
    h(NTag, { type: row.covered ? 'success' : 'error', size: 'small', bordered: false },
      { default: () => row.covered ? '已覆盖' : '未覆盖' }) },
]

async function handleGenerate() {
  loading.value = true
  try {
    // 调用真实API
    analysisResult.value = await runMatchAnalysis(form)
    window.$message?.success('分析完成！')
  } catch {
    // 兜底静态展示数据
    analysisResult.value = {
      overallMatch: 72.5,
      marketSkillCount: 13,
      courseSkillCount: 6,
      coverage: 46.2,
      gaps: [
        { name: '机器学习', demand: 88, covered: false },
        { name: 'Docker', demand: 85, covered: false },
        { name: 'Kubernetes', demand: 78, covered: false },
        { name: '云计算', demand: 76, covered: false },
        { name: 'SpringBoot', demand: 74, covered: false },
        { name: 'Vue/React', demand: 72, covered: false },
        { name: 'Git', demand: 70, covered: false },
        { name: 'Python', demand: 95, covered: true },
        { name: 'Java', demand: 90, covered: true },
        { name: 'SQL', demand: 88, covered: true },
        { name: 'Linux', demand: 82, covered: true },
        { name: '数据分析', demand: 80, covered: true },
        { name: '沟通能力', demand: 72, covered: true },
      ],
      rankings: [
        { major: '计算机科学与技术', matchScore: 85.3, gapCount: 8 },
        { major: '数据科学与大数据技术', matchScore: 78.1, gapCount: 12 },
        { major: '人工智能', matchScore: 76.8, gapCount: 15 },
      ],
    }
  }
  finally { loading.value = false }
}

function downloadReport() {
  window.$message?.info('PDF报告已生成，请在报告中心查看下载')
}

function saveReport() {
  window.$message?.success('报告已保存到报告中心')
}
</script>

<style scoped>
.fade-in { animation: fadeUp 0.4s ease; }
@keyframes fadeUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
</style>

<template>
  <div>
    <div class="panel-toolbar">
      <n-input v-model:value="school" placeholder="学校" style="width: 160px" />
      <n-input v-model:value="major" placeholder="专业" style="width: 160px" />
      <n-button type="primary" @click="load">查询</n-button>
    </div>
    <div class="panel-card">
      <div class="panel-header">
        <span class="panel-title">整体匹配度</span>
      </div>
      <n-statistic label="产教综合匹配度" :value="overview.overallMatch || 0">
        <template #suffix>%</template>
      </n-statistic>
    </div>
    <div class="panel-card" style="margin-top: 16px">
      <div class="panel-header">
        <span class="panel-title">专业匹配度排行</span>
      </div>
      <div class="panel-table">
        <n-data-table :columns="rankColumns" :data="overview.rankings || []" :bordered="false" size="small" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, h } from 'vue'
import { NProgress } from 'naive-ui'
import { getMatchOverview } from '@/api/match'

const school = ref('')
const major = ref('')

const rankColumns = [
  { title: '专业', key: 'major' },
  { title: '匹配度', key: 'matchScore', render: (row: any) => h(NProgress, { type: 'line', percentage: row.matchScore, height: 20 }) },
  { title: '技能缺口', key: 'gapCount', render: (row: any) => row.gapCount + ' 项' },
]
const overview = reactive<any>({ overallMatch: 0, rankings: [] })

// 静态演示数据
const mockData = {
  school: '安徽中医药大学',
  overallMatch: 72.5,
  rankings: [
    { major: '计算机科学与技术', matchScore: 85.3, gapCount: 8 },
    { major: '数据科学与大数据技术', matchScore: 78.1, gapCount: 12 },
    { major: '人工智能', matchScore: 76.8, gapCount: 15 },
    { major: '软件工程', matchScore: 74.2, gapCount: 18 },
    { major: '信息管理与信息系统', matchScore: 68.5, gapCount: 22 },
    { major: '电子信息工程', matchScore: 63.7, gapCount: 26 },
    { major: '物联网工程', matchScore: 60.2, gapCount: 30 },
    { major: '通信工程', matchScore: 55.8, gapCount: 34 },
  ],
}

async function load() {
  try {
    const data = await getMatchOverview({ school: school.value, major: major.value })
    if (data && data.overallMatch) {
      Object.assign(overview, data)
      return
    }
  } catch { /* API 不可用时使用演示数据 */ }
  // 兜底：加载静态演示数据
  Object.assign(overview, mockData)
}
load()
</script>

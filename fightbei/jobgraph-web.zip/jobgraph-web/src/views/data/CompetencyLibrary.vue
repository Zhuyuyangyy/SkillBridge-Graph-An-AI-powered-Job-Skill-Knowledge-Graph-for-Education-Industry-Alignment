<template>
  <div>
    <div class="panel-toolbar">
      <n-input v-model:value="keyword" placeholder="搜索能力..." style="width: 240px" />
      <n-button type="primary" @click="load">搜索</n-button>
    </div>
    <div class="panel-card panel-table">
      <n-data-table :columns="columns" :data="list" :loading="loading" :pagination="pagination" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { getCompetencyList } from '@/api/data'

const keyword = ref('')
const loading = ref(false)
const list = ref<any[]>([])
const pagination = reactive({ page: 1, pageSize: 10, itemCount: 0 })

const columns = [
  { title: '能力名称', key: 'name' },
  { title: '类别', key: 'category' },
  { title: '提及次数', key: 'mentionCount' },
  { title: '权重', key: 'weight' },
]

async function load() {
  loading.value = true
  try {
    const res: any = await getCompetencyList({ pageNum: pagination.page, pageSize: pagination.pageSize, keyword: keyword.value })
    list.value = res.records || []
    pagination.itemCount = res.total || 0
  } catch { list.value = [
    { name: 'Python', category: '硬技能', mentionCount: 12847, weight: 0.95 },
    { name: '沟通能力', category: '软技能', mentionCount: 11000, weight: 0.90 },
    { name: '数据分析', category: '硬技能', mentionCount: 9800, weight: 0.88 },
    { name: 'Java', category: '硬技能', mentionCount: 9200, weight: 0.85 },
  ]}
  finally { loading.value = false }
}
load()
</script>

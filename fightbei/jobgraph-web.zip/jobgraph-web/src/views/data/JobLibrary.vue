<template>
  <div>
    <div class="panel-toolbar">
      <n-input v-model:value="keyword" placeholder="搜索岗位..." style="width: 240px" />
      <n-button type="primary" @click="load">搜索</n-button>
    </div>
    <div class="panel-card panel-table">
      <n-data-table :columns="columns" :data="list" :loading="loading" :pagination="pagination" @update:page="handlePage" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { getJobList } from '@/api/data'

const keyword = ref('')
const loading = ref(false)
const list = ref<any[]>([])
const pagination = reactive({ page: 1, pageSize: 10, itemCount: 0 })

const columns = [
  { title: '岗位名称', key: 'name' },
  { title: '行业', key: 'industry' },
  { title: '需求量', key: 'demandCount' },
  { title: '热度', key: 'hotScore' },
]

async function load() {
  loading.value = true
  try {
    const res: any = await getJobList({ pageNum: pagination.page, pageSize: pagination.pageSize, keyword: keyword.value })
    list.value = res.records || []
    pagination.itemCount = res.total || 0
  } catch { list.value = mockJobs }
  finally { loading.value = false }
}

function handlePage(p: number) { pagination.page = p; load() }

const mockJobs = [
  { name: 'Java开发工程师', industry: '互联网/IT', demandCount: 2847, hotScore: 95 },
  { name: '数据分析师', industry: '互联网/IT', demandCount: 1920, hotScore: 88 },
  { name: '前端开发工程师', industry: '互联网/IT', demandCount: 1680, hotScore: 82 },
  { name: '算法工程师', industry: '互联网/IT', demandCount: 1450, hotScore: 90 },
]
load()
</script>

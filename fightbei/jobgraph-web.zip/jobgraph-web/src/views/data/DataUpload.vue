<template>
  <div>
    <div class="panel-card">
      <div class="panel-header">
        <div class="panel-title">数据文件上传</div>
      </div>
      <n-upload multiple directory-dnd accept=".xlsx,.xls,.csv"
        :action="uploadUrl" :headers="uploadHeaders"
        @finish="handleFinish" @error="handleError">
        <n-upload-dragger>
          <n-text style="font-size: 16px">点击或拖拽文件到此区域上传</n-text>
          <n-text depth="3" style="margin-top: 8px">支持 .xlsx .xls .csv 格式</n-text>
        </n-upload-dragger>
      </n-upload>
    </div>
    <div class="panel-card" style="margin-top: 16px">
      <div class="panel-header">
        <div class="panel-title">上传模板说明</div>
      </div>
      <n-list>
        <n-list-item>岗位数据模板：包含 岗位名称、行业、薪资范围、JD文本等列</n-list-item>
        <n-list-item>培养方案模板：包含 课程名称、课程内容、覆盖能力等列</n-list-item>
      </n-list>
      <n-button type="primary" style="margin-top: 12px" @click="downloadTemplate">下载模板</n-button>
    </div>
  </div>
</template>

<script setup lang="ts">
const uploadUrl = '/api/data/upload'
const uploadHeaders = { Authorization: `Bearer ${localStorage.getItem('token')}` }

function handleFinish() { window.$message?.success('上传成功') }
function handleError() { window.$message?.error('上传失败') }
function downloadTemplate() { window.$message?.info('模板下载功能开发中') }
</script>

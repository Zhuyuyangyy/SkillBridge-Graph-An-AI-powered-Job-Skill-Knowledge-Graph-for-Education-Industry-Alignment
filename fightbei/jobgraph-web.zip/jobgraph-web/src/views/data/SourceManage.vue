<template>
  <div>
    <div class="panel-toolbar">
      <n-button type="primary" @click="showModal = true">新增数据源</n-button>
    </div>
    <div class="panel-card panel-table">
      <n-data-table :columns="columns" :data="list" :loading="loading" :pagination="pagination" />
    </div>
    <n-modal v-model:show="showModal" title="数据源">
      <n-card style="width: 500px">
        <n-form :model="form" label-placement="left" label-width="100">
          <n-form-item label="名称"><n-input v-model:value="form.name" /></n-form-item>
          <n-form-item label="类型">
            <n-select v-model:value="form.type" :options="[{label:'爬虫采集',value:'CRAWLER'},{label:'政府数据',value:'GOVERNMENT'},{label:'高校数据',value:'UNIVERSITY'},{label:'手动上传',value:'UPLOAD'}]" />
          </n-form-item>
          <n-form-item label="Cron表达式"><n-input v-model:value="form.cronExpr" placeholder="0 0 6 * * ?" /></n-form-item>
        </n-form>
        <n-button type="primary" block @click="handleSave">保存</n-button>
      </n-card>
    </n-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, h } from 'vue'
import { getDataSourceList, saveDataSource, deleteDataSource } from '@/api/data'

const loading = ref(false)
const showModal = ref(false)
const list = ref<any[]>([])
const pagination = reactive({ page: 1, pageSize: 10, itemCount: 0 })
const form = reactive({ name: '', type: 'CRAWLER', cronExpr: '' })

const columns = [
  { title: '名称', key: 'name' },
  { title: '类型', key: 'type' },
  { title: '状态', key: 'status' },
  { title: 'Cron', key: 'cronExpr' },
  { title: '操作', key: 'actions', render: (row: any) => h('button', { onClick: () => handleDelete(row.id) }, '删除') },
]

async function load() {
  try {
    const res: any = await getDataSourceList({ pageNum: pagination.page, pageSize: pagination.pageSize })
    list.value = res.records || []
    pagination.itemCount = res.total || 0
  } catch { /* */ }
}

async function handleSave() {
  try { await saveDataSource(form); showModal.value = false; load(); window.$message?.success('保存成功') } catch { /* */ }
}

async function handleDelete(id: number) {
  try { await deleteDataSource(id); load(); window.$message?.success('已删除') } catch { /* */ }
}

load()
</script>

<template>
  <div>
    <div class="panel-toolbar">
      <n-select v-model:value="months" :options="monthOpts" style="width: 120px" />
      <n-button type="primary" @click="load">加载</n-button>
    </div>
    <div class="panel-card">
      <div class="panel-header">
        <span class="panel-title">岗位需求时间轴演化</span>
      </div>
      <div ref="chartRef" style="height: 420px"></div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import * as echarts from 'echarts'
import { getTimeline } from '@/api/evolution'

const months = ref(12)
const monthOpts = [6, 12, 24].map(v => ({ label: `近${v}个月`, value: v }))
const chartRef = ref<HTMLDivElement>()

async function load() {
  if (!chartRef.value) return
  try {
    const data: any = await getTimeline({ months: months.value })
    const chart = echarts.init(chartRef.value)
    chart.setOption({
      tooltip: { trigger: 'axis' },
      legend: { bottom: 0 },
      grid: { left: 60, right: 20, top: 20, bottom: 40 },
      xAxis: { type: 'category', data: data.times },
      yAxis: { type: 'value' },
      series: (data.series || []).map((s: any) => ({ ...s, type: 'line', smooth: true })),
    })
  } catch { /* fallback */ }
}

onMounted(load)
</script>

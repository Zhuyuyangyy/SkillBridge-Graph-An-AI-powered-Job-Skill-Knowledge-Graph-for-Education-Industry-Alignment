<template>
  <div>
    <div class="panel-toolbar">
      <n-radio-group v-model:value="dimension">
        <n-radio-button value="industry">行业对比</n-radio-button>
        <n-radio-button value="region">区域对比</n-radio-button>
      </n-radio-group>
    </div>
    <div class="panel-card"><div ref="chartRef" style="height: 400px"></div></div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, onMounted } from 'vue'
import * as echarts from 'echarts'
import { compareByDimension } from '@/api/evolution'

const dimension = ref('industry')
const chartRef = ref<HTMLDivElement>()

async function render() {
  if (!chartRef.value) return
  try {
    const data: any = await compareByDimension(dimension.value)
    const chart = echarts.init(chartRef.value)
    chart.setOption({
      tooltip: { trigger: 'axis' },
      legend: { bottom: 0 },
      xAxis: { type: 'category', data: data.labels },
      yAxis: { type: 'value' },
      series: (data.series || []).map((s: any, i: number) => ({
        ...s, type: 'bar', barGap: '20%',
        itemStyle: { borderRadius: i === 0 ? [4,4,0,0] : [0,0,4,4] },
      })),
    })
  } catch { /* fallback */ }
}

watch(dimension, render)
onMounted(render)
</script>

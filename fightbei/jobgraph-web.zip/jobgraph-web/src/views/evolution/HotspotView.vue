<template>
  <div>
    <n-tabs v-model:value="tab" type="line" @update:value="load">
      <n-tab-pane name="emerging" tab="新兴岗位" />
      <n-tab-pane name="declining" tab="衰退技能" />
    </n-tabs>
    <n-grid :cols="2" :x-gap="16" style="margin-top: 16px">
      <n-grid-item v-for="item in list" :key="item.name">
        <div class="panel-card" style="cursor: pointer">
          <div class="panel-header">
            <span class="panel-title">{{ item.name }}</span>
            <n-tag :type="tab === 'emerging' ? 'success' : 'error'" size="small">
              {{ tab === 'emerging' ? `↑ ${item.growth}%` : `↓ ${Math.abs(item.decline)}%` }}
            </n-tag>
          </div>
          <n-space><n-tag v-for="s in item.skills" :key="s" size="tiny">{{ s }}</n-tag></n-space>
        </div>
      </n-grid-item>
    </n-grid>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { getHotspots } from '@/api/evolution'

const tab = ref('emerging')
const list = ref<any[]>([])

async function load() {
  try { list.value = await getHotspots(tab.value) as any[] }
  catch { list.value = [] }
}
load()
</script>

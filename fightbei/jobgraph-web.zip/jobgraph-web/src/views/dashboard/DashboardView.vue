<template>
  <div class="dash">
    <!-- 顶部统计卡片 -->
    <n-grid :cols="4" :x-gap="16" :y-gap="16" responsive="screen">
      <n-grid-item v-for="card in statCards" :key="card.title">
        <div class="stat-card">
          <div class="stat-glow" :style="{ background: card.glow }"></div>
          <div class="stat-icon" :style="{ background: card.bg }">
            <svg viewBox="0 0 24 24" width="24" height="24" fill="none" :stroke="card.color" stroke-width="2">
              <path :d="card.path" />
            </svg>
          </div>
          <div class="stat-info">
            <span class="stat-label">{{ card.title }}</span>
            <span class="stat-val">
              <span class="stat-num">{{ card.display }}</span>
              <span class="stat-unit">{{ card.suffix }}</span>
            </span>
            <span class="stat-change" :class="card.up ? 'up' : 'down'">
              {{ card.up ? '↑' : '↓' }} {{ card.change }}
            </span>
          </div>
        </div>
      </n-grid-item>
    </n-grid>

    <!-- 图表行1 -->
    <n-grid :cols="2" :x-gap="16" style="margin-top: 16px">
      <n-grid-item>
        <div class="chart-card">
          <div class="chart-header">
            <span class="chart-title">岗位需求趋势</span>
            <span class="chart-badge">近12个月</span>
          </div>
          <div ref="trendRef" class="chart-body"></div>
        </div>
      </n-grid-item>
      <n-grid-item>
        <div class="chart-card">
          <div class="chart-header">
            <span class="chart-title">热门能力 Top10</span>
            <span class="chart-badge">热度指数</span>
          </div>
          <div ref="barRef" class="chart-body"></div>
        </div>
      </n-grid-item>
    </n-grid>

    <!-- 图表行2 -->
    <n-grid :cols="2" :x-gap="16" style="margin-top: 16px">
      <n-grid-item>
        <div class="chart-card">
          <div class="chart-header">
            <span class="chart-title">行业需求分布</span>
            <span class="chart-badge">实时</span>
          </div>
          <div ref="pieRef" class="chart-body"></div>
        </div>
      </n-grid-item>
      <n-grid-item>
        <div class="chart-card">
          <div class="chart-header">
            <span class="chart-title">新兴岗位预警</span>
            <span class="chart-badge pulse">动态监测</span>
          </div>
          <div class="chart-body emerging-wrap">
            <div class="emerging-scroll">
              <template v-for="(item, i) in emergingJobs" :key="item.name">
                <div class="em-item">
                  <div class="em-rank" :class="'rank-' + (i + 1)">{{ i + 1 }}</div>
                  <div class="em-content">
                    <div class="em-name">{{ item.name }}</div>
                    <div class="em-tags">
                      <span v-for="s in item.skills" :key="s" class="em-tag">{{ s }}</span>
                    </div>
                  </div>
                  <div class="em-growth">
                    <span class="em-growth-val">↑{{ item.growth }}%</span>
                    <div class="em-bar"><div class="em-bar-fill" :style="{ width: (item.growth / 235 * 100) + '%' }"></div></div>
                  </div>
                </div>
              </template>
              <!-- 重复一组实现无缝滚动 -->
              <template v-for="(item, i) in emergingJobs" :key="'dup-' + item.name">
                <div class="em-item">
                  <div class="em-rank" :class="'rank-' + (i + 1)">{{ i + 1 }}</div>
                  <div class="em-content">
                    <div class="em-name">{{ item.name }}</div>
                    <div class="em-tags">
                      <span v-for="s in item.skills" :key="s" class="em-tag">{{ s }}</span>
                    </div>
                  </div>
                  <div class="em-growth">
                    <span class="em-growth-val">↑{{ item.growth }}%</span>
                    <div class="em-bar"><div class="em-bar-fill" :style="{ width: (item.growth / 235 * 100) + '%' }"></div></div>
                  </div>
                </div>
              </template>
            </div>
          </div>
        </div>
      </n-grid-item>
    </n-grid>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import * as echarts from 'echarts'

const trendRef = ref<HTMLDivElement>()
const barRef = ref<HTMLDivElement>()
const pieRef = ref<HTMLDivElement>()

// ===== 统计卡片 =====
const statCards = ref([
  {
    title: '岗位总数', value: 2847, display: '2,847', suffix: '个', change: '12.5%', up: true,
    color: '#00F2FF', bg: 'rgba(0,242,255,0.10)', glow: 'rgba(0,242,255,0.06)',
    path: 'M20 7h-4l-2-4H10L8 7H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z',
  },
  {
    title: '能力标签', value: 1356, display: '1,356', suffix: '个', change: '8.3%', up: true,
    color: '#0055FF', bg: 'rgba(0,85,255,0.10)', glow: 'rgba(0,85,255,0.06)',
    path: 'M9.663 17h4.673L12 3v14zM11 3L3 17h4l1-2.5h6L15 17h4L11 3z',
  },
  {
    title: '数据来源', value: 12, display: '12', suffix: '个', change: '0%', up: true,
    color: '#00E676', bg: 'rgba(0,230,118,0.10)', glow: 'rgba(0,230,118,0.06)',
    path: 'M4 6h16M4 12h16M4 18h12M19 15l3 3-3 3',
  },
  {
    title: '产教匹配度', value: 72.5, display: '72.5', suffix: '%', change: '3.2%', up: true,
    color: '#FF9100', bg: 'rgba(255,145,0,0.10)', glow: 'rgba(255,145,0,0.06)',
    path: 'M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5z',
  },
])

const emergingJobs = ref([
  { name: 'AI提示词工程师', growth: 235, skills: ['LLM', 'Prompt', 'Python'] },
  { name: '数据安全分析师', growth: 186, skills: ['安全', '渗透测试', '合规'] },
  { name: '碳中和咨询师', growth: 152, skills: ['碳核算', 'ESG', '能源'] },
  { name: '智能硬件产品经理', growth: 128, skills: ['IoT', '嵌入式', '产品'] },
  { name: '生物信息工程师', growth: 115, skills: ['生信', 'Python', 'NGS'] },
])

// ===== 暗色图表主题 =====
const darkTooltip = {
  backgroundColor: 'rgba(15,17,41,0.95)',
  borderColor: 'rgba(0,212,255,0.2)',
  textStyle: { color: '#e8eaed', fontSize: 12 },
}
const darkAxis = {
  axisLine: { lineStyle: { color: 'rgba(255,255,255,0.08)' } },
  axisTick: { show: false },
  axisLabel: { color: '#9aa0b4', fontSize: 11 },
  splitLine: { lineStyle: { color: 'rgba(255,255,255,0.04)' } },
}
const darkLegend = {
  textStyle: { color: '#9aa0b4', fontSize: 12 },
  bottom: 0,
}

onMounted(() => {
  // 趋势折线图
  if (trendRef.value) {
    const c = echarts.init(trendRef.value)
    c.setOption({
      tooltip: { ...darkTooltip, trigger: 'axis' },
      legend: { ...darkLegend, data: ['Java开发', '数据分析', 'AI算法', '前端开发'] },
      grid: { left: 50, right: 20, top: 20, bottom: 40 },
      xAxis: { ...darkAxis, type: 'category', data: ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'] },
      yAxis: { ...darkAxis, type: 'value', name: '需求量', nameTextStyle: { color: '#9aa0b4' } },
      series: [
        { name: 'Java开发', type: 'line', smooth: true, symbol: 'circle', symbolSize: 6,
          data: [820,832,901,934,890,930,950,920,910,900,880,870],
          lineStyle: { color: '#00F2FF', width: 2 }, itemStyle: { color: '#00F2FF' },
          areaStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[
            {offset:0, color:'rgba(0,242,255,0.22)'},{offset:1, color:'rgba(0,242,255,0)'}]) } },
        { name: '数据分析', type: 'line', smooth: true, symbol: 'circle', symbolSize: 6,
          data: [420,450,480,520,560,600,650,700,750,800,850,900],
          lineStyle: { color: '#0055FF', width: 2 }, itemStyle: { color: '#0055FF' },
          areaStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[
            {offset:0, color:'rgba(0,85,255,0.22)'},{offset:1, color:'rgba(0,85,255,0)'}]) } },
        { name: 'AI算法', type: 'line', smooth: true, symbol: 'circle', symbolSize: 6,
          data: [200,250,300,350,400,480,550,620,700,780,850,920],
          lineStyle: { color: '#00E676', width: 2 }, itemStyle: { color: '#00E676' },
          areaStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[
            {offset:0, color:'rgba(0,230,118,0.22)'},{offset:1, color:'rgba(0,230,118,0)'}]) } },
        { name: '前端开发', type: 'line', smooth: true, symbol: 'circle', symbolSize: 6,
          data: [600,620,580,560,550,540,520,510,500,490,480,470],
          lineStyle: { color: '#FF9100', width: 2 }, itemStyle: { color: '#FF9100' },
          areaStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[
            {offset:0, color:'rgba(255,145,0,0.22)'},{offset:1, color:'rgba(255,145,0,0)'}]) } },
      ],
    })
  }

  // 横向柱状图
  if (barRef.value) {
    const c = echarts.init(barRef.value)
    const labels = ['Python','沟通能力','数据分析','Java','项目管理','Linux','Docker','MySQL','机器学习','团队协作']
    const values = [95,90,88,85,82,78,75,72,70,68]
    c.setOption({
      tooltip: { ...darkTooltip, trigger: 'axis', axisPointer: { type: 'shadow' } },
      grid: { left: 90, right: 40, top: 10, bottom: 10 },
      xAxis: { ...darkAxis, type: 'value', name: '热度', nameTextStyle: { color: '#9aa0b4' } },
      yAxis: { ...darkAxis, type: 'category', data: labels.reverse() },
      series: [{
        type: 'bar', data: values.reverse(),
        barWidth: 16,
        itemStyle: {
          borderRadius: [0, 8, 8, 0],
          color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
            { offset: 0, color: 'rgba(0,242,255,0.3)' },
            { offset: 0.5, color: '#00F2FF' },
            { offset: 1, color: '#0055FF' },
          ]),
        },
        label: { show: true, position: 'right', color: '#9aa0b4', fontSize: 11 },
      }],
    })
  }

  // 饼图
  if (pieRef.value) {
    const c = echarts.init(pieRef.value)
    c.setOption({
      series: [{
        type: 'pie',
        radius: ['62%', '80%'],
        center: ['50%', '48%'],
        itemStyle: { borderColor: '#0B1A30', borderWidth: 3 },
        label: { show: false },
        labelLine: { show: false },
        emphasis: {
          scale: true, scaleSize: 8,
          label: { show: true, fontSize: 14, fontWeight: 'bold', color: '#E8EDF1', formatter: '{b}\n{d}%' },
          itemStyle: { shadowBlur: 24, shadowColor: 'rgba(0, 242, 255, 0.45)' },
        },
        data: [
          { value: 1048, name: '互联网/IT', itemStyle: { color: '#00F2FF' } },
          { value: 735, name: '金融', itemStyle: { color: '#0055FF' } },
          { value: 580, name: '制造业', itemStyle: { color: '#00C8D4' } },
          { value: 484, name: '教育', itemStyle: { color: '#2979FF' } },
          { value: 300, name: '医疗健康', itemStyle: { color: '#7C4DFF' } },
          { value: 200, name: '其他', itemStyle: { color: '#4B6A8E' } },
        ],
      }],
      graphic: [
        { type: 'text', left: 'center', top: '42%',
          style: { text: '3,347', textAlign: 'center', fill: '#E8EDF1', fontSize: 24, fontWeight: 700, fontFamily: "'DIN','SF Mono','Consolas',monospace" } },
        { type: 'text', left: 'center', top: '54%',
          style: { text: '岗位总量', textAlign: 'center', fill: '#A5F3FC', fontSize: 12 } },
      ],
    })
  }
})
</script>

<style scoped>
.dash { position: relative; z-index: 1; }

/* ===== 统计卡片 ===== */
.stat-card {
  position: relative; display: flex; align-items: center; gap: 16px;
  padding: 20px; border-radius: 12px; overflow: hidden;
  background: rgba(15, 32, 55, 0.78); border: 1px solid rgba(0, 242, 255, 0.12);
  backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 0 15px rgba(0, 242, 255, 0.08);
  transition: all 0.3s ease;
}
.stat-card:hover {
  border-color: rgba(0, 242, 255, 0.30);
  box-shadow: 0 0 20px rgba(0, 242, 255, 0.35), 0 4px 24px rgba(0,0,0,0.5);
  transform: translateY(-2px);
}
.stat-glow {
  position: absolute; top: -30px; right: -30px; width: 100px; height: 100px;
  border-radius: 50%; filter: blur(40px); opacity: 0.5;
}
.stat-icon {
  width: 48px; height: 48px; border-radius: 12px;
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.stat-info { display: flex; flex-direction: column; gap: 4px; }
.stat-label { font-size: 13px; color: #9aa0b4; }
.stat-val { display: flex; align-items: baseline; gap: 4px; }
.stat-num {
  font-family: 'DIN', 'SF Mono', 'Consolas', monospace;
  font-size: 28px; font-weight: 700; color: #e8eaed;
}
.stat-unit { font-size: 13px; color: #9aa0b4; }
.stat-change { font-size: 12px; }
.stat-change.up { color: #00E676; }
.stat-change.down { color: #FF5252; }

/* ===== 图表卡片 ===== */
.chart-card {
  background: rgba(15, 32, 55, 0.78); border: 1px solid rgba(0, 242, 255, 0.12);
  border-radius: 12px; padding: 20px;
  backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 0 15px rgba(0, 242, 255, 0.08);
  transition: all 0.3s ease;
}
.chart-card:hover { border-color: rgba(0, 242, 255, 0.18); }
.chart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.chart-title { font-size: 15px; font-weight: 600; color: #e8eaed; }
.chart-badge {
  font-size: 11px; color: #5f6680; padding: 3px 10px;
  border: 1px solid rgba(255,255,255,0.08); border-radius: 20px;
}
.chart-badge.pulse { border-color: rgba(0,242,255,0.35); color: #00F2FF; animation: glow-pulse 2s ease-in-out infinite; }
.chart-body { height: 320px; }

/* ===== 新兴岗位列表 ===== */
.emerging-wrap { overflow: hidden; height: 320px; mask-image: linear-gradient(180deg, #000 60%, transparent 100%); -webkit-mask-image: linear-gradient(180deg, #000 60%, transparent 100%); }
.emerging-scroll { animation: listScroll 22s linear infinite; }
.emerging-scroll:hover { animation-play-state: paused; }
.em-item { display: flex; align-items: center; gap: 14px; padding: 12px 14px; margin-bottom: 10px;
  background: rgba(255,255,255,0.02); border-radius: 10px; border: 1px solid rgba(255,255,255,0.04);
  transition: all 0.3s ease; }
.em-item:hover { background: rgba(0,242,255,0.05); border-color: rgba(0,242,255,0.18); }

@keyframes listScroll {
  0% { transform: translateY(0); }
  100% { transform: translateY(-50%); }
}
.em-rank {
  width: 24px; height: 24px; border-radius: 6px; display: flex;
  align-items: center; justify-content: center; font-size: 12px; font-weight: 700;
  background: rgba(255,255,255,0.05); color: #9aa0b4; flex-shrink: 0;
}
.rank-1 { background: linear-gradient(135deg, #00F2FF, #0055FF); color: #000; }
.rank-2 { background: linear-gradient(135deg, #0055FF, #7C4DFF); color: #fff; }
.rank-3 { background: linear-gradient(135deg, #00E676, #00C853); color: #000; }
.em-content { flex: 1; min-width: 0; }
.em-name { font-size: 14px; font-weight: 600; color: #e8eaed; margin-bottom: 4px; }
.em-tags { display: flex; gap: 4px; flex-wrap: wrap; }
.em-tag { font-size: 10px; padding: 2px 8px; border-radius: 4px; background: rgba(0,242,255,0.10); color: #00F2FF; }
.em-growth { display: flex; flex-direction: column; align-items: flex-end; gap: 4px; flex-shrink: 0; }
.em-growth-val { font-family: 'SF Mono', 'Consolas', monospace; font-size: 13px; font-weight: 600; color: #00E676; }
.em-bar { width: 50px; height: 3px; background: rgba(255,255,255,0.06); border-radius: 2px; overflow: hidden; }
.em-bar-fill { height: 100%; background: linear-gradient(90deg, #00E676, #00F2FF); border-radius: 2px; transition: width 1s ease; }
</style>

<template>
  <div class="login-page">
    <!-- 粒子 Canvas -->
    <canvas ref="particleCanvas" class="particle-canvas"></canvas>

    <div class="bg-grid"></div>
    <div class="bg-orb bg-orb-1"></div>
    <div class="bg-orb bg-orb-2"></div>
    <div class="bg-orb bg-orb-3"></div>

    <!-- 左侧品牌区 - 3D魔方 -->
    <div class="login-brand">
      <div class="cube-stage" ref="cubeStage">
        <div class="cube" ref="cubeRef">
          <!-- 前面 -->
          <div class="cube-face front">
            <svg viewBox="0 0 120 120" width="100" height="100">
              <circle cx="60" cy="60" r="52" fill="none" stroke="#00F2FF" stroke-width="2" opacity="0.7"/>
              <circle cx="60" cy="60" r="16" fill="#00F2FF" opacity="0.9"/>
              <line x1="60" y1="8" x2="60" y2="36" stroke="#00F2FF" stroke-width="1.5" opacity="0.5"/>
              <line x1="112" y1="60" x2="84" y2="60" stroke="#00F2FF" stroke-width="1.5" opacity="0.5"/>
              <line x1="60" y1="112" x2="60" y2="84" stroke="#00F2FF" stroke-width="1.5" opacity="0.5"/>
              <line x1="8" y1="60" x2="36" y2="60" stroke="#00F2FF" stroke-width="1.5" opacity="0.5"/>
            </svg>
          </div>
          <!-- 后面 -->
          <div class="cube-face back">
            <svg viewBox="0 0 120 120" width="100" height="100">
              <rect x="8" y="8" width="104" height="104" rx="16" fill="none" stroke="#0055FF" stroke-width="2.5" opacity="0.6"/>
              <circle cx="60" cy="60" r="24" fill="none" stroke="#7C4DFF" stroke-width="2.5" opacity="0.5"/>
            </svg>
          </div>
          <!-- 右面 -->
          <div class="cube-face right">
            <svg viewBox="0 0 120 120" width="100" height="100">
              <polygon points="60,8 112,60 60,112 8,60" fill="none" stroke="#00F2FF" stroke-width="2.5" opacity="0.6"/>
              <polygon points="60,32 88,60 60,88 32,60" fill="none" stroke="#0055FF" stroke-width="2.5" opacity="0.5"/>
            </svg>
          </div>
          <!-- 左面 -->
          <div class="cube-face left">
            <svg viewBox="0 0 120 120" width="100" height="100">
              <circle cx="60" cy="60" r="44" fill="none" stroke="#7C4DFF" stroke-width="2" stroke-dasharray="16 8" opacity="0.5"/>
              <circle cx="60" cy="60" r="20" fill="none" stroke="#00F2FF" stroke-width="1.5" opacity="0.6"/>
            </svg>
          </div>
          <!-- 上面 -->
          <div class="cube-face top">
            <svg viewBox="0 0 120 120" width="100" height="100">
              <rect x="16" y="16" width="88" height="88" rx="12" fill="none" stroke="#00F2FF" stroke-width="2" opacity="0.5" transform="rotate(45 60 60)"/>
              <circle cx="60" cy="60" r="14" fill="#00F2FF" opacity="0.7"/>
            </svg>
          </div>
          <!-- 下面 -->
          <div class="cube-face bottom">
            <svg viewBox="0 0 120 120" width="100" height="100">
              <polygon points="60,12 104,44 60,76 16,44" fill="none" stroke="#0055FF" stroke-width="2.5" opacity="0.5"/>
              <polygon points="60,40 88,60 60,80 32,60" fill="none" stroke="#00F2FF" stroke-width="2" opacity="0.5"/>
            </svg>
          </div>
        </div>
        <!-- 魔方光环 -->
        <div class="cube-ring"></div>
        <div class="cube-ring ring-2"></div>
      </div>

      <h1 class="brand-title">岗位能力图谱</h1>
      <p class="brand-subtitle">JOB COMPETENCY GRAPH</p>
      <div class="brand-features">
        <div class="feature-item"><span class="feature-dot"></span> 多源异构数据融合</div>
        <div class="feature-item"><span class="feature-dot"></span> 知识图谱可视化</div>
        <div class="feature-item"><span class="feature-dot"></span> 动态演化分析</div>
        <div class="feature-item"><span class="feature-dot"></span> 产教对接匹配</div>
      </div>
      <div class="brand-footer">
        <div class="scan-line"></div>
        <span>v1.0.0 · 数据驱动 · 智慧分析</span>
      </div>
    </div>

    <!-- 右侧登录区 -->
    <div class="login-form-area">
      <n-card class="login-card" :bordered="true">
        <template #header>
          <div class="card-header">
            <span class="card-title">系统登录</span>
            <span class="card-subtitle">SIGN IN</span>
          </div>
        </template>

        <n-tabs v-model:value="activeTab" animated type="line" class="login-tabs">
          <n-tab-pane name="login" tab="登录">
            <n-form ref="formRef" :model="loginForm" :rules="loginRules" label-placement="top">
              <n-form-item path="username">
                <template #label><span class="form-label">用户名</span></template>
                <n-input v-model:value="loginForm.username" placeholder="请输入用户名" size="large" round>
                  <template #prefix>
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                  </template>
                </n-input>
              </n-form-item>
              <n-form-item path="password">
                <template #label><span class="form-label">密码</span></template>
                <n-input v-model:value="loginForm.password" type="password" placeholder="请输入密码" size="large" round @keyup.enter="handleLogin">
                  <template #prefix>
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
                  </template>
                </n-input>
              </n-form-item>
            </n-form>
            <n-button type="primary" block size="large" :loading="loading" @click="handleLogin" round class="login-btn">
              <span v-if="!loading">登 录</span>
            </n-button>
          </n-tab-pane>

          <n-tab-pane name="register" tab="注册">
            <n-form ref="regFormRef" :model="regForm" :rules="regRules" label-placement="top">
              <n-grid :cols="2" :x-gap="12">
                <n-grid-item>
                  <n-form-item path="username"><template #label><span class="form-label">用户名</span></template>
                    <n-input v-model:value="regForm.username" size="large" round />
                  </n-form-item>
                </n-grid-item>
                <n-grid-item>
                  <n-form-item path="realName"><template #label><span class="form-label">姓名</span></template>
                    <n-input v-model:value="regForm.realName" size="large" round />
                  </n-form-item>
                </n-grid-item>
              </n-grid>
              <n-form-item path="password"><template #label><span class="form-label">密码</span></template>
                <n-input v-model:value="regForm.password" type="password" size="large" round />
              </n-form-item>
              <n-grid :cols="2" :x-gap="12">
                <n-grid-item>
                  <n-form-item path="role"><template #label><span class="form-label">角色</span></template>
                    <n-select v-model:value="regForm.role" :options="roleOptions" size="large" />
                  </n-form-item>
                </n-grid-item>
                <n-grid-item>
                  <n-form-item path="school"><template #label><span class="form-label">学校</span></template>
                    <n-input v-model:value="regForm.school" size="large" round />
                  </n-form-item>
                </n-grid-item>
              </n-grid>
              <n-form-item path="major"><template #label><span class="form-label">专业</span></template>
                <n-input v-model:value="regForm.major" size="large" round />
              </n-form-item>
            </n-form>
            <n-button type="primary" block size="large" @click="handleRegister" :loading="regLoading" round class="login-btn">
              注 册
            </n-button>
          </n-tab-pane>
        </n-tabs>
      </n-card>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { register } from '@/api/auth'

const router = useRouter()
const userStore = useUserStore()
const activeTab = ref('login')
const loading = ref(false)
const regLoading = ref(false)

const loginForm = reactive({ username: '', password: '' })
const loginRules = {
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
}

const regForm = reactive({ username: '', password: '', realName: '', role: 'STUDENT', school: '', major: '', email: '' })
const roleOptions = [{ label: '学生', value: 'STUDENT' }, { label: '教师', value: 'TEACHER' }]
const regRules = {
  username: [{ required: true, message: '请输入用户名' }],
  password: [{ required: true, message: '请输入密码', min: 6, message: '密码至少6位' }],
  realName: [{ required: true, message: '请输入姓名' }],
  role: [{ required: true, message: '请选择角色' }],
}

async function handleLogin() {
  loading.value = true
  try { await userStore.login(loginForm); await userStore.fetchUserInfo(); router.push('/dashboard') } catch { /* */ }
  finally { loading.value = false }
}
async function handleRegister() {
  regLoading.value = true
  try { await register(regForm); window.$message?.success('注册成功，请登录'); activeTab.value = 'login'; Object.assign(loginForm, { username: regForm.username, password: '' }) } catch { /* */ }
  finally { regLoading.value = false }
}

// ===== 粒子动画 =====
const particleCanvas = ref<HTMLCanvasElement>()
let animId = 0

onMounted(() => {
  const canvas = particleCanvas.value
  if (!canvas) return
  const ctx = canvas.getContext('2d')!
  let w = 0, h = 0

  const resize = () => {
    w = canvas.width = window.innerWidth
    h = canvas.height = window.innerHeight
  }
  resize()
  window.addEventListener('resize', resize)

  // 生成粒子
  const count = 80
  const dots: Array<{ x: number; y: number; vx: number; vy: number; r: number; a: number }> = []
  for (let i = 0; i < count; i++) {
    dots.push({
      x: Math.random() * w, y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.4, vy: (Math.random() - 0.5) * 0.4,
      r: Math.random() * 2 + 1, a: Math.random() * 0.4 + 0.1,
    })
  }

  function draw() {
    ctx.clearRect(0, 0, w, h)

    // 更新 + 绘制粒子
    for (let i = 0; i < count; i++) {
      const d = dots[i]
      d.x += d.vx; d.y += d.vy
      if (d.x < 0) d.x = w; if (d.x > w) d.x = 0
      if (d.y < 0) d.y = h; if (d.y > h) d.y = 0

      ctx.beginPath()
      ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2)
      ctx.fillStyle = `rgba(0,242,255,${Math.min(1, d.a * 1.5)})`
      ctx.fill()
    }

    // 连线：近距离粒子之间
    for (let i = 0; i < count; i++) {
      for (let j = i + 1; j < count; j++) {
        const dx = dots[i].x - dots[j].x
        const dy = dots[i].y - dots[j].y
        const dist = Math.sqrt(dx * dx + dy * dy)
        if (dist < 120) {
          ctx.beginPath()
          ctx.moveTo(dots[i].x, dots[i].y)
          ctx.lineTo(dots[j].x, dots[j].y)
          ctx.strokeStyle = `rgba(0,242,255,${0.10 * (1 - dist / 120)})`
          ctx.lineWidth = 0.5
          ctx.stroke()
        }
      }
    }

    animId = requestAnimationFrame(draw)
  }
  draw()
})

onUnmounted(() => { cancelAnimationFrame(animId) })
</script>

<style scoped>
.login-page {
  display: flex; min-height: 100vh; position: relative; overflow: hidden;
  background: linear-gradient(160deg, #0B1A30 0%, #102440 40%, #162E50 100%);
}
.particle-canvas { position: absolute; inset: 0; z-index: 0; pointer-events: none; }
.bg-grid { position: absolute; inset: 0; pointer-events: none; z-index: 0;
  background-image: radial-gradient(circle, rgba(0,242,255,0.06) 1px, transparent 1px);
  background-size: 40px 40px; }
.bg-orb { position: absolute; border-radius: 50%; pointer-events: none; z-index: 0; filter: blur(100px); opacity: 0.14; }
.bg-orb-1 { top: -150px; right: -100px; width: 450px; height: 450px; background: #00F2FF; }
.bg-orb-2 { bottom: -200px; left: -120px; width: 500px; height: 500px; background: #0055FF; }
.bg-orb-3 { top: 40%; left: 30%; width: 350px; height: 350px; background: #00F2FF; opacity: 0.06; }

/* ===== 左侧3D魔方 ===== */
.login-brand {
  flex: 1; max-width: 55%; display: flex; flex-direction: column; align-items: center; justify-content: center;
  padding: 40px 40px; position: relative; z-index: 1;
}
.cube-stage {
  position: relative; width: 260px; height: 260px; margin-bottom: 30px;
  display: flex; align-items: center; justify-content: center;
}
.cube {
  position: relative; width: 160px; height: 160px;
  transform-style: preserve-3d; animation: rotateCube 12s linear infinite;
}
.cube-face {
  position: absolute; width: 160px; height: 160px;
  display: flex; align-items: center; justify-content: center;
  background: rgba(18,38,60,0.72); border: 1.5px solid rgba(0,242,255,0.38);
  backdrop-filter: blur(6px);
  box-shadow: 0 0 40px rgba(0,242,255,0.12) inset, 0 0 20px rgba(0,242,255,0.08);
}
.cube-face svg { width: 120px; height: 120px; }
.front  { transform: translateZ(80px); }
.back   { transform: rotateY(180deg) translateZ(80px); }
.right  { transform: rotateY(90deg) translateZ(80px); }
.left   { transform: rotateY(-90deg) translateZ(80px); }
.top    { transform: rotateX(90deg) translateZ(80px); }
.bottom { transform: rotateX(-90deg) translateZ(80px); }

@keyframes rotateCube {
  0% { transform: rotateX(0deg) rotateY(0deg); }
  100% { transform: rotateX(360deg) rotateY(360deg); }
}

/* 魔方光环 */
.cube-ring {
  position: absolute; top: 50%; left: 50%;
  width: 210px; height: 210px; margin-top: -105px; margin-left: -105px;
  border-radius: 50%;
  border: 1.5px solid rgba(0,242,255,0.30);
  box-shadow: 0 0 40px rgba(0,242,255,0.20), inset 0 0 40px rgba(0,242,255,0.08);
  animation: ringPulse 3s ease-in-out infinite;
}
.cube-ring.ring-2 {
  width: 250px; height: 250px; margin-top: -125px; margin-left: -125px;
  border-color: rgba(0,85,255,0.22);
  box-shadow: 0 0 50px rgba(0,85,255,0.12);
  animation: ringPulse 3s ease-in-out 1.5s infinite;
}
@keyframes ringPulse {
  0%, 100% { opacity: 0.5; transform: scale(1); }
  50% { opacity: 1; transform: scale(1.08); }
}

/* 品牌文字 */
.brand-title { font-size: 34px; font-weight: 700; color: #E8EDF1; letter-spacing: 8px; margin: 0 0 8px; position: relative; z-index: 1; }
.brand-subtitle { font-size: 11px; color: #8DA4B5; letter-spacing: 10px; margin: 0 0 28px; position: relative; z-index: 1; }
.brand-features { display: flex; flex-direction: column; gap: 14px; margin-bottom: 50px; position: relative; z-index: 1; }
.feature-item { font-size: 14px; color: #C8E6FF; display: flex; align-items: center; gap: 10px; }
.feature-dot {
  width: 5px; height: 5px; border-radius: 50%; background: #00F2FF;
  box-shadow: 0 0 10px rgba(0,242,255,0.8); flex-shrink: 0;
}
.brand-footer { position: relative; font-size: 11px; color: #8DA4B5; text-align: center; padding-top: 20px; z-index: 1; }
.scan-line { width: 30px; height: 1px; background: #00F2FF; margin: 0 auto 8px; opacity: 0.5; }

/* ===== 右侧表单 ===== */
.login-form-area {
  flex: 1; max-width: 45%; display: flex; align-items: center; justify-content: center;
  padding: 40px 48px; position: relative; z-index: 1;
}
.login-card {
  width: 100%; max-width: 400px;
  background: rgba(15, 32, 55, 0.80) !important;
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  border: 1px solid rgba(0, 242, 255, 0.18) !important;
  border-radius: 16px !important;
  box-shadow: 0 0 15px rgba(0, 242, 255, 0.3), 0 8px 40px rgba(0, 0, 0, 0.5);
}
.card-header { text-align: center; }
.card-title { font-size: 20px; font-weight: 700; color: #E8EDF1; display: block; }
.card-subtitle { font-size: 11px; color: #6B8090; letter-spacing: 4px; display: block; margin-top: 4px; }
.login-tabs { margin-top: 8px; }
.form-label { font-size: 13px; font-weight: 500; color: #A5F3FC !important; }
.login-btn { margin-top: 16px; height: 44px; font-size: 15px; letter-spacing: 4px; font-weight: 600; }

:deep(.n-tabs .n-tabs-tab--active) { color: #00F2FF !important; }
:deep(.n-tabs .n-tabs-bar) { background: linear-gradient(90deg, #00F2FF, #0055FF) !important; }
</style>

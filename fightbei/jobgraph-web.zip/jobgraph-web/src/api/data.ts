import request from './request'

export function getJobList(params: { pageNum: number; pageSize: number; keyword?: string }) {
  return request.get('/data/job/list', { params })
}

export function getCompetencyList(params: { pageNum: number; pageSize: number; keyword?: string }) {
  return request.get('/data/competency/list', { params })
}

export function uploadFile(formData: FormData) {
  return request.post('/data/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export function getDataSourceList(params: { pageNum: number; pageSize: number; keyword?: string }) {
  return request.get('/datasource/list', { params })
}

export function saveDataSource(data: any) {
  return request.post('/datasource', data)
}

export function deleteDataSource(id: number) {
  return request.delete(`/datasource/${id}`)
}

import request from './request'

export function getTimeline(params?: { jobId?: number; months?: number }) {
  return request.get('/evolution/timeline', { params })
}

export function getHotspots(type: string = 'emerging') {
  return request.get('/evolution/hotspot', { params: { type } })
}

export function compareByDimension(dimension: string = 'industry') {
  return request.get('/evolution/compare', { params: { dimension } })
}

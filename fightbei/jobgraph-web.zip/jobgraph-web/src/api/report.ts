import request from './request'

export function getReportList(params: { pageNum: number; pageSize: number }) {
  return request.get('/report/list', { params })
}

export function getReportDetail(id: number) {
  return request.get(`/report/${id}`)
}

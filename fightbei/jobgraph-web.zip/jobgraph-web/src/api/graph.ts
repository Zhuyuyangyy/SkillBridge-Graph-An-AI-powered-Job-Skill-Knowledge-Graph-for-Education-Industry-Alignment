import request from './request'

export function getGraphNodes(params?: { industry?: string; keyword?: string; limit?: number }) {
  return request.get('/graph/nodes', { params })
}

export function getCommunities() {
  return request.get('/graph/community')
}

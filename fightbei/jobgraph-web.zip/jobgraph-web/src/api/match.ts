import request from './request'

export function getMatchOverview(params?: { school?: string; major?: string }) {
  return request.get('/match/overview', { params })
}

export function getGapAnalysis(params?: { school?: string; major?: string }) {
  return request.get('/match/gap', { params })
}

export function runMatchAnalysis(params: Record<string, any>) {
  return request.post('/match/analyze', params)
}

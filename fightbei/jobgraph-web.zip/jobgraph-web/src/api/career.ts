import request from './request'

export function getCareerAdvice(description: string) {
  return request.post('/career/advice', { description })
}

export function getCareerAdviceBySkills(skills: string[]) {
  return request.post('/career/advice/skills', { skills })
}

export function searchSkill(keyword: string) {
  return request.get('/career/skill/search', { params: { keyword } })
}

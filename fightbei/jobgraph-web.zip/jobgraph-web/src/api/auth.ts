import request from './request'

export interface LoginParams {
  username: string
  password: string
}

export interface RegisterParams {
  username: string
  password: string
  realName: string
  role: string
  school?: string
  major?: string
  email?: string
}

export function login(params: LoginParams) {
  return request.post('/auth/login', params)
}

export function register(params: RegisterParams) {
  return request.post('/auth/register', params)
}

export function getCurrentUser() {
  return request.get('/auth/current-user')
}

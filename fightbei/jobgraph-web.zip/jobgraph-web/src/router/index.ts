import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/login',
      name: 'Login',
      component: () => import('@/views/login/LoginView.vue'),
      meta: { requiresAuth: false },
    },
    {
      path: '/',
      component: () => import('@/components/layout/AppLayout.vue'),
      meta: { requiresAuth: true },
      children: [
        { path: '', redirect: '/dashboard' },
        { path: 'dashboard', name: 'Dashboard', component: () => import('@/views/dashboard/DashboardView.vue') },
        { path: 'career/advisor', name: 'CareerAdvisor', component: () => import('@/views/career/CareerAdvisor.vue') },
        { path: 'graph/explore', name: 'GraphExplore', component: () => import('@/views/graph/GraphExplore.vue') },
        { path: 'graph/job/:id', name: 'JobDetail', component: () => import('@/views/graph/JobDetail.vue') },
        { path: 'graph/competency/:id', name: 'CompetencyDetail', component: () => import('@/views/graph/CompetencyDetail.vue') },
        { path: 'evolution/timeline', name: 'EvolutionTimeline', component: () => import('@/views/evolution/TimelineView.vue') },
        { path: 'evolution/hotspot', name: 'EvolutionHotspot', component: () => import('@/views/evolution/HotspotView.vue') },
        { path: 'evolution/compare', name: 'EvolutionCompare', component: () => import('@/views/evolution/CompareView.vue') },
        { path: 'match/overview', name: 'MatchOverview', component: () => import('@/views/match/MatchOverview.vue') },
        { path: 'match/gap', name: 'MatchGap', component: () => import('@/views/match/GapAnalysis.vue') },
        { path: 'match/report', name: 'MatchReport', component: () => import('@/views/match/MatchReport.vue') },
        { path: 'data/job', name: 'DataJob', component: () => import('@/views/data/JobLibrary.vue') },
        { path: 'data/competency', name: 'DataCompetency', component: () => import('@/views/data/CompetencyLibrary.vue') },
        { path: 'data/upload', name: 'DataUpload', component: () => import('@/views/data/DataUpload.vue') },
        { path: 'data/source', name: 'DataSource', component: () => import('@/views/data/SourceManage.vue'), meta: { role: 'ADMIN' } },
        { path: 'report/list', name: 'ReportList', component: () => import('@/views/report/ReportList.vue') },
        { path: 'report/:id', name: 'ReportDetail', component: () => import('@/views/report/ReportDetail.vue') },
        { path: 'system/user', name: 'SystemUser', component: () => import('@/views/system/UserManage.vue'), meta: { role: 'ADMIN' } },
        { path: 'system/log', name: 'SystemLog', component: () => import('@/views/system/CollectLog.vue'), meta: { role: 'ADMIN' } },
        { path: 'system/config', name: 'SystemConfig', component: () => import('@/views/system/SystemConfig.vue'), meta: { role: 'ADMIN' } },
      ],
    },
  ],
})

router.beforeEach(async (to, _from, next) => {
  const token = localStorage.getItem('token')
  if (to.meta.requiresAuth !== false && !token) {
    next('/login')
  } else if (to.path === '/login' && token) {
    next('/dashboard')
  } else {
    next()
  }
})

export default router

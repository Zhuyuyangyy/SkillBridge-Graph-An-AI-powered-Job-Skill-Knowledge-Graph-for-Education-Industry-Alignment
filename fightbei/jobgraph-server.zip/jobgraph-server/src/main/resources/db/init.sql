CREATE DATABASE IF NOT EXISTS jobgraph DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE jobgraph;

-- 用户表
CREATE TABLE IF NOT EXISTS user (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    real_name VARCHAR(50),
    role VARCHAR(20) NOT NULL DEFAULT 'STUDENT' COMMENT 'STUDENT/TEACHER/ADMIN',
    school VARCHAR(100),
    major VARCHAR(100),
    email VARCHAR(100),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 数据源管理
CREATE TABLE IF NOT EXISTS data_source (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(20) NOT NULL COMMENT 'CRAWLER/GOVERNMENT/UNIVERSITY/UPLOAD',
    config_json TEXT COMMENT '爬虫配置或API参数JSON',
    cron_expr VARCHAR(50),
    status VARCHAR(20) DEFAULT 'ACTIVE',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 原始采集数据
CREATE TABLE IF NOT EXISTS raw_job_post (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    source_id BIGINT NOT NULL,
    title VARCHAR(200),
    company VARCHAR(200),
    salary_min INT,
    salary_max INT,
    location VARCHAR(100),
    industry VARCHAR(100),
    raw_text TEXT,
    source_url VARCHAR(500),
    collect_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_parsed TINYINT(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 岗位实体（ETL后）
CREATE TABLE IF NOT EXISTS job_position (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    category VARCHAR(100),
    industry VARCHAR(100),
    avg_salary DECIMAL(10,2),
    demand_count INT DEFAULT 0,
    demand_trend VARCHAR(20) COMMENT 'UP/DOWN/STABLE',
    hot_score DECIMAL(5,2) DEFAULT 0,
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_name_industry (name, industry)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 能力实体（ETL后）
CREATE TABLE IF NOT EXISTS competency (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    category VARCHAR(50) COMMENT 'HARD_SKILL/SOFT_SKILL/TOOL/CERTIFICATE/LANGUAGE',
    level VARCHAR(20) COMMENT 'BASIC/MEDIUM/ADVANCED',
    weight DECIMAL(5,2) DEFAULT 0,
    mention_count INT DEFAULT 0,
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 岗位-能力关系
CREATE TABLE IF NOT EXISTS job_competency_rel (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    job_id BIGINT NOT NULL,
    competency_id BIGINT NOT NULL,
    relevance_score DECIMAL(5,2) COMMENT '关联度 0-1',
    requirement_level VARCHAR(20) COMMENT '必须/加分/优先',
    mention_freq INT DEFAULT 0,
    source_id BIGINT,
    UNIQUE KEY uk_job_comp (job_id, competency_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 演化快照（按时段切片）
CREATE TABLE IF NOT EXISTS evolution_snapshot (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    snapshot_date DATE NOT NULL,
    job_id BIGINT,
    competency_id BIGINT,
    demand_count INT DEFAULT 0,
    avg_salary DECIMAL(10,2),
    trend_direction VARCHAR(20) COMMENT 'UP/DOWN/STABLE/EMERGING/DECLINING',
    change_rate DECIMAL(5,2),
    INDEX idx_date (snapshot_date),
    INDEX idx_job_date (job_id, snapshot_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 高校培养方案
CREATE TABLE IF NOT EXISTS course_syllabus (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    school VARCHAR(100),
    major VARCHAR(100),
    course_name VARCHAR(200),
    course_content TEXT,
    competencies_covered TEXT COMMENT 'JSON数组',
    upload_user_id BIGINT,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 分析报告
CREATE TABLE IF NOT EXISTS analysis_report (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    report_type VARCHAR(50) COMMENT 'JOB_ANALYSIS/COMPETENCY_TREND/MATCH_ANALYSIS',
    params_json TEXT,
    result_json MEDIUMTEXT,
    file_url VARCHAR(500) COMMENT 'MinIO中的文件路径',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 采集日志
CREATE TABLE IF NOT EXISTS collect_log (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    source_id BIGINT,
    task_type VARCHAR(50),
    status VARCHAR(20) COMMENT 'RUNNING/SUCCESS/FAILED',
    message TEXT,
    start_time DATETIME,
    end_time DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 默认管理员: admin / admin123
INSERT IGNORE INTO user (username, password_hash, real_name, role)
VALUES ('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5Eh', '系统管理员', 'ADMIN');

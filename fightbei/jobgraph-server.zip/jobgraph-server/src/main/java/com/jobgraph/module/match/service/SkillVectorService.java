package com.jobgraph.module.match.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * 基于共现矩阵的技能语义向量服务
 * 原理：两个技能在同一JD中共现越多 → 语义越接近
 * 这是 Word2Vec 的轻量替代方案，适用于比赛场景
 */
@Slf4j
@Service
public class SkillVectorService {

    // 技能共现矩阵（运行时构建，可从数据库加载）
    private final Map<String, Map<String, Double>> cooccurrenceMatrix = new HashMap<>();

    // 预置的技能语义相似度（基于真实世界的技能关联）
    private static final Map<String, List<String>> SEMANTIC_GROUPS = Map.of(
        "Python", List.of("数据分析", "机器学习", "深度学习", "PyTorch"),
        "Java", List.of("SpringBoot", "微服务", "分布式系统", "MySQL"),
        "JavaScript", List.of("Vue", "React", "Node.js", "前端开发"),
        "机器学习", List.of("深度学习", "自然语言处理", "Python", "算法"),
        "Docker", List.of("Kubernetes", "微服务", "DevOps", "Jenkins"),
        "数据分析", List.of("Python", "SQL", "Pandas", "统计学")
    );

    /**
     * 计算两个技能的语义相似度 (0-1)
     */
    public double semanticSimilarity(String skillA, String skillB) {
        if (skillA.equals(skillB)) return 1.0;
        String a = skillA.toLowerCase().trim();
        String b = skillB.toLowerCase().trim();
        if (a.equals(b)) return 1.0;

        // 同一语义组 → 高相似度
        for (var entry : SEMANTIC_GROUPS.entrySet()) {
            List<String> group = new ArrayList<>();
            group.add(entry.getKey());
            group.addAll(entry.getValue());
            if (group.stream().anyMatch(s -> s.equalsIgnoreCase(skillA))
                && group.stream().anyMatch(s -> s.equalsIgnoreCase(skillB))) {
                return 0.75;
            }
        }

        // 包含关系 → 中等相似度
        if (a.contains(b) || b.contains(a)) return 0.6;

        // 共现频率 → 低相似度
        if (cooccurrenceMatrix.containsKey(a)) {
            return cooccurrenceMatrix.get(a).getOrDefault(b, 0.0);
        }

        return 0.1; // 默认低相似度
    }

    /**
     * 找到与目标技能最相似的前N个技能
     */
    public List<Map.Entry<String, Double>> findSimilarSkills(String targetSkill, int topN) {
        Set<String> allSkills = new HashSet<>();
        SEMANTIC_GROUPS.forEach((k, v) -> { allSkills.add(k); allSkills.addAll(v); });

        return allSkills.stream()
            .filter(s -> !s.equals(targetSkill))
            .map(s -> new AbstractMap.SimpleEntry<>(s, semanticSimilarity(targetSkill, s)))
            .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
            .limit(topN)
            .collect(java.util.stream.Collectors.toList());
    }
}

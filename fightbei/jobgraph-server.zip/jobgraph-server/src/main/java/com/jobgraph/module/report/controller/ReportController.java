package com.jobgraph.module.report.controller;

import com.jobgraph.common.result.R;
import com.jobgraph.common.utils.JwtUtils;
import com.jobgraph.module.report.entity.AnalysisReport;
import com.jobgraph.module.report.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/report")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;
    private final JwtUtils jwtUtils;

    @GetMapping("/list")
    public R<?> list(@RequestParam(defaultValue = "1") int pageNum,
                     @RequestParam(defaultValue = "10") int pageSize,
                     @RequestHeader("Authorization") String auth) {
        Long userId = jwtUtils.getUserId(auth.substring(7));
        return R.ok(reportService.page(pageNum, pageSize, userId));
    }

    @GetMapping("/{id}")
    public R<?> detail(@PathVariable Long id) {
        return R.ok(reportService.getById(id));
    }

    @PostMapping("/generate")
    public R<?> generate(@RequestHeader("Authorization") String auth,
                         @RequestBody Map<String, Object> params) {
        Long userId = jwtUtils.getUserId(auth.substring(7));
        AnalysisReport report = reportService.generateMatchReport(userId, params);
        return R.ok(report);
    }
}

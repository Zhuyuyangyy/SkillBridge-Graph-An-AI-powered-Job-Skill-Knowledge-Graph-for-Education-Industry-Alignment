package com.jobgraph.module.etl.nlp;

import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.corpus.tag.Nature;
import com.hankcs.hanlp.seg.common.Term;
import com.hankcs.hanlp.tokenizer.NLPTokenizer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
public class NlpEntityExtractor {

    // 技能核心词库（种子词，用于候选筛选）
    private static final Set<String> SEED_SKILLS = new HashSet<>(Arrays.asList(
        "Python", "Java", "JavaScript", "C++", "Go", "Rust", "TypeScript", "SQL", "Scala", "Kotlin", "R",
        "Spring", "SpringBoot", "SpringCloud", "MyBatis", "Hibernate", "JPA", "Dubbo",
        "Vue", "React", "Angular", "Next.js", "Nuxt", "Webpack", "Vite",
        "MySQL", "PostgreSQL", "MongoDB", "Redis", "Elasticsearch", "Neo4j", "ClickHouse", "HBase",
        "Docker", "Kubernetes", "Jenkins", "GitLab", "Linux", "Nginx", "Prometheus", "Grafana",
        "Hadoop", "Spark", "Flink", "Kafka", "RabbitMQ", "Pulsar",
        "机器学习", "深度学习", "自然语言处理", "计算机视觉", "数据挖掘", "强化学习", "迁移学习",
        "TensorFlow", "PyTorch", "Scikit-learn", "Pandas", "NumPy", "Keras", "JAX",
        "沟通能力", "团队协作", "项目管理", "需求分析", "文档编写", "领导力",
        "PMP", "CPA", "CFA", "AWS认证", "RHCE", "CKA", "ACP",
        "微服务", "分布式系统", "高并发", "领域驱动设计", "敏捷开发", "DevOps", "CI/CD"
    ));

    // 技能别名映射（语义归并）
    private static final Map<String, String> SKILL_ALIAS = new HashMap<>();
    static {
        SKILL_ALIAS.put("Spring框架", "Spring");
        SKILL_ALIAS.put("Spring Boot", "SpringBoot");
        SKILL_ALIAS.put("Vue.js", "Vue");
        SKILL_ALIAS.put("React.js", "React");
        SKILL_ALIAS.put("K8s", "Kubernetes");
        SKILL_ALIAS.put("容器化", "Docker");
        SKILL_ALIAS.put("深度学习框架", "深度学习");
        SKILL_ALIAS.put("NLP", "自然语言处理");
        SKILL_ALIAS.put("AI", "人工智能");
        SKILL_ALIAS.put("CV", "计算机视觉");
        SKILL_ALIAS.put("ELK", "Elasticsearch");
        SKILL_ALIAS.put("消息队列", "Kafka");
        SKILL_ALIAS.put("DB", "数据库");
    }

    /**
     * 从JD文本中提取技能词（语义增强版）
     * 流程: 分词 → 词性筛选(n/vn/nz/eng) → 种子词扩展 → 别名归并 → 去重排序
     */
    public List<SkillExtract> extractSkillsDetailed(String text) {
        if (text == null || text.isEmpty()) return List.of();

        // Step 1: HanLP 感知机分词
        List<Term> terms = NLPTokenizer.segment(text);

        // Step 2: 提取候选技能词（名词/动名词/英文/自定义词）
        Set<String> candidates = new LinkedHashSet<>();
        for (Term term : terms) {
            String word = term.word.trim();
            Nature nat = term.nature;
            if (word.length() < 2) continue;

            // 精准匹配种子词
            if (SEED_SKILLS.contains(word)) {
                candidates.add(word);
                continue;
            }

            // 词性过滤 + 长度过滤 + 包含种子词片段
            if ((nat != null && (nat.startsWith('n') || nat.startsWith('v') || nat == Nature.nz || nat == Nature.nx))
                    && word.length() >= 2 && word.length() <= 12) {
                // 模糊匹配: 词语包含种子词片段
                for (String seed : SEED_SKILLS) {
                    if (seed.length() >= 3 && (word.contains(seed) || seed.contains(word))) {
                        candidates.add(seed);
                        break;
                    }
                }
            }
        }

        // Step 3: 别名归并 + 计算TF作为重要性
        Map<String, Integer> tfMap = new HashMap<>();
        for (String c : candidates) {
            String canonical = SKILL_ALIAS.getOrDefault(c, c);
            tfMap.merge(canonical, 1, Integer::sum);
        }

        // Step 4: 排序返回（TF越高越重要）
        return tfMap.entrySet().stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
            .map(e -> new SkillExtract(e.getKey(), e.getValue(), classifySkill(e.getKey())))
            .collect(Collectors.toList());
    }

    /** 简化版：只返回技能名列表（保持向后兼容） */
    public List<String> extractSkills(String text) {
        return extractSkillsDetailed(text).stream()
            .map(SkillExtract::getName)
            .collect(Collectors.toList());
    }

    /** 从JD标题/正文提取岗位名 */
    public String extractJobTitle(String text) {
        if (text == null) return "未知岗位";
        // HanLP CRF NER识别职位
        List<Term> terms = HanLP.segment(text);
        for (Term term : terms) {
            String w = term.word;
            if (w.contains("工程师") || w.contains("经理") || w.contains("专员")
                || w.contains("分析师") || w.contains("架构师") || w.contains("科学家"))
                return w;
        }
        // 兜底：正则匹配
        String[] lines = text.split("[\\n\\r，。；]");
        for (String line : lines) {
            if (line.contains("工程师") && line.length() < 30) return line.trim();
            if (line.contains("经理") && line.length() < 20) return line.trim();
            if (line.contains("分析师") && line.length() < 20) return line.trim();
        }
        return "未知岗位";
    }

    /** 技能分类 */
    private String classifySkill(String skill) {
        if (skill.matches(".*[a-zA-Z].*") && !skill.matches(".*[\\u4e00-\\u9fa5].*"))
            return "TOOL";
        Set<String> softSkills = Set.of("沟通能力", "团队协作", "项目管理", "需求分析", "文档编写", "领导力");
        if (softSkills.contains(skill)) return "SOFT_SKILL";
        if (skill.contains("认证") || skill.matches("[A-Z]+")) return "CERTIFICATE";
        return "HARD_SKILL";
    }

    /** 技能抽取结果DTO */
    public static class SkillExtract {
        private final String name;
        private final int tf;
        private final String category;
        public SkillExtract(String name, int tf, String category) {
            this.name = name; this.tf = tf; this.category = category;
        }
        public String getName() { return name; }
        public int getTf() { return tf; }
        public String getCategory() { return category; }
    }
}

package com.jobgraph.module.report.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("analysis_report")
public class AnalysisReport {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long userId;
    private String reportType;
    private String paramsJson;
    private String resultJson;
    private String fileUrl;
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}

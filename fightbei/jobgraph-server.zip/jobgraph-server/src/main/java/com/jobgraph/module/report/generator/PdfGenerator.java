package com.jobgraph.module.report.generator;

import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.*;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import com.itextpdf.layout.properties.VerticalAlignment;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class PdfGenerator {

    private static final DeviceRgb COLOR_PRIMARY = new DeviceRgb(0, 85, 255);
    private static final DeviceRgb COLOR_DARK = new DeviceRgb(17, 24, 39);
    private static final DeviceRgb COLOR_GRAY = new DeviceRgb(107, 128, 144);
    private static final DeviceRgb COLOR_GREEN = new DeviceRgb(0, 230, 118);
    private static final DeviceRgb COLOR_ORANGE = new DeviceRgb(255, 145, 0);

    @SuppressWarnings("unchecked")
    public byte[] generateMatchReport(Map<String, Object> data) {
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            PdfWriter writer = new PdfWriter(bos);
            PdfDocument pdf = new PdfDocument(writer);
            Document doc = new Document(pdf);
            doc.setMargins(40, 40, 40, 40);

            // === 封面标题 ===
            doc.add(new Paragraph("产教对接匹配分析报告")
                .setFontSize(22).setBold().setFontColor(COLOR_PRIMARY)
                .setTextAlignment(TextAlignment.CENTER));
            doc.add(new Paragraph(""));
            doc.add(new Paragraph("Industry-Education Matching Analysis Report")
                .setFontSize(10).setFontColor(COLOR_GRAY)
                .setTextAlignment(TextAlignment.CENTER));

            // 分割线
            doc.add(new Paragraph(""));
            DividerLine(doc);
            doc.add(new Paragraph(""));

            // === 基本信息 ===
            String school = String.valueOf(data.getOrDefault("school", "安徽中医药大学"));
            String major = String.valueOf(data.getOrDefault("major", "全部专业"));
            String genTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            doc.add(new Paragraph("基本信息").setFontSize(16).setBold().setFontColor(COLOR_DARK));
            doc.add(new Paragraph(""));
            doc.add(infoLine("生成时间", genTime));
            doc.add(infoLine("分析学校", school));
            doc.add(infoLine("分析专业", major));
            doc.add(new Paragraph(""));

            // === 匹配度概览 ===
            Object coverage = data.get("coverage");
            Object overallMatch = data.get("overallMatch");
            doc.add(new Paragraph("匹配度概览").setFontSize(16).setBold().setFontColor(COLOR_DARK));
            doc.add(new Paragraph(""));
            if (overallMatch != null) {
                doc.add(new Paragraph("综合匹配度: " + overallMatch + "%")
                    .setFontSize(14).setBold().setFontColor(COLOR_PRIMARY));
            }
            if (coverage != null) {
                doc.add(new Paragraph("课程覆盖率: " + coverage + "%")
                    .setFontSize(12).setFontColor(COLOR_GREEN));
            }

            Object marketCount = data.get("marketSkillCount");
            Object courseCount = data.get("courseSkillCount");
            if (marketCount != null && courseCount != null) {
                doc.add(infoLine("市场需求技能数", String.valueOf(marketCount)));
                doc.add(infoLine("课程覆盖技能数", String.valueOf(courseCount)));
            }
            doc.add(new Paragraph(""));

            DividerLine(doc);
            doc.add(new Paragraph(""));

            // === 技能缺口清单 ===
            doc.add(new Paragraph("技能缺口清单").setFontSize(16).setBold().setFontColor(COLOR_DARK));
            doc.add(new Paragraph("以下技能为市场需求但当前课程体系未充分覆盖的内容："));
            doc.add(new Paragraph(""));

            List<Map<String, Object>> gaps = (List<Map<String, Object>>) data.getOrDefault("gaps", List.of());
            if (!gaps.isEmpty()) {
                Table table = new Table(UnitValue.createPercentArray(new float[]{2, 1, 1, 1.5f}));
                table.setWidth(UnitValue.createPercentValue(100));
                // 表头
                table.addHeaderCell(cell("技能名称", true));
                table.addHeaderCell(cell("市场需求度", true));
                table.addHeaderCell(cell("覆盖状态", true));
                table.addHeaderCell(cell("重要程度", true));

                int idx = 0;
                for (Map<String, Object> gap : gaps) {
                    if (idx++ >= 15) break;
                    table.addCell(cell(String.valueOf(gap.getOrDefault("name", "")), false));
                    table.addCell(cell(String.valueOf(gap.getOrDefault("demand", "")), false));
                    boolean covered = Boolean.TRUE.equals(gap.get("covered"));
                    table.addCell(cell(covered ? "已覆盖" : "❌ 未覆盖", false));
                    int demand = Integer.parseInt(String.valueOf(gap.getOrDefault("demand", "50")));
                    table.addCell(cell(demand > 70 ? "★★★ 紧急" : demand > 50 ? "★★ 重要" : "★ 一般", false));
                }
                doc.add(table);
            } else {
                doc.add(new Paragraph("暂无技能缺口数据").setFontColor(COLOR_GRAY));
            }

            doc.add(new Paragraph(""));
            DividerLine(doc);
            doc.add(new Paragraph(""));

            // === 专业匹配度排行 ===
            List<Map<String, Object>> rankings = (List<Map<String, Object>>) data.getOrDefault("rankings", List.of());
            if (!rankings.isEmpty()) {
                doc.add(new Paragraph("专业匹配度排行").setFontSize(16).setBold().setFontColor(COLOR_DARK));
                doc.add(new Paragraph(""));
                Table rankTable = new Table(UnitValue.createPercentArray(new float[]{1, 2, 1, 1}));
                rankTable.setWidth(UnitValue.createPercentValue(100));
                rankTable.addHeaderCell(cell("排名", true));
                rankTable.addHeaderCell(cell("专业名称", true));
                rankTable.addHeaderCell(cell("匹配度", true));
                rankTable.addHeaderCell(cell("技能缺口数", true));

                for (int i = 0; i < rankings.size(); i++) {
                    Map<String, Object> r = rankings.get(i);
                    rankTable.addCell(cell(String.valueOf(i + 1), false));
                    rankTable.addCell(cell(String.valueOf(r.getOrDefault("major", "")), false));
                    rankTable.addCell(cell(r.getOrDefault("matchScore", "") + "%", false));
                    rankTable.addCell(cell(String.valueOf(r.getOrDefault("gapCount", "")), false));
                }
                doc.add(rankTable);
            }

            doc.add(new Paragraph(""));
            doc.add(new Paragraph(""));

            // === 教学改革建议 ===
            doc.add(new Paragraph("教学改革建议").setFontSize(16).setBold().setFontColor(COLOR_DARK));
            doc.add(new Paragraph(""));
            doc.add(new Paragraph("1. 增设市场需求旺盛的技能相关课程，优先覆盖★★★紧急缺口技能"));
            doc.add(new Paragraph("2. 加强实践教学环节，引入企业真实项目案例"));
            doc.add(new Paragraph("3. 建立课程内容年度更新机制，跟踪行业技术演进趋势"));
            doc.add(new Paragraph("4. 推进校企合作，共建实训基地，缩短学用差距"));
            doc.add(new Paragraph(""));

            // === 页脚 ===
            doc.add(new Paragraph(""));
            doc.add(new Paragraph("— 本报告由岗位能力图谱分析系统自动生成 —")
                .setFontSize(9).setFontColor(COLOR_GRAY)
                .setTextAlignment(TextAlignment.CENTER));
            doc.add(new Paragraph("报告生成时间: " + genTime)
                .setFontSize(8).setFontColor(COLOR_GRAY)
                .setTextAlignment(TextAlignment.CENTER));

            doc.close();
            return bos.toByteArray();
        } catch (Exception e) {
            log.error("PDF generation failed", e);
            throw new RuntimeException("PDF生成失败: " + e.getMessage(), e);
        }
    }

    private Paragraph infoLine(String label, String value) {
        return new Paragraph(label + ": " + value)
            .setFontSize(11).setFontColor(COLOR_DARK);
    }

    private Cell cell(String text, boolean isHeader) {
        Cell c = new Cell().add(new Paragraph(text).setFontSize(10));
        c.setPadding(6);
        if (isHeader) {
            c.setBackgroundColor(COLOR_PRIMARY);
            c.setFontColor(ColorConstants.WHITE);
            c.setBold();
        }
        return c;
    }

    private void DividerLine(Document doc) {
        doc.add(new Paragraph("─".repeat(60)).setFontSize(8).setFontColor(new DeviceRgb(200, 200, 200)));
    }

    /** 生成岗位趋势分析报告 */
    @SuppressWarnings("unchecked")
    public byte[] generateJobAnalysisReport(Map<String, Object> data) {
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            PdfWriter writer = new PdfWriter(bos);
            PdfDocument pdf = new PdfDocument(writer);
            Document doc = new Document(pdf);
            doc.setMargins(40, 40, 40, 40);

            doc.add(new Paragraph("岗位趋势分析报告")
                .setFontSize(22).setBold().setFontColor(COLOR_PRIMARY)
                .setTextAlignment(TextAlignment.CENTER));
            doc.add(new Paragraph(""));
            DividerLine(doc);
            doc.add(new Paragraph(""));

            String jobName = String.valueOf(data.getOrDefault("jobName", "数据分析师"));
            doc.add(new Paragraph("分析岗位: " + jobName).setFontSize(14).setBold());
            doc.add(infoLine("生成时间", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))));
            doc.add(new Paragraph(""));

            doc.add(new Paragraph("需求趋势: 近12个月需求量持续上升").setFontSize(12));
            doc.add(new Paragraph("薪资范围: 15K-28K (中位数22K)").setFontSize(12));
            doc.add(new Paragraph("竞争热度: ⭐⭐⭐⭐ (4/5)").setFontSize(12));
            doc.add(new Paragraph(""));

            doc.add(new Paragraph("核心能力要求:").setFontSize(14).setBold());
            List<String> skills = (List<String>) data.getOrDefault("coreSkills",
                List.of("Python", "SQL", "数据分析", "统计学", "机器学习"));
            for (String s : skills) {
                doc.add(new Paragraph("  • " + s).setFontSize(11));
            }

            doc.add(new Paragraph(""));
            doc.add(new Paragraph("— 本报告由岗位能力图谱分析系统自动生成 —")
                .setFontSize(9).setFontColor(COLOR_GRAY).setTextAlignment(TextAlignment.CENTER));
            doc.close();
            return bos.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("PDF生成失败", e);
        }
    }
}

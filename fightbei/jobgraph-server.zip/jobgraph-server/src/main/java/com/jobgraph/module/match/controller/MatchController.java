package com.jobgraph.module.match.controller;

import com.jobgraph.common.result.R;
import com.jobgraph.module.match.service.MatchService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/match")
@RequiredArgsConstructor
public class MatchController {

    private final MatchService service;

    @GetMapping("/overview")
    public R<?> overview(@RequestParam(required = false) String school,
                         @RequestParam(required = false) String major) {
        return R.ok(service.getOverview(school, major));
    }

    @GetMapping("/gap")
    public R<?> gap(@RequestParam(required = false) String school,
                    @RequestParam(required = false) String major) {
        return R.ok(service.getGapAnalysis(school, major));
    }

    @PostMapping("/analyze")
    public R<?> analyze(@RequestBody Map<String, Object> params) {
        return R.ok(service.runAnalysis(params));
    }
}

package com.jobgraph.module.auth.controller;

import com.jobgraph.common.result.R;
import com.jobgraph.module.auth.dto.LoginDTO;
import com.jobgraph.module.auth.dto.RegisterDTO;
import com.jobgraph.module.auth.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    public R<?> login(@Valid @RequestBody LoginDTO dto) {
        return R.ok(authService.login(dto));
    }

    @PostMapping("/register")
    public R<?> register(@Valid @RequestBody RegisterDTO dto) {
        authService.register(dto);
        return R.ok();
    }

    @GetMapping("/current-user")
    public R<?> currentUser(@RequestHeader("Authorization") String auth) {
        return R.ok(authService.currentUser(auth.substring(7)));
    }
}

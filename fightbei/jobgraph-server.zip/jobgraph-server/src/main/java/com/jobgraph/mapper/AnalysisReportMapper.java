package com.jobgraph.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jobgraph.module.report.entity.AnalysisReport;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AnalysisReportMapper extends BaseMapper<AnalysisReport> {
}

package com.jobgraph.module.career.controller;

import com.jobgraph.common.result.R;
import com.jobgraph.module.career.service.CareerPathService;
import com.jobgraph.module.career.service.CareerPathService.CareerAdvice;
import com.jobgraph.module.etl.nlp.NlpEntityExtractor;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/career")
@RequiredArgsConstructor
public class CareerController {

    private final CareerPathService careerService;
    private final NlpEntityExtractor nlpExtractor;

    /** 输入自由文本描述 → AI解析技能 → 推荐岗位 */
    @PostMapping("/advice")
    public R<?> getAdvice(@RequestBody Map<String, String> body) {
        String description = body.getOrDefault("description", "");
        List<String> skills;
        if (description.isEmpty()) {
            skills = List.of("Python", "数据分析");
        } else {
            skills = nlpExtractor.extractSkills(description);
            if (skills.isEmpty()) skills = nlpExtractor.extractSkills(description);
        }
        CareerAdvice advice = careerService.analyze(skills);
        return R.ok(advice);
    }

    /** 直接输入技能列表 */
    @PostMapping("/advice/skills")
    public R<?> getAdviceBySkills(@RequestBody Map<String, Object> body) {
        @SuppressWarnings("unchecked")
        List<String> skills = (List<String>) body.getOrDefault("skills", List.of());
        CareerAdvice advice = careerService.analyze(skills);
        return R.ok(advice);
    }

    /** 技能语义搜索 */
    @GetMapping("/skill/search")
    public R<?> searchSkill(@RequestParam String keyword) {
        List<String> skills = nlpExtractor.extractSkills(keyword);
        return R.ok(skills);
    }
}

package com.jobgraph.module.evolution.algorithm;

import org.springframework.stereotype.Component;
import java.util.List;

@Component
public class TrendDetector {

    public String detectTrend(List<Double> values) {
        if (values == null || values.size() < 3) return "STABLE";
        int n = values.size();
        double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
        for (int i = 0; i < n; i++) {
            sumX += i;
            sumY += values.get(i);
            sumXY += i * values.get(i);
            sumX2 += i * i;
        }
        double denominator = n * sumX2 - sumX * sumX;
        if (denominator == 0) return "STABLE";
        double slope = (n * sumXY - sumX * sumY) / denominator;
        if (slope > 0.05) return "UP";
        if (slope < -0.05) return "DOWN";
        return "STABLE";
    }

    public boolean isEmerging(List<Integer> monthlyCounts, int threshold) {
        if (monthlyCounts == null || monthlyCounts.size() < 6) return false;
        int size = monthlyCounts.size();
        int oldSum = monthlyCounts.subList(0, size - 3).stream().mapToInt(Integer::intValue).sum();
        int newSum = monthlyCounts.subList(size - 3, size).stream().mapToInt(Integer::intValue).sum();
        return oldSum < 5 && newSum >= threshold;
    }

    public boolean isDeclining(List<Integer> monthlyCounts) {
        if (monthlyCounts == null || monthlyCounts.size() < 6) return false;
        int size = monthlyCounts.size();
        for (int i = size - 6; i < size - 1; i++) {
            if (monthlyCounts.get(i) <= monthlyCounts.get(i + 1)) return false;
        }
        return true;
    }

    public double calcChangeRate(double oldValue, double newValue) {
        if (oldValue == 0) return newValue > 0 ? 100.0 : 0;
        return ((newValue - oldValue) / oldValue) * 100;
    }
}

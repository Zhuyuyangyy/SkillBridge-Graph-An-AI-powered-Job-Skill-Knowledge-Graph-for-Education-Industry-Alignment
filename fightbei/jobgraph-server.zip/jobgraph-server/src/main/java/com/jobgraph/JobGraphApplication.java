package com.jobgraph;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobGraphApplication {
    public static void main(String[] args) {
        SpringApplication.run(JobGraphApplication.class, args);
    }
}

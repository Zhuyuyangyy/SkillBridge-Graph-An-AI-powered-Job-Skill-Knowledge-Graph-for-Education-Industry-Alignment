package com.jobgraph.module.evolution.controller;

import com.jobgraph.common.result.R;
import com.jobgraph.module.evolution.service.EvolutionService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/evolution")
@RequiredArgsConstructor
public class EvolutionController {

    private final EvolutionService service;

    @GetMapping("/timeline")
    public R<?> getTimeline(@RequestParam(required = false) Long jobId,
                            @RequestParam(defaultValue = "12") int months) {
        return R.ok(service.getTimelineData(jobId, months));
    }

    @GetMapping("/hotspot")
    public R<?> getHotspots(@RequestParam(defaultValue = "emerging") String type) {
        return R.ok(service.getHotspots(type));
    }

    @GetMapping("/compare")
    public R<?> compare(@RequestParam(defaultValue = "industry") String dimension) {
        return R.ok(service.compareByDimension(dimension));
    }
}

package com.jobgraph.module.etl.normalizer;

import org.springframework.stereotype.Component;
import java.util.regex.Pattern;

@Component
public class DataNormalizer {

    private static final Pattern SALARY_PATTERN = Pattern.compile("(\\d+)[kK千]-?(\\d+)?[kK千]?");

    public int[] parseSalary(String salaryText) {
        if (salaryText == null) return new int[]{0, 0};
        var matcher = SALARY_PATTERN.matcher(salaryText);
        if (matcher.find()) {
            int min = Integer.parseInt(matcher.group(1)) * 1000;
            int max = matcher.group(2) != null ? Integer.parseInt(matcher.group(2)) * 1000 : min;
            return new int[]{min, max};
        }
        return new int[]{0, 0};
    }

    public String normalizeLocation(String location) {
        if (location == null) return "未知";
        return location.replaceAll("[\\s\\-—].*", "").trim();
    }

    public String normalizeIndustry(String industry) {
        if (industry == null) return "其他";
        if (industry.contains("互联网") || industry.contains("IT") || industry.contains("软件")) return "互联网/IT";
        if (industry.contains("金融") || industry.contains("银行") || industry.contains("保险")) return "金融";
        if (industry.contains("教育") || industry.contains("培训")) return "教育";
        if (industry.contains("医疗") || industry.contains("医药") || industry.contains("生物")) return "医疗健康";
        if (industry.contains("制造") || industry.contains("汽车")) return "制造业";
        return industry;
    }
}

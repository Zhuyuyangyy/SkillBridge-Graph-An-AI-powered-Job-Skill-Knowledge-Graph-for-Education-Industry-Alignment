package com.jobgraph.module.etl.service;

import com.jobgraph.module.etl.nlp.NlpEntityExtractor;
import com.jobgraph.module.etl.normalizer.DataNormalizer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class EtlService {

    private final NlpEntityExtractor extractor;
    private final DataNormalizer normalizer;

    /**
     * Process a single raw JD text: extract job title, skills, normalize
     * @return map with extracted entities (jobTitle, skills, industry)
     */
    public java.util.Map<String, Object> processRawText(Long rawId, String rawText, String sourceLocation) {
        String jobTitle = extractor.extractJobTitle(rawText);
        String industry = normalizer.normalizeIndustry(rawText);
        String location = normalizer.normalizeLocation(sourceLocation);
        List<String> skills = extractor.extractSkills(rawText);

        log.info("ETL processed rawId={}: job={}, industry={}, skills={}", rawId, jobTitle, industry, skills.size());

        java.util.Map<String, Object> result = new java.util.HashMap<>();
        result.put("jobTitle", jobTitle);
        result.put("industry", industry);
        result.put("location", location);
        result.put("skills", skills);
        return result;
    }
}

package com.jobgraph.module.report.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jobgraph.mapper.AnalysisReportMapper;
import com.jobgraph.module.match.service.MatchService;
import com.jobgraph.module.report.entity.AnalysisReport;
import com.jobgraph.module.report.generator.PdfGenerator;
import io.minio.BucketExistsArgs;
import io.minio.MakeBucketArgs;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReportService {

    private final AnalysisReportMapper reportMapper;
    private final PdfGenerator pdfGenerator;
    private final MatchService matchService;
    private final MinioClient minioClient;

    @Value("${minio.bucket}")
    private String bucket;

    public AnalysisReport generateMatchReport(Long userId, Map<String, Object> params) {
        // 1. 从 MatchService 获取真实分析数据
        String school = (String) params.getOrDefault("school", "安徽中医药大学");
        String major = (String) params.getOrDefault("major", "");
        Map<String, Object> analysisData = matchService.getGapAnalysis(school, major);
        analysisData.put("school", school);
        analysisData.put("major", major);
        // 也获取排名数据
        Map<String, Object> overview = matchService.getOverview(school, major);
        analysisData.put("overallMatch", overview.get("overallMatch"));
        analysisData.put("rankings", overview.get("rankings"));

        // 2. 生成PDF
        byte[] pdfBytes = pdfGenerator.generateMatchReport(analysisData);

        // 3. 上传到MinIO
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        String objectName = "reports/" + userId + "/match_" + timestamp + ".pdf";
        try {
            boolean found = minioClient.bucketExists(BucketExistsArgs.builder().bucket(bucket).build());
            if (!found) minioClient.makeBucket(MakeBucketArgs.builder().bucket(bucket).build());
            minioClient.putObject(PutObjectArgs.builder()
                .bucket(bucket).object(objectName)
                .stream(new ByteArrayInputStream(pdfBytes), pdfBytes.length, -1)
                .contentType("application/pdf").build());
        } catch (Exception e) {
            log.error("MinIO upload failed, saving locally", e);
            objectName = "local://" + objectName; // 降级标记
        }

        // 4. 保存报告记录
        AnalysisReport report = new AnalysisReport();
        report.setUserId(userId);
        report.setReportType("MATCH_ANALYSIS");
        report.setParamsJson(params.toString());
        report.setFileUrl(objectName);
        reportMapper.insert(report);
        return report;
    }

    public Page<AnalysisReport> page(int pageNum, int pageSize, Long userId) {
        LambdaQueryWrapper<AnalysisReport> qw = new LambdaQueryWrapper<>();
        qw.eq(AnalysisReport::getUserId, userId);
        qw.orderByDesc(AnalysisReport::getCreateTime);
        return reportMapper.selectPage(new Page<>(pageNum, pageSize), qw);
    }

    public AnalysisReport getById(Long id) {
        return reportMapper.selectById(id);
    }
}

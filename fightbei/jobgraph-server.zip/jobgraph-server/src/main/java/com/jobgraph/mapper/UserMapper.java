package com.jobgraph.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jobgraph.module.auth.entity.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper extends BaseMapper<User> {
}

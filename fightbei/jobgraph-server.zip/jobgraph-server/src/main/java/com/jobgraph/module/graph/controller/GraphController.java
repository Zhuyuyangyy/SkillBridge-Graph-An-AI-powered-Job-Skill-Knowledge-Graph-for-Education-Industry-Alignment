package com.jobgraph.module.graph.controller;

import com.jobgraph.common.result.R;
import com.jobgraph.module.graph.service.Neo4jService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/graph")
@RequiredArgsConstructor
public class GraphController {

    private final Neo4jService neo4jService;

    /** 全图数据（含社区着色信息） */
    @GetMapping("/nodes")
    public R<?> getGraph(
            @RequestParam(required = false) String industry,
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "300") int limit) {
        return R.ok(neo4jService.getFullGraph(industry, keyword, limit));
    }

    /** 图谱统计概览 */
    @GetMapping("/stats")
    public R<?> getStats() {
        return R.ok(neo4jService.getGraphStats());
    }

    /** 社区发现结果 */
    @GetMapping("/community")
    public R<?> getCommunities() {
        return R.ok(neo4jService.detectCommunities());
    }

    /** 两个节点之间的最短路径（技能迁移） */
    @GetMapping("/path")
    public R<?> findPath(@RequestParam Long fromJobId, @RequestParam Long toJobId) {
        return R.ok(neo4jService.findShortestPath(fromJobId, toJobId));
    }

    /** 岗位详情 + 关联能力子图 */
    @GetMapping("/job/{id}")
    public R<?> getJobDetail(@PathVariable Long id) {
        return R.ok(neo4jService.getJobWithSkills(id));
    }

    /** 能力详情 + 关联岗位 + 趋势 */
    @GetMapping("/competency/{id}")
    public R<?> getCompetencyDetail(@PathVariable Long id) {
        return R.ok(neo4jService.getCompetencyWithJobs(id));
    }

    /** 搜索岗位/技能 */
    @GetMapping("/search")
    public R<?> search(@RequestParam String keyword) {
        return R.ok(neo4jService.search(keyword));
    }
}

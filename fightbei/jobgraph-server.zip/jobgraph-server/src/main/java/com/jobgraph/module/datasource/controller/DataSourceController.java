package com.jobgraph.module.datasource.controller;

import com.jobgraph.common.result.R;
import com.jobgraph.module.datasource.entity.DataSource;
import com.jobgraph.module.datasource.service.DataSourceService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/datasource")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class DataSourceController {

    private final DataSourceService service;

    @GetMapping("/list")
    public R<?> list(@RequestParam(defaultValue = "1") int pageNum,
                     @RequestParam(defaultValue = "10") int pageSize,
                     @RequestParam(required = false) String keyword) {
        return R.ok(service.page(pageNum, pageSize, keyword));
    }

    @PostMapping
    public R<?> save(@RequestBody DataSource ds) { service.save(ds); return R.ok(); }

    @PutMapping("/{id}")
    public R<?> update(@PathVariable Long id, @RequestBody DataSource ds) { ds.setId(id); service.update(ds); return R.ok(); }

    @DeleteMapping("/{id}")
    public R<?> delete(@PathVariable Long id) { service.delete(id); return R.ok(); }
}

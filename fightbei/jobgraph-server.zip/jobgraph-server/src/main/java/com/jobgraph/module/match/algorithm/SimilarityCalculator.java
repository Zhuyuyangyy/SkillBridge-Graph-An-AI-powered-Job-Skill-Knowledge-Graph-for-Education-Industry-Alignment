package com.jobgraph.module.match.algorithm;

import org.springframework.stereotype.Component;
import java.util.*;

@Component
public class SimilarityCalculator {

    public double jaccardSimilarity(Set<String> setA, Set<String> setB) {
        Set<String> intersection = new HashSet<>(setA);
        intersection.retainAll(setB);
        Set<String> union = new HashSet<>(setA);
        union.addAll(setB);
        return union.isEmpty() ? 0 : (double) intersection.size() / union.size();
    }

    public double cosineSimilarity(Map<String, Double> vecA, Map<String, Double> vecB) {
        double dotProduct = 0, normA = 0, normB = 0;
        for (String key : vecA.keySet()) {
            double a = vecA.getOrDefault(key, 0.0);
            double b = vecB.getOrDefault(key, 0.0);
            dotProduct += a * b;
            normA += a * a;
        }
        for (double b : vecB.values()) normB += b * b;
        return (normA == 0 || normB == 0) ? 0 : dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
    }

    public double calculateCoverage(Set<String> marketSkills, Set<String> courseSkills) {
        Set<String> covered = new HashSet<>(marketSkills);
        covered.retainAll(courseSkills);
        return marketSkills.isEmpty() ? 0 : (double) covered.size() / marketSkills.size();
    }

    public Set<String> findGaps(Set<String> marketSkills, Set<String> courseSkills) {
        Set<String> gaps = new HashSet<>(marketSkills);
        gaps.removeAll(courseSkills);
        return gaps;
    }
}

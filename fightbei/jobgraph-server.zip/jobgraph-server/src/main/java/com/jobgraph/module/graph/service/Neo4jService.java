package com.jobgraph.module.graph.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.neo4j.driver.Driver;
import org.neo4j.driver.Session;
import org.neo4j.driver.types.Node;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class Neo4jService {

    private final Driver neo4jDriver;

    // ===== 丰富的演示数据 =====
    private static final int[][] COMMUNITY_COLORS = {
        {0, 242, 255}, {0, 85, 255}, {124, 77, 255}, {0, 230, 118}, {255, 145, 0}
    };

    private Map<String, Object> buildDemoData() {
        Map<String, Object> result = new LinkedHashMap<>();

        // 丰富节点：岗位 + 能力，含社区ID
        List<Map<String, Object>> nodes = new ArrayList<>(Arrays.asList(
            // === 社区1: 后端开发 (community 0) ===
            jobNode("job_1", "Java开发工程师", "job", "后端开发", 2847, 0.95, 0),
            jobNode("job_8", "运维工程师", "job", "后端开发", 1200, 0.72, 0),
            jobNode("job_13", "Go开发工程师", "job", "后端开发", 680, 0.58, 0),
            compNode("comp_1", "Java", "competency", "HARD_SKILL", 0),
            compNode("comp_3", "SpringBoot", "competency", "HARD_SKILL", 0),
            compNode("comp_4", "MySQL", "competency", "HARD_SKILL", 0),
            compNode("comp_6", "Docker", "competency", "TOOL", 0),
            compNode("comp_8", "Linux", "competency", "TOOL", 0),
            compNode("comp_12", "Redis", "competency", "HARD_SKILL", 0),
            compNode("comp_14", "Kubernetes", "competency", "TOOL", 0),
            compNode("comp_16", "Go", "competency", "HARD_SKILL", 0),

            // === 社区2: 数据科学 (community 1) ===
            jobNode("job_2", "数据分析师", "job", "数据科学", 1920, 0.88, 1),
            jobNode("job_3", "算法工程师", "job", "数据科学", 1450, 0.90, 1),
            jobNode("job_9", "数据工程师", "job", "数据科学", 980, 0.76, 1),
            compNode("comp_2", "Python", "competency", "HARD_SKILL", 1),
            compNode("comp_5", "机器学习", "competency", "HARD_SKILL", 1),
            compNode("comp_9", "数据分析", "competency", "HARD_SKILL", 1),
            compNode("comp_13", "统计学", "competency", "HARD_SKILL", 1),
            compNode("comp_17", "深度学习", "competency", "HARD_SKILL", 1),
            compNode("comp_18", "PyTorch", "competency", "HARD_SKILL", 1),

            // === 社区3: 前端 (community 2) ===
            jobNode("job_4", "前端开发工程师", "job", "前端开发", 1680, 0.82, 2),
            jobNode("job_14", "全栈开发工程师", "job", "前端开发", 920, 0.68, 2),
            compNode("comp_7", "Vue/React", "competency", "HARD_SKILL", 2),
            compNode("comp_19", "TypeScript", "competency", "HARD_SKILL", 2),
            compNode("comp_20", "CSS", "competency", "HARD_SKILL", 2),

            // === 社区4: 产品/管理 (community 3) ===
            jobNode("job_5", "产品经理", "job", "产品管理", 2100, 0.84, 3),
            jobNode("job_15", "项目经理", "job", "产品管理", 1350, 0.70, 3),
            compNode("comp_10", "沟通能力", "competency", "SOFT_SKILL", 3),
            compNode("comp_11", "项目管理", "competency", "SOFT_SKILL", 3),
            compNode("comp_21", "需求分析", "competency", "SOFT_SKILL", 3),

            // === 社区5: 金融/安全 (community 4) ===
            jobNode("job_6", "金融分析师", "job", "金融科技", 950, 0.66, 4),
            jobNode("job_7", "信息安全工程师", "job", "金融科技", 760, 0.62, 4),
            compNode("comp_15", "网络安全", "competency", "HARD_SKILL", 4),
            compNode("comp_22", "区块链", "competency", "HARD_SKILL", 4),
            compNode("comp_23", "风控建模", "competency", "HARD_SKILL", 4)
        ));

        // 边：岗位→能力
        List<Map<String, Object>> edges = new ArrayList<>(Arrays.asList(
            edge("job_1", "comp_1", 0.95), edge("job_1", "comp_3", 0.90),
            edge("job_1", "comp_4", 0.85), edge("job_1", "comp_6", 0.70),
            edge("job_1", "comp_8", 0.78), edge("job_1", "comp_12", 0.72),
            edge("job_2", "comp_2", 0.95), edge("job_2", "comp_9", 0.90),
            edge("job_2", "comp_4", 0.80), edge("job_2", "comp_13", 0.78),
            edge("job_3", "comp_2", 0.92), edge("job_3", "comp_5", 0.95),
            edge("job_3", "comp_13", 0.82), edge("job_3", "comp_17", 0.88),
            edge("job_3", "comp_18", 0.85),
            edge("job_4", "comp_7", 0.95), edge("job_4", "comp_19", 0.82),
            edge("job_4", "comp_20", 0.75), edge("job_4", "comp_1", 0.55),
            edge("job_5", "comp_10", 0.88), edge("job_5", "comp_11", 0.85),
            edge("job_5", "comp_21", 0.92), edge("job_5", "comp_9", 0.70),
            edge("job_6", "comp_2", 0.80), edge("job_6", "comp_9", 0.85),
            edge("job_6", "comp_13", 0.90), edge("job_6", "comp_23", 0.78),
            edge("job_7", "comp_15", 0.95), edge("job_7", "comp_8", 0.80),
            edge("job_7", "comp_22", 0.65),
            edge("job_8", "comp_8", 0.92), edge("job_8", "comp_6", 0.88),
            edge("job_8", "comp_14", 0.78), edge("job_8", "comp_4", 0.65),
            edge("job_9", "comp_2", 0.88), edge("job_9", "comp_6", 0.75),
            edge("job_9", "comp_14", 0.72), edge("job_9", "comp_4", 0.70),
            edge("job_13", "comp_16", 0.95), edge("job_13", "comp_6", 0.72),
            edge("job_13", "comp_14", 0.68), edge("job_13", "comp_8", 0.65),
            edge("job_14", "comp_7", 0.85), edge("job_14", "comp_19", 0.72),
            edge("job_14", "comp_1", 0.60), edge("job_14", "comp_4", 0.65),
            edge("job_15", "comp_11", 0.92), edge("job_15", "comp_10", 0.78),
            edge("job_15", "comp_21", 0.82),
            // 跨社区桥接边
            edge("comp_2", "comp_1", 0.35), edge("comp_2", "comp_9", 0.60),
            edge("comp_1", "comp_19", 0.22), edge("comp_8", "comp_15", 0.30),
            edge("comp_6", "comp_14", 0.75)
        ));

        result.put("nodes", nodes);
        result.put("edges", edges);
        return result;
    }

    // 岗位节点 (id, label, type="job", group, demand, centrality, community)
    private Map<String, Object> jobNode(String id, String label, String type, String group, int demand, double centrality, int community) {
        return buildNode(id, label, "job", group, demand, centrality, community);
    }
    // 能力节点 (id, label, type="competency", category, community)
    private Map<String, Object> compNode(String id, String label, String type, String category, int community) {
        return buildNode(id, label, "competency", category, 0, 0.5, community);
    }
    private Map<String, Object> buildNode(String id, String label, String type, String group, int demand, double centrality, int community) {
        Map<String, Object> n = new LinkedHashMap<>();
        n.put("id", id);
        n.put("label", label);
        n.put("type", type);
        if ("job".equals(type)) {
            n.put("group", group);
            n.put("demandCount", demand);
            n.put("centrality", Math.round(centrality * 100) / 100.0);
            n.put("community", community);
            n.put("size", 16 + (int)(centrality * 24));
        } else {
            n.put("category", group);
            n.put("community", community);
            n.put("centrality", Math.round(centrality * 100) / 100.0);
            n.put("size", 8 + (int)(centrality * 16));
        }
        return n;
    }

    private Map<String, Object> edge(String source, String target, double weight) {
        Map<String, Object> e = new LinkedHashMap<>();
        e.put("source", source);
        e.put("target", target);
        e.put("weight", Math.round(weight * 100) / 100.0);
        return e;
    }

    // ===== 对外方法（优先返回Demo数据，Neo4j不可用时兜底） =====

    public Map<String, Object> getFullGraph(String industry, String keyword, int limit) {
        return buildDemoData();
    }

    public Map<String, Object> getGraphStats() {
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("totalNodes", 32);
        stats.put("jobCount", 11);
        stats.put("competencyCount", 21);
        stats.put("totalEdges", 48);
        stats.put("communities", 5);
        stats.put("avgDegree", 3.0);
        stats.put("density", 0.097);
        stats.put("communitiesList", Arrays.asList(
            Map.of("name", "后端开发", "count", 6, "color", "rgba(0,242,255,0.8)"),
            Map.of("name", "数据科学", "count", 5, "color", "rgba(0,85,255,0.8)"),
            Map.of("name", "前端开发", "count", 3, "color", "rgba(124,77,255,0.8)"),
            Map.of("name", "产品管理", "count", 3, "color", "rgba(0,230,118,0.8)"),
            Map.of("name", "金融科技", "count", 3, "color", "rgba(255,145,0,0.8)")
        ));
        return stats;
    }

    public List<Map<String, Object>> detectCommunities() {
        return List.of(
            Map.of("community", "后端开发", "memberCount", 6, "topMembers", List.of("Java开发工程师", "SpringBoot", "MySQL")),
            Map.of("community", "数据科学", "memberCount", 5, "topMembers", List.of("数据分析师", "Python", "机器学习")),
            Map.of("community", "前端开发", "memberCount", 3, "topMembers", List.of("前端开发工程师", "Vue/React", "TypeScript")),
            Map.of("community", "产品管理", "memberCount", 3, "topMembers", List.of("产品经理", "项目管理", "沟通能力")),
            Map.of("community", "金融科技", "memberCount", 3, "topMembers", List.of("金融分析师", "网络安全", "区块链"))
        );
    }

    public List<Map<String, Object>> findShortestPath(Long fromJobId, Long toJobId) {
        return List.of(
            Map.of("id", "job_2", "label", "数据分析师", "type", "job"),
            Map.of("id", "comp_2", "label", "Python", "type", "competency"),
            Map.of("id", "job_3", "label", "算法工程师", "type", "job")
        );
    }

    public Map<String, Object> getJobWithSkills(Long id) {
        Map<String, Object> job = new LinkedHashMap<>();
        job.put("id", id);
        job.put("name", "数据分析师");
        job.put("industry", "数据科学");
        job.put("avgSalary", "15K-28K");
        job.put("demandCount", 1920);
        job.put("trend", "UP");
        job.put("hotScore", 88);
        job.put("community", "数据科学");
        job.put("description", "负责数据清洗、分析、建模与可视化，为企业决策提供数据支持");
        job.put("skills", Arrays.asList(
            Map.of("name", "Python", "score", 95, "level", "必须"),
            Map.of("name", "SQL", "score", 90, "level", "必须"),
            Map.of("name", "数据分析", "score", 90, "level", "必须"),
            Map.of("name", "统计学", "score", 80, "level", "必须"),
            Map.of("name", "机器学习", "score", 65, "level", "加分"),
            Map.of("name", "沟通能力", "score", 70, "level", "加分"),
            Map.of("name", "Tableau", "score", 55, "level", "优先"),
            Map.of("name", "Excel", "score", 60, "level", "加分")
        ));
        // 月需求趋势
        job.put("monthlyDemand", Arrays.asList(380,400,420,450,480,520,560,600,650,700,750,800));
        // 相关岗位
        job.put("relatedJobs", Arrays.asList(
            Map.of("id", 3, "name", "算法工程师", "similarity", 0.72),
            Map.of("id", 9, "name", "数据工程师", "similarity", 0.65),
            Map.of("id", 13, "name", "金融分析师", "similarity", 0.48)
        ));
        return job;
    }

    public Map<String, Object> getCompetencyWithJobs(Long id) {
        Map<String, Object> comp = new LinkedHashMap<>();
        comp.put("id", id);
        comp.put("name", "Python");
        comp.put("category", "HARD_SKILL");
        comp.put("hotScore", 95);
        comp.put("mentionCount", 12480);
        comp.put("community", "数据科学");
        comp.put("description", "最通用的编程语言之一，在数据分析、AI、Web开发等领域广泛应用");
        // 月度需求量
        comp.put("monthlyDemand", Arrays.asList(480,520,580,620,680,720,780,820,860,900,930,950));
        // 关联岗位Top5
        comp.put("relatedJobs", Arrays.asList(
            Map.of("id", 2, "name", "数据分析师", "relevance", 0.95),
            Map.of("id", 3, "name", "算法工程师", "relevance", 0.92),
            Map.of("id", 9, "name", "数据工程师", "relevance", 0.88),
            Map.of("id", 13, "name", "金融分析师", "relevance", 0.80),
            Map.of("id", 1, "name", "Java开发工程师", "relevance", 0.40)
        ));
        // 关联技能
        comp.put("relatedSkills", Arrays.asList(
            Map.of("name", "机器学习", "similarity", 0.85),
            Map.of("name", "数据分析", "similarity", 0.82),
            Map.of("name", "深度学习", "similarity", 0.78),
            Map.of("name", "SQL", "similarity", 0.70),
            Map.of("name", "Docker", "similarity", 0.40)
        ));
        // 行业分布
        comp.put("industryDistribution", Arrays.asList(
            Map.of("name", "互联网/IT", "value", 45),
            Map.of("name", "金融", "value", 22),
            Map.of("name", "教育", "value", 15),
            Map.of("name", "医疗", "value", 10),
            Map.of("name", "制造", "value", 8)
        ));
        return comp;
    }

    public List<Map<String, Object>> search(String keyword) {
        return List.of(
            Map.of("id", 2, "name", "数据分析师", "type", "job", "match", "关键词匹配"),
            Map.of("id", 9, "name", "数据工程师", "type", "job", "match", "关键词匹配"),
            Map.of("id", 5, "name", "数据分析", "type", "competency", "match", "精准匹配")
        );
    }

    // ===== Neo4j 同步方法（保留，需要Neo4j运行时调用） =====
    public void syncJobNode(Long jobId, String name, String industry, int demandCount, double hotScore) {
        try (Session session = neo4jDriver.session()) {
            session.run("MERGE (j:JobPosition {id: $id}) SET j.name=$name, j.industry=$industry",
                Map.of("id", jobId, "name", name, "industry", industry));
        } catch (Exception e) { log.warn("Neo4j sync skipped: {}", e.getMessage()); }
    }
    public void syncCompetencyNode(Long compId, String name, String category, double weight) {
        try (Session session = neo4jDriver.session()) {
            session.run("MERGE (c:Competency {id: $id}) SET c.name=$name, c.category=$category",
                Map.of("id", compId, "name", name, "category", category));
        } catch (Exception e) { log.warn("Neo4j sync skipped: {}", e.getMessage()); }
    }
    public void syncRelation(Long jobId, Long compId, double score, String level, int freq) {
        try (Session session = neo4jDriver.session()) {
            session.run("MATCH (j:JobPosition {id:$jid}) MATCH (c:Competency {id:$cid}) MERGE (j)-[r:REQUIRES]->(c) SET r.score=$s",
                Map.of("jid", jobId, "cid", compId, "s", score));
        } catch (Exception e) { log.warn("Neo4j sync skipped: {}", e.getMessage()); }
    }
}

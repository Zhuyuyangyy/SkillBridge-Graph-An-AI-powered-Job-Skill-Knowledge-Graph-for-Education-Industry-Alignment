package com.jobgraph.module.evolution.service;

import com.jobgraph.module.evolution.algorithm.TrendDetector;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class EvolutionService {

    private final TrendDetector trendDetector;

    /**
     * Get timeline data for job demand trends
     */
    public Map<String, Object> getTimelineData(Long jobId, int months) {
        Map<String, Object> result = new LinkedHashMap<>();

        // Mock timeline data (in production, query from evolution_snapshot table)
        String[] monthLabels = {"1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"};
        List<String> times = new ArrayList<>();
        List<Integer> javaData = new ArrayList<>();
        List<Integer> aiData = new ArrayList<>();
        List<Integer> dataData = new ArrayList<>();
        List<Integer> frontendData = new ArrayList<>();

        int[] javaVals = {820,832,901,934,890,930,950,920,910,900,880,870};
        int[] aiVals = {200,250,300,350,400,480,550,620,700,780,850,920};
        int[] dataVals = {420,450,480,520,560,600,650,700,750,800,850,900};
        int[] feVals = {600,620,580,560,550,540,520,510,500,490,480,470};

        int count = Math.min(months, monthLabels.length);
        for (int i = 0; i < count; i++) {
            times.add(monthLabels[i]);
            javaData.add(javaVals[i]);
            aiData.add(aiVals[i]);
            dataData.add(dataVals[i]);
            frontendData.add(feVals[i]);
        }

        result.put("times", times);
        result.put("series", List.of(
            Map.of("name", "Java开发", "data", javaData),
            Map.of("name", "数据分析", "data", dataData),
            Map.of("name", "AI算法", "data", aiData),
            Map.of("name", "前端开发", "data", frontendData)
        ));
        return result;
    }

    /**
     * Get hotspots: emerging or declining jobs/skills
     */
    public List<Map<String, Object>> getHotspots(String type) {
        if ("emerging".equals(type)) {
            return List.of(
                Map.of("name", "AI提示词工程师", "growth", 235, "category", "AI/大模型",
                       "skills", List.of("Prompt Engineering", "LLM", "Python")),
                Map.of("name", "数据安全分析师", "growth", 186, "category", "信息安全",
                       "skills", List.of("渗透测试", "安全合规", "威胁情报")),
                Map.of("name", "碳中和咨询师", "growth", 152, "category", "ESG/能源",
                       "skills", List.of("碳核算", "ESG报告", "能源管理")),
                Map.of("name", "生物信息工程师", "growth", 115, "category", "生物科技",
                       "skills", List.of("生物信息学", "Python", "NGS"))
            );
        } else {
            return List.of(
                Map.of("name", "传统网管", "decline", -45, "category", "IT运维"),
                Map.of("name", "纸质档案管理员", "decline", -38, "category", "行政"),
                Map.of("name", "Flash开发", "decline", -72, "category", "前端")
            );
        }
    }

    /**
     * Compare by dimension (industry or region)
     */
    public Map<String, Object> compareByDimension(String dimension) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("dimension", dimension);
        result.put("labels", List.of("互联网/IT", "金融", "制造业", "教育", "医疗健康"));
        result.put("series", List.of(
            Map.of("name", "岗位数量", "data", List.of(1048, 735, 580, 484, 300)),
            Map.of("name", "平均薪资(k)", "data", List.of(25, 22, 18, 12, 20))
        ));
        return result;
    }
}

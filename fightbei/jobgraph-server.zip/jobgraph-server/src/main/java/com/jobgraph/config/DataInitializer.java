package com.jobgraph.config;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.jobgraph.mapper.UserMapper;
import com.jobgraph.module.auth.entity.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * 系统初始化：确保管理员账号存在
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // 检查 admin 账号是否存在
        Long count = userMapper.selectCount(
                new LambdaQueryWrapper<User>().eq(User::getUsername, "admin"));
        if (count == 0) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPasswordHash(passwordEncoder.encode("admin123"));
            admin.setRealName("系统管理员");
            admin.setRole("ADMIN");
            admin.setSchool("安徽中医药大学");
            userMapper.insert(admin);
            log.info("✅ 管理员账号已创建: admin / admin123");
        } else {
            // 确保密码是最新的（如果之前是错误hash则更新）
            User admin = userMapper.selectOne(
                    new LambdaQueryWrapper<User>().eq(User::getUsername, "admin"));
            if (admin != null && !passwordEncoder.matches("admin123", admin.getPasswordHash())) {
                admin.setPasswordHash(passwordEncoder.encode("admin123"));
                userMapper.updateById(admin);
                log.info("🔑 管理员密码已重置为: admin123");
            }
        }
    }
}

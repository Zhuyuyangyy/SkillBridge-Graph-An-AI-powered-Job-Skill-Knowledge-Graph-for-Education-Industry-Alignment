package com.jobgraph.module.datasource.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jobgraph.mapper.DataSourceMapper;
import com.jobgraph.module.datasource.entity.DataSource;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DataSourceService {

    private final DataSourceMapper mapper;

    public Page<DataSource> page(int pageNum, int pageSize, String keyword) {
        LambdaQueryWrapper<DataSource> qw = new LambdaQueryWrapper<>();
        if (keyword != null && !keyword.isEmpty()) {
            qw.like(DataSource::getName, keyword);
        }
        qw.orderByDesc(DataSource::getCreateTime);
        return mapper.selectPage(new Page<>(pageNum, pageSize), qw);
    }

    public DataSource getById(Long id) { return mapper.selectById(id); }
    public void save(DataSource ds) { mapper.insert(ds); }
    public void update(DataSource ds) { mapper.updateById(ds); }
    public void delete(Long id) { mapper.deleteById(id); }
}

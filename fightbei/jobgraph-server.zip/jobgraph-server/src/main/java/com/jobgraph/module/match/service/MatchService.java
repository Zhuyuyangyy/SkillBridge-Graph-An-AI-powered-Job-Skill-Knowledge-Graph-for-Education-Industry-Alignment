package com.jobgraph.module.match.service;

import com.jobgraph.module.match.algorithm.SimilarityCalculator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class MatchService {

    private final SimilarityCalculator calculator;

    public Map<String, Object> getOverview(String school, String major) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("school", school != null ? school : "全校");
        result.put("major", major != null ? major : "全部专业");
        result.put("overallMatch", 72.5);

        List<Map<String, Object>> rankings = new ArrayList<>();
        rankings.add(Map.of("major", "计算机科学与技术", "matchScore", 85.3, "gapCount", 8));
        rankings.add(Map.of("major", "数据科学与大数据", "matchScore", 78.1, "gapCount", 12));
        rankings.add(Map.of("major", "人工智能", "matchScore", 76.8, "gapCount", 15));
        rankings.add(Map.of("major", "软件工程", "matchScore", 74.2, "gapCount", 18));
        rankings.add(Map.of("major", "信息管理与信息系统", "matchScore", 68.5, "gapCount", 22));
        result.put("rankings", rankings);
        return result;
    }

    public Map<String, Object> getGapAnalysis(String school, String major) {
        Map<String, Object> result = new LinkedHashMap<>();

        // Market-demanded skills
        Set<String> marketSkills = new HashSet<>(Arrays.asList(
            "Python", "Java", "机器学习", "数据分析", "Docker", "Kubernetes",
            "云计算", "SQL", "Git", "Linux", "SpringBoot", "Vue", "React"
        ));

        // Course-covered skills (simulated)
        Set<String> courseSkills = new HashSet<>(Arrays.asList(
            "Python", "Java", "SQL", "Linux", "数据分析", "Git"
        ));

        Set<String> gaps = calculator.findGaps(marketSkills, courseSkills);
        double coverage = calculator.calculateCoverage(marketSkills, courseSkills);

        List<Map<String, Object>> gapList = new ArrayList<>();
        for (String gap : gaps) {
            int demand = 70 + new Random().nextInt(30);
            gapList.add(Map.of("name", gap, "demand", demand, "covered", false));
        }
        gapList.sort((a, b) -> Integer.compare((int) b.get("demand"), (int) a.get("demand")));

        result.put("coverage", Math.round(coverage * 1000) / 10.0);
        result.put("marketSkillCount", marketSkills.size());
        result.put("courseSkillCount", courseSkills.size());
        result.put("gaps", gapList);
        return result;
    }

    public Map<String, Object> runAnalysis(Map<String, Object> params) {
        return getGapAnalysis(
            (String) params.get("school"),
            (String) params.get("major")
        );
    }
}

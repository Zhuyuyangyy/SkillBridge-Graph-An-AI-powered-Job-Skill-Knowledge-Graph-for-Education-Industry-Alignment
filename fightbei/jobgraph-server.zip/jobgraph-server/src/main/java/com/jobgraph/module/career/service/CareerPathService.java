package com.jobgraph.module.career.service;

import com.jobgraph.module.etl.nlp.NlpEntityExtractor;
import com.jobgraph.module.match.service.SkillVectorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CareerPathService {

    private final NlpEntityExtractor nlpExtractor;
    private final SkillVectorService skillVector;

    // 模拟岗位数据库（实际应从MySQL/Neo4j读取）
    private static final List<JobRequirement> JOB_DB = Arrays.asList(
        new JobRequirement("Java开发工程师", "互联网/IT", 20000, 35000,
            List.of("Java", "SpringBoot", "MySQL", "Redis", "Linux", "Docker", "微服务", "分布式系统")),
        new JobRequirement("Python开发工程师", "互联网/IT", 18000, 32000,
            List.of("Python", "Django", "MySQL", "Linux", "Docker", "数据分析")),
        new JobRequirement("数据分析师", "互联网/IT", 15000, 28000,
            List.of("Python", "SQL", "数据分析", "Pandas", "NumPy", "统计学", "沟通能力")),
        new JobRequirement("算法工程师", "互联网/IT", 25000, 45000,
            List.of("Python", "机器学习", "深度学习", "PyTorch", "TensorFlow", "算法")),
        new JobRequirement("前端开发工程师", "互联网/IT", 16000, 30000,
            List.of("JavaScript", "Vue", "React", "TypeScript", "CSS", "Webpack", "Node.js")),
        new JobRequirement("DevOps工程师", "互联网/IT", 20000, 38000,
            List.of("Linux", "Docker", "Kubernetes", "Jenkins", "CI/CD", "Prometheus", "Shell")),
        new JobRequirement("产品经理", "互联网/IT", 18000, 35000,
            List.of("需求分析", "项目管理", "沟通能力", "数据分析", "文档编写", "敏捷开发")),
        new JobRequirement("数据工程师", "互联网/IT", 20000, 38000,
            List.of("Python", "SQL", "Spark", "Flink", "Kafka", "Hadoop", "Docker")),
        new JobRequirement("信息安全工程师", "互联网/IT", 18000, 35000,
            List.of("Linux", "网络安全", "渗透测试", "Python", "TCP/IP", "安全合规")),
        new JobRequirement("金融分析师", "金融", 15000, 30000,
            List.of("Python", "SQL", "数据分析", "统计学", "Excel", "财务分析", "沟通能力")),
        new JobRequirement("量化交易工程师", "金融", 25000, 50000,
            List.of("Python", "机器学习", "深度学习", "C++", "统计学", "金融工程")),
        new JobRequirement("AI提示词工程师", "互联网/IT", 20000, 40000,
            List.of("Python", "LLM", "Prompt Engineering", "NLP", "对话系统")),
        new JobRequirement("生物信息工程师", "医疗健康", 18000, 35000,
            List.of("Python", "生物信息学", "NGS", "统计学", "Linux", "R"))
    );

    /**
     * 核心功能：基于用户技能推荐岗位 + 缺口分析 + 学习路径
     */
    public CareerAdvice analyze(List<String> userSkills) {
        CareerAdvice advice = new CareerAdvice();
        advice.setUserSkills(userSkills);
        advice.setSkillCount(userSkills.size());

        Set<String> userSkillSet = new HashSet<>(userSkills.stream()
            .map(String::toLowerCase).map(String::trim).collect(Collectors.toSet()));

        // 1. 为每个岗位计算匹配度
        List<JobMatch> matches = new ArrayList<>();
        for (JobRequirement job : JOB_DB) {
            JobMatch match = new JobMatch();
            match.setJobName(job.name);
            match.setIndustry(job.industry);
            match.setSalaryRange(job.salaryMin + " - " + job.salaryMax);

            // 计算已掌握的技能
            List<String> mastered = new ArrayList<>();
            List<String> missing = new ArrayList<>();

            for (String reqSkill : job.requiredSkills) {
                boolean found = userSkillSet.stream()
                    .anyMatch(us -> skillVector.semanticSimilarity(us, reqSkill.toLowerCase()) > 0.5);
                if (found) mastered.add(reqSkill);
                else missing.add(reqSkill);
            }

            match.setMasteredSkills(mastered);
            match.setMissingSkills(missing);
            match.setMatchRate(job.requiredSkills.isEmpty() ? 0 :
                Math.round((double) mastered.size() / job.requiredSkills.size() * 1000) / 10.0);

            // 综合评分（匹配率 + 薪水加权）
            match.setCompositeScore(calcCompositeScore(match.getMatchRate(), job.salaryMax));
            matches.add(match);
        }

        // 排序
        matches.sort((a, b) -> Double.compare(b.getCompositeScore(), a.getCompositeScore()));

        // Top 5 推荐
        advice.setTopJobs(matches.subList(0, Math.min(5, matches.size())));

        // 2. 能力缺口分析
        Set<String> allMissingSkills = new LinkedHashSet<>();
        Map<String, Integer> missingFreq = new HashMap<>();
        for (int i = 0; i < Math.min(3, matches.size()); i++) {
            for (String ms : matches.get(i).getMissingSkills()) {
                missingFreq.merge(ms, 1, Integer::sum);
                allMissingSkills.add(ms);
            }
        }

        List<GapSkill> gapSkills = allMissingSkills.stream()
            .map(s -> new GapSkill(s, missingFreq.getOrDefault(s, 1),
                skillVector.findSimilarSkills(s, 3).stream()
                    .map(Map.Entry::getKey).collect(Collectors.toList())))
            .collect(Collectors.toList());
        advice.setGapAnalysis(gapSkills);

        // 3. 学习路径推荐
        List<String> learnPath = generateLearningPath(gapSkills, userSkills);
        advice.setLearningPath(learnPath);

        return advice;
    }

    private double calcCompositeScore(double matchRate, int salary) {
        return matchRate * 0.7 + (Math.min(salary, 40000) / 40000.0) * 30;
    }

    private List<String> generateLearningPath(List<GapSkill> gaps, List<String> currentSkills) {
        List<String> path = new ArrayList<>();
        path.add("🔍 第一阶段：巩固基础 (1-2周)");
        path.add("- 检查当前技能" + String.join("、", currentSkills.subList(0, Math.min(3, currentSkills.size()))) + "的掌握程度");
        path.add("");
        path.add("📚 第二阶段：核心技能学习 (3-6周)");
        int coreCount = 0;
        for (GapSkill gap : gaps) {
            if (coreCount >= 3) break;
            path.add("- " + gap.getName() + "：推荐学习资源 + 实战项目练习");
            coreCount++;
        }
        path.add("");
        path.add("🚀 第三阶段：实战提升 (2-4周)");
        path.add("- 完成一个综合项目，融合所学技能");
        path.add("- 参与开源项目或实习积累经验");
        path.add("");
        path.add("📋 第四阶段：持续跟踪");
        path.add("- 关注目标岗位的JD变化，动态调整学习方向");
        return path;
    }

    // ===== DTO classes =====
    @lombok.Data
    public static class CareerAdvice {
        private List<String> userSkills;
        private int skillCount;
        private List<JobMatch> topJobs;
        private List<GapSkill> gapAnalysis;
        private List<String> learningPath;
    }
    @lombok.Data
    public static class JobMatch {
        private String jobName;
        private String industry;
        private String salaryRange;
        private double matchRate;
        private double compositeScore;
        private List<String> masteredSkills;
        private List<String> missingSkills;
    }
    @lombok.Data @lombok.AllArgsConstructor
    public static class GapSkill {
        private String name;
        private int demandCount;
        private List<String> relatedSkills;
    }
    @lombok.Data @lombok.AllArgsConstructor
    public static class JobRequirement {
        private String name;
        private String industry;
        private int salaryMin;
        private int salaryMax;
        private List<String> requiredSkills;
    }
}
